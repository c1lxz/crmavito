const fs = require("node:fs");
const path = require("node:path");

const SUPPORTED_BROWSERS = ["chrome", "yandex", "edge", "firefox"];
const DEFAULT_PROFILE = Object.freeze({ id: "default", name: "Основной аккаунт" });

function normalizeBrowser(value) {
  const browser = String(value || "").trim().toLowerCase();
  if (!SUPPORTED_BROWSERS.includes(browser)) {
    throw new Error("Выберите Google Chrome, Яндекс.Браузер, Microsoft Edge или Mozilla Firefox.");
  }
  return browser;
}

function normalizeProfileId(value) {
  const id = String(value || "").trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9_-]{0,47}$/.test(id)) {
    throw new Error("Некорректный идентификатор профиля браузера.");
  }
  return id;
}

function normalizeProfileName(value) {
  const name = String(value || "").replace(/\s+/g, " ").trim();
  if (name.length < 2) throw new Error("Укажите название аккаунта.");
  if (name.length > 60) throw new Error("Название аккаунта не должно быть длиннее 60 символов.");
  return name;
}

function profileSlug(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32) || "account";
}

function normalizeAgentSettings(input = {}) {
  const browser = normalizeBrowser(input.browser || "chrome");
  const profiles = {};
  const selectedProfiles = {};

  for (const browserId of SUPPORTED_BROWSERS) {
    const rawProfiles = Array.isArray(input.profiles?.[browserId]) ? input.profiles[browserId] : [];
    const seen = new Set();
    profiles[browserId] = [DEFAULT_PROFILE, ...rawProfiles]
      .map((profile) => {
        try {
          return {
            id: normalizeProfileId(profile?.id),
            name: normalizeProfileName(profile?.name),
          };
        } catch {
          return null;
        }
      })
      .filter((profile) => profile && !seen.has(profile.id) && seen.add(profile.id));

    if (!profiles[browserId].some((profile) => profile.id === DEFAULT_PROFILE.id)) {
      profiles[browserId].unshift({ ...DEFAULT_PROFILE });
    }

    const requested = String(input.selectedProfiles?.[browserId] || "default");
    selectedProfiles[browserId] = profiles[browserId].some((profile) => profile.id === requested)
      ? requested
      : "default";
  }

  return { browser, profiles, selectedProfiles };
}

function listAgentProfiles(settings, browser = settings.browser) {
  const browserId = normalizeBrowser(browser);
  const installed = installedBrowserProfiles(browserId);
  if (!installed.length) return settings.profiles[browserId].map((profile) => ({ ...profile }));

  return installed.map((browserProfile) => {
    const stored = browserProfile.directory === "Default"
      ? settings.profiles[browserId].find((profile) => profile.id === "default")
      : settings.profiles[browserId].find((profile) => profileNamesMatch(profile.name, browserProfile));
    if (!stored) return null;
    return {
      ...stored,
      name: browserProfile.displayName,
      source: "system",
      systemProfileDirectory: browserProfile.directory,
      browserUserName: browserProfile.userName,
    };
  }).filter(Boolean);
}

function getAgentProfile(settings, browser, profileId) {
  const browserId = normalizeBrowser(browser);
  const id = normalizeProfileId(profileId || settings.selectedProfiles[browserId] || "default");
  const profile = settings.profiles[browserId].find((candidate) => candidate.id === id);
  if (!profile) throw new Error("Профиль браузера не найден. Обновите список аккаунтов и выберите профиль снова.");
  return { ...profile };
}

function addAgentProfile(settings, browser, name, now = Date.now()) {
  const browserId = normalizeBrowser(browser);
  const profileName = normalizeProfileName(name);
  const base = profileSlug(profileName);
  const existing = new Set(settings.profiles[browserId].map((profile) => profile.id));
  let id = `${base}-${Number(now).toString(36)}`;
  let suffix = 2;
  while (existing.has(id)) id = `${base}-${Number(now).toString(36)}-${suffix++}`;

  const profile = { id, name: profileName };
  const next = normalizeAgentSettings(settings);
  next.profiles[browserId].push(profile);
  next.selectedProfiles[browserId] = id;
  return { settings: next, profile };
}

function selectAgentProfile(settings, browser, profileId) {
  const browserId = normalizeBrowser(browser);
  const profile = getAgentProfile(settings, browserId, profileId);
  const next = normalizeAgentSettings(settings);
  next.selectedProfiles[browserId] = profile.id;
  return { settings: next, profile };
}

function agentProfileDirectory(rpaDir, browser, profileId) {
  const browserId = normalizeBrowser(browser);
  const id = normalizeProfileId(profileId || "default");
  const suffix = id === "default" ? "" : `-${id}`;
  return path.join(rpaDir, `.browser-profile-${browserId}${suffix}`);
}

function browserUserDataDirectory(browser, env = process.env, platform = process.platform) {
  const browserId = normalizeBrowser(browser);
  if (platform === "win32") {
    const localAppData = env.LOCALAPPDATA || "";
    return {
      chrome: localAppData && path.join(localAppData, "Google", "Chrome", "User Data"),
      yandex: localAppData && path.join(localAppData, "Yandex", "YandexBrowser", "User Data"),
      edge: localAppData && path.join(localAppData, "Microsoft", "Edge", "User Data"),
      firefox: "",
    }[browserId];
  }
  if (platform === "darwin") {
    const home = env.HOME || "";
    return {
      chrome: home && path.join(home, "Library", "Application Support", "Google", "Chrome"),
      yandex: home && path.join(home, "Library", "Application Support", "Yandex", "YandexBrowser"),
      edge: home && path.join(home, "Library", "Application Support", "Microsoft Edge"),
      firefox: "",
    }[browserId];
  }
  const home = env.HOME || "";
  return {
    chrome: home && path.join(home, ".config", "google-chrome"),
    yandex: home && path.join(home, ".config", "yandex-browser"),
    edge: home && path.join(home, ".config", "microsoft-edge"),
    firefox: "",
  }[browserId];
}

function installedBrowserProfiles(browser, options = {}) {
  const userDataDir = options.userDataDir || browserUserDataDirectory(browser, options.env, options.platform);
  if (!userDataDir) return [];
  const readFileSync = options.readFileSync || fs.readFileSync;
  try {
    const state = JSON.parse(readFileSync(path.join(userDataDir, "Local State"), "utf8"));
    const infoCache = state?.profile?.info_cache || {};
    const preferredOrder = Array.isArray(state?.profile?.profiles_order) ? state.profile.profiles_order : [];
    const directories = [...new Set([...preferredOrder, ...Object.keys(infoCache)])];
    return directories
      .filter((directory) => infoCache[directory])
      .map((directory) => {
        const info = infoCache[directory];
        const gaiaName = String(info?.gaia_given_name || info?.gaia_name || "").trim();
        return {
          directory,
          displayName: gaiaName ? gaiaName.split(/\s+/)[0] : String(info?.name || directory).trim(),
          profileName: String(info?.name || directory).trim(),
          userName: String(info?.user_name || "").trim(),
        };
      });
  } catch {
    return [];
  }
}

function profileNamesMatch(name, installed) {
  const expected = String(name || "").trim().toLocaleLowerCase();
  return [installed.displayName, installed.profileName, installed.userName]
    .some((value) => String(value || "").trim().toLocaleLowerCase() === expected);
}

function resolveInstalledBrowserProfile(settings, browser, profileId, options = {}) {
  const browserId = normalizeBrowser(browser);
  const profile = getAgentProfile(settings, browserId, profileId);
  const installed = installedBrowserProfiles(browserId, options);
  const match = profile.id === "default"
    ? installed.find((candidate) => candidate.directory === "Default")
    : installed.find((candidate) => profileNamesMatch(profile.name, candidate));
  if (!match) {
    throw new Error(`Системный профиль ${profile.name} не найден в ${browserId === "chrome" ? "Google Chrome" : "браузере"}.`);
  }
  return { ...profile, name: match.displayName, source: "system", systemProfileDirectory: match.directory, browserUserName: match.userName };
}

module.exports = {
  SUPPORTED_BROWSERS,
  addAgentProfile,
  agentProfileDirectory,
  browserUserDataDirectory,
  getAgentProfile,
  installedBrowserProfiles,
  listAgentProfiles,
  normalizeAgentSettings,
  normalizeBrowser,
  resolveInstalledBrowserProfile,
  selectAgentProfile,
};
