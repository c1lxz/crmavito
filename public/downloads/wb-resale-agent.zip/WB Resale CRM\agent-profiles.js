const path = require("node:path");

const SUPPORTED_BROWSERS = ["chrome", "yandex", "edge", "firefox"];
const DEFAULT_PROFILE = Object.freeze({ id: "default", name: "Основной аккаунт" });

function normalizeBrowser(value) {
  const browser = String(value || "").trim().toLowerCase();
  if (!SUPPORTED_BROWSERS.includes(browser)) {
    throw new Error("Выберите Google Chrome, Яндекс.Браузер, Microsoft Edge или Mozilla Firefox.");
  }
  return browser;
}

function normalizeProfileId(value) {
  const id = String(value || "").trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9_-]{0,47}$/.test(id)) {
    throw new Error("Некорректный идентификатор профиля браузера.");
  }
  return id;
}

function normalizeProfileName(value) {
  const name = String(value || "").replace(/\s+/g, " ").trim();
  if (name.length < 2) throw new Error("Укажите название аккаунта.");
  if (name.length > 60) throw new Error("Название аккаунта не должно быть длиннее 60 символов.");
  return name;
}

function profileSlug(name) {
  return String(name || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32) || "account";
}

function normalizeAgentSettings(input = {}) {
  const browser = normalizeBrowser(input.browser || "chrome");
  const profiles = {};
  const selectedProfiles = {};

  for (const browserId of SUPPORTED_BROWSERS) {
    const rawProfiles = Array.isArray(input.profiles?.[browserId]) ? input.profiles[browserId] : [];
    const seen = new Set();
    profiles[browserId] = [DEFAULT_PROFILE, ...rawProfiles]
      .map((profile) => {
        try {
          return {
            id: normalizeProfileId(profile?.id),
            name: normalizeProfileName(profile?.name),
          };
        } catch {
          return null;
        }
      })
      .filter((profile) => profile && !seen.has(profile.id) && seen.add(profile.id));

    if (!profiles[browserId].some((profile) => profile.id === DEFAULT_PROFILE.id)) {
      profiles[browserId].unshift({ ...DEFAULT_PROFILE });
    }

    const requested = String(input.selectedProfiles?.[browserId] || "default");
    selectedProfiles[browserId] = profiles[browserId].some((profile) => profile.id === requested)
      ? requested
      : "default";
  }

  return { browser, profiles, selectedProfiles };
}

function listAgentProfiles(settings, browser = settings.browser) {
  const browserId = normalizeBrowser(browser);
  return settings.profiles[browserId].map((profile) => ({ ...profile }));
}

function getAgentProfile(settings, browser, profileId) {
  const browserId = normalizeBrowser(browser);
  const id = normalizeProfileId(profileId || settings.selectedProfiles[browserId] || "default");
  const profile = settings.profiles[browserId].find((candidate) => candidate.id === id);
  if (!profile) throw new Error("Профиль браузера не найден. Обновите список аккаунтов и выберите профиль снова.");
  return { ...profile };
}

function addAgentProfile(settings, browser, name, now = Date.now()) {
  const browserId = normalizeBrowser(browser);
  const profileName = normalizeProfileName(name);
  const base = profileSlug(profileName);
  const existing = new Set(settings.profiles[browserId].map((profile) => profile.id));
  let id = `${base}-${Number(now).toString(36)}`;
  let suffix = 2;
  while (existing.has(id)) id = `${base}-${Number(now).toString(36)}-${suffix++}`;

  const profile = { id, name: profileName };
  const next = normalizeAgentSettings(settings);
  next.profiles[browserId].push(profile);
  next.selectedProfiles[browserId] = id;
  return { settings: next, profile };
}

function selectAgentProfile(settings, browser, profileId) {
  const browserId = normalizeBrowser(browser);
  const profile = getAgentProfile(settings, browserId, profileId);
  const next = normalizeAgentSettings(settings);
  next.selectedProfiles[browserId] = profile.id;
  return { settings: next, profile };
}

function agentProfileDirectory(rpaDir, browser, profileId) {
  const browserId = normalizeBrowser(browser);
  const id = normalizeProfileId(profileId || "default");
  const suffix = id === "default" ? "" : `-${id}`;
  return path.join(rpaDir, `.browser-profile-${browserId}${suffix}`);
}

module.exports = {
  SUPPORTED_BROWSERS,
  addAgentProfile,
  agentProfileDirectory,
  getAgentProfile,
  listAgentProfiles,
  normalizeAgentSettings,
  normalizeBrowser,
  selectAgentProfile,
};
