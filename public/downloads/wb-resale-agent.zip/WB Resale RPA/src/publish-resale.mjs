import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const csvPath = path.join(rootDir, "items.csv");
const selectorsPath = path.join(rootDir, "selectors.json");
const userDataDir = path.join(rootDir, ".browser-profile");
const logsDir = path.join(rootDir, "logs");
const remotePhotosDir = path.join(rootDir, "remote-photos");

fs.mkdirSync(logsDir, { recursive: true });
fs.mkdirSync(remotePhotosDir, { recursive: true });

const rl = readline.createInterface({ input, output });
const selectors = JSON.parse(fs.readFileSync(selectorsPath, "utf8"));
const items = parseSemicolonCsv(fs.readFileSync(csvPath, "utf8"));
const autoPublish = process.env.AUTO_PUBLISH !== "0";
const autoOpenForm = process.env.AUTO_OPEN_FORM !== "0";
const noPause = process.env.NO_PAUSE === "1";
const startUrl = process.env.START_URL || selectors.startUrl;
let hadErrors = false;
const networkEvents = [];

log(`Loaded ${items.length} item(s)`);
log(`Browser profile: ${userDataDir}`);
emit({ type: "run", status: "starting", total: items.length });

if (process.env.PARSE_ONLY === "1") {
  console.log(JSON.stringify({
    count: items.length,
    first: items[0] ? { id: items[0].id, title: items[0].title, category: items[0].category } : null,
    last: items.at(-1) ? { id: items.at(-1).id, title: items.at(-1).title, category: items.at(-1).category } : null
  }, null, 2));
  process.exit(0);
}

const context = await chromium.launchPersistentContext(userDataDir, {
  headless: false,
  viewport: { width: 1366, height: 1200 },
  locale: "ru-RU"
});

const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(5000);
page.on("response", async (response) => {
  const request = response.request();
  if (!["xhr", "fetch"].includes(request.resourceType())) return;
  const status = response.status();
  if (status < 400) return;
  const body = await response.text().catch(() => "");
  networkEvents.push({
    time: new Date().toISOString(),
    status,
    method: request.method(),
    url: response.url(),
    body: body.slice(0, 1500)
  });
  if (networkEvents.length > 80) networkEvents.shift();
});

try {
  await page.goto(startUrl, { waitUntil: "domcontentloaded" });
  log("Auto mode is enabled. Log in to Wildberries in the opened browser if needed.");

  for (const item of items) {
    const result = { id: item.id, title: item.title, status: "started", error: "" };
    try {
      emit({ type: "item", id: item.id, title: item.title, status: "running", message: "Открываю форму" });
      log(`Filling: ${item.id} - ${item.title}`);

      await ensureCreateForm(page);
      await fillText(page, selectors.fields.title, item.title, { fieldName: "Название", fallbackIndex: 0 });
      await chooseCategory(page, item);
      await uploadPhotos(page, selectors.fields.photos, item.photos);
      await fillText(page, selectors.fields.price, item.price, { fieldName: "Цена" });
      await setCheckbox(page, selectors.fields.allowOffers, item.allow_offers, { optional: true });
      await fillText(page, selectors.fields.quantity, item.quantity || "1", { fieldName: "Количество" });
      await fillSizeV2(page, item);
      await selectCondition(page, item.condition);
      await fillText(page, selectors.fields.description, item.description, { fieldName: "Описание" });
      await chooseFieldValue(page, selectors.fields.characteristics, item.characteristics, "Характеристики", { optional: true });
      await choosePickupPoint(page, item.pickup_point);
      await setAcceptRulesV2(page, item.accept_rules);

      if (shouldPublish(item)) {
        emit({ type: "item", id: item.id, status: "publishing", message: "Нажимаю Опубликовать" });
        await clickFirst(page, selectors.submitButton, "Кнопка публикации");
        await verifySubmission(page, item);
        result.status = "submitted";
        emit({ type: "item", id: item.id, status: "submitted", message: "Отправлено на публикацию" });
      } else {
        result.status = "draft_review";
        emit({ type: "item", id: item.id, status: "draft_review", message: "Заполнено без публикации" });
      }

      appendLog("published.csv", result);
    } catch (error) {
      hadErrors = true;
      result.status = "error";
      result.error = error?.message ?? String(error);
      appendLog("errors.csv", result);
      const screenshot = await saveDiagnostics(page, item.id, result.error);
      emit({ type: "item", id: item.id, status: "error", message: result.error, screenshot });
      log(`Error on ${item.id}: ${result.error}`);

      if (!noPause) {
        await rl.question("Fix the page or skip this item, then press Enter...");
      }
    }

    await resetForNextItem(page);
  }

  emit({ type: "run", status: hadErrors ? "failed" : "done", message: hadErrors ? "Завершено с ошибками" : "Готово" });
  log(`${hadErrors ? "Finished with errors" : "Done"}. Logs are in: ${logsDir}`);
  if (hadErrors) process.exitCode = 1;
} finally {
  if (hadErrors && noPause) {
    log("Keeping browser open for 60 seconds because errors occurred.");
    await page.waitForTimeout(60000).catch(() => {});
  } else if (!noPause) {
    await rl.question("Press Enter to close the browser...");
  }
  await context.close();
  rl.close();
}

async function ensureCreateForm(page) {
  if (await hasAnyVisible(page, selectors.fields.title)) return;

  if (autoOpenForm) {
    await page.goto(startUrl, { waitUntil: "domcontentloaded" }).catch(() => {});
    await page.waitForLoadState("networkidle", { timeout: 15000 }).catch(() => {});
    for (let attempt = 0; attempt < 8; attempt += 1) {
      await page.waitForTimeout(2500);
      const preferredProductType = false && await clickVisibleByText(page, [
        /^\u0444\u0443\u0442\u0431\u043e\u043b\u043a[аи]?$/i,
        /^\u0444\u0443\u0442\u0431\u043e\u043b\u043a\u0438$/i,
        /^\u043e\u0434\u0435\u0436\u0434\u0430$/i
      ]);
      if (preferredProductType) {
        log(`Clicked preferred product type: ${preferredProductType}`);
        await page.waitForTimeout(2500);
        if (await hasAnyVisible(page, selectors.fields.title)) return;
        continue;
      }
      if (await hasAnyVisible(page, selectors.fields.title)) return;
      if (await clickVisibleByText(page, [/^другой товар$/i])) {
        log("Clicked product type: Другой товар");
        await page.waitForTimeout(2500);
        if (await hasAnyVisible(page, selectors.fields.title)) return;
        continue;
      }
      if (await clickFirst(page, selectors.createButton, "Кнопка создания объявления", { optional: true })) {
        log(`Clicked create-form step ${attempt + 1}`);
        await page.waitForTimeout(2500);
        if (await hasAnyVisible(page, selectors.fields.title)) return;
        continue;
      }

      const clickedText = await clickVisibleByText(page, [/^продать что[-‑]то сво[её]$/i, /^разместить объявление$/i, /^создать объявление$/i]);
      if (clickedText) {
        log(`Clicked auto candidate: ${clickedText}`);
        await page.waitForTimeout(2500);
        if (await hasAnyVisible(page, selectors.fields.title)) return;
        continue;
      }
    }
  }

  const details = await visibleDiagnostics(page);
  throw new Error(
    "Не удалось открыть форму создания объявления. Проверьте, что аккаунт WB вошёл в систему. " +
      `Видимые кнопки/ссылки: ${details.clickables.slice(0, 12).join(" | ") || "нет"}`
  );
}

async function resetForNextItem(page) {
  await page.goto(startUrl, { waitUntil: "domcontentloaded" }).catch(() => {});
  await page.waitForTimeout(800).catch(() => {});
}

async function fillText(page, selectorList, value, options = {}) {
  if (!value) return;
  let locator = options.fieldName === "Описание"
    ? await fieldNearLabelLocator(page, "Описание", { prefer: ["textarea", "input", "contenteditable"] })
    : null;
  if (!locator) locator = await firstVisible(page, selectorList);
  if (!locator && Number.isInteger(options.fallbackIndex)) {
    locator = await nthVisibleTextInput(page, options.fallbackIndex);
  }
  if (!locator) {
    const details = await visibleDiagnostics(page);
    throw new Error(
      `${options.fieldName || "Поле"} не найдено. Видимые поля: ${details.inputs.slice(0, 12).join(" | ") || "нет"}`
    );
  }

  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  if (tagName === "button" || (await locator.getAttribute("role").catch(() => "")) === "button") {
    await locator.click();
    await page.keyboard.type(String(value), { delay: 20 });
    await page.keyboard.press("Enter");
    return;
  }

  await locator.fill(String(value));
  await verifyControlValue(locator, value, options.fieldName || "Поле");
}

async function chooseFieldValue(page, selectorList, value, fieldName, options = {}) {
  if (!value) return;
  let locator = fieldName === "Характеристики"
    ? await fieldNearLabelLocator(page, "Характеристики", { prefer: ["input", "textarea", "button", "rolebutton", "contenteditable"] })
    : null;
  if (!locator) locator = await firstVisible(page, selectorList);
  if (!locator) {
    if (options.optional) return;
    throw new Error(`${fieldName} не найдено. Обновите selectors.json.`);
  }

  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  const readonly = await locator.getAttribute("readonly").catch(() => null);
  if (readonly !== null) {
    await locator.click();
    await page.waitForTimeout(700);
    await clickVisibleExactText(page, String(value), { optional: options.optional, label: fieldName });
    return;
  }
  if (["input", "textarea"].includes(tagName)) {
    await locator.fill(String(value));
    await page.keyboard.press("Enter").catch(() => {});
    await verifyControlValue(locator, value, fieldName);
    return;
  }

  await locator.click();
  await page.waitForTimeout(700);
  await page.keyboard.type(String(value), { delay: 20 }).catch(() => {});
  await page.keyboard.press("Enter").catch(() => {});
}

async function fieldNearLabelLocator(page, labelText, options = {}) {
  const token = `wbr-field-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const found = await page.evaluate(({ labelText, token, prefer }) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const controlKind = (el) => {
      const tag = el.tagName.toLowerCase();
      if (tag === "textarea") return "textarea";
      if (tag === "input") return "input";
      if (tag === "button") return "button";
      if (el.getAttribute("role") === "button") return "rolebutton";
      if (el.isContentEditable) return "contenteditable";
      return "";
    };
    const controls = [...document.querySelectorAll("textarea,input,button,[role='button'],[contenteditable='true']")]
      .filter(visible)
      .filter((el) => {
        if (el.matches("input[type='hidden'],input[type='file'],input[type='checkbox'],input[type='radio']")) return false;
        return controlKind(el);
      });
    const labels = [...document.querySelectorAll("label,div,span,p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
      .filter(({ text }) => text === labelText || (text.startsWith(labelText) && text.length <= labelText.length + 32))
      .sort((a, b) => a.text.length - b.text.length || a.rect.top - b.rect.top);

    for (const label of labels) {
      const inside = controls.find((control) => label.el.contains(control));
      if (inside) {
        inside.setAttribute("data-wbr-field-token", token);
        return true;
      }

      const labelRect = label.rect;
      const target = controls
        .map((control) => {
          const rect = control.getBoundingClientRect();
          const kind = controlKind(control);
          const preferred = Array.isArray(prefer) ? prefer.indexOf(kind) : -1;
          const dy = rect.top - labelRect.bottom;
          const dx = Math.abs(rect.left - labelRect.left);
          return { control, preferred: preferred < 0 ? 99 : preferred, dy, dx, rect };
        })
        .filter(({ dy, rect }) => dy >= -12 && dy <= 190 && rect.bottom > labelRect.top)
        .sort((a, b) => a.dy - b.dy || a.preferred - b.preferred || a.dx - b.dx)[0]?.control;

      if (target) {
        target.scrollIntoView({ block: "center", inline: "center" });
        target.setAttribute("data-wbr-field-token", token);
        return true;
      }
    }
    return false;
  }, { labelText, token, prefer: options.prefer || [] }).catch(() => false);

  if (!found) return null;
  return page.locator(`[data-wbr-field-token="${token}"]`).first();
}

async function verifyControlValue(locator, expected, label) {
  const ok = await locator.evaluate((el, expected) => {
    const actual = "value" in el ? el.value : el.textContent;
    return String(actual || "").trim() === String(expected || "").trim();
  }, String(expected)).catch(() => true);
  if (!ok) throw new Error(`${label} не заполнилось. WB не принял введенный текст.`);
}

async function chooseCategory(page, item) {
  const target = normalizeCategory(item);
  const locator = await firstVisible(page, selectors.fields.category);
  if (!locator) throw new Error("Категория не найдена.");
  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  const readonly = await locator.getAttribute("readonly").catch(() => null);
  if (["input", "textarea"].includes(tagName) && readonly === null) {
    await locator.fill(target);
    return;
  }
  await locator.click();
  await page.waitForTimeout(900);
  const shortTarget = target.split("/").map((part) => part.trim()).filter(Boolean).at(-1) || target;
  let clicked = await clickVisibleExactText(page, target, { label: "Категория", optional: true });
  if (!clicked) clicked = await clickVisibleExactText(page, shortTarget, { label: "Категория", optional: true });
  if (!clicked) {
    await fillCategorySearch(page, shortTarget);
    clicked = await clickVisibleContainsText(page, shortTarget, { label: "Категория", optional: true });
  }
  if (!clicked) {
    await fillCategorySearch(page, target);
    clicked = await clickVisibleContainsText(page, shortTarget, { label: "Категория", optional: true });
  }
  if (!clicked) throw new Error(`Категория "${shortTarget}" не найдено в списке.`);
  await page.waitForTimeout(700);
}

function normalizeCategory(item) {
  const raw = String(item.category || "").trim();
  if (raw.includes("/")) return raw;
  const title = `${item.title || ""} ${item.description || ""}`.toLowerCase();
  if (title.includes("куртк")) return "Одежда / Куртки";
  if (title.includes("футбол")) return "Одежда / Футболки";
  if (title.includes("худи")) return "Одежда / Худи";
  if (title.includes("рубаш")) return "Одежда / Рубашки";
  if (title.includes("джинс")) return "Одежда / Джинсы";
  return raw || "Одежда / Футболки";
}

async function selectCondition(page, condition) {
  if (!condition) return;
  const value = String(condition).trim();
  const direct = page.getByText(value, { exact: true }).first();
  if (await direct.count().catch(() => 0)) {
    await direct.click().catch(async () => {
      await direct.locator("xpath=ancestor::label[1]").click();
    });
    return;
  }
  await chooseFieldValue(page, selectors.fields.condition, value, "Состояние", { optional: true });
}

async function fillSizeV2(page, item) {
  const size = extractSize(item);
  if (!size) return;

  await chooseSizeControlV3(page, size);
  if (!(await verifySizeSelectedV2(page, size))) {
    const screenshot = path.join(logsDir, `${safeName(item.id)}-size-not-selected-${Date.now()}.png`);
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`Размер ${size} не выбран на форме WB. Скрин: ${screenshot}`);
  }
}

async function chooseSizeControlV2(page, size) {
  const selectedByKeyboard = await chooseSizeByKeyboard(page, size);
  if (selectedByKeyboard) return;

  throw new Error(`Не удалось выбрать размер ${size} через клавиатуру.`);

  const selectedByLocator = await page.getByText(size, { exact: true }).last().click({ timeout: 5000 }).then(() => true).catch(() => false);
  const selected = selectedByLocator || await clickVisibleExactText(page, size, { label: "Размер", optional: true });
  if (selected) return;

  const typed = await page.evaluate((value) => {
    const input = document.activeElement?.tagName === "INPUT"
      ? document.activeElement
      : [...document.querySelectorAll("input")].find((el) => {
          const rect = el.getBoundingClientRect();
          const style = getComputedStyle(el);
          return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
        });
    if (!input) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    setter?.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }, size);
  if (typed) {
    await page.keyboard.press("Enter").catch(() => {});
    await page.waitForTimeout(500);
    await clickVisibleExactText(page, size, { label: "Размер", optional: true }).catch(() => false);
    return;
  }

  throw new Error(`Не удалось выбрать размер ${size}.`);
}

async function chooseSizeControlV3(page, size) {
  const opened = await clickSizeSelectLocator(page);
  if (opened) {
    await page.waitForTimeout(700);
    const selected =
      await page.getByText(size, { exact: true }).last().click({ timeout: 5000, force: true }).then(() => true).catch(() => false) ||
      await clickVisibleExactText(page, size, { label: "Размер", optional: true });
    if (selected) return;
  }

  const selectedByKeyboard = await chooseSizeByKeyboard(page, size);
  if (selectedByKeyboard) return;

  const screenshot = path.join(logsDir, `size-select-failed-${safeName(size)}-${Date.now()}.png`);
  await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
  throw new Error(`Не удалось выбрать размер ${size}. Скрин: ${screenshot}`);
}

async function clickSizeSelectLocator(page) {
  const wrapper = page.locator("div.mo-select__wrapper").filter({ hasText: "Выберите размер" }).last();
  if (!(await wrapper.count().catch(() => 0))) return false;
  await wrapper.scrollIntoViewIfNeeded().catch(() => {});
  await page.waitForTimeout(300);
  await wrapper.click({ timeout: 5000, force: true }).catch(async () => {
    const box = await wrapper.boundingBox().catch(() => null);
    if (!box) throw new Error("Size select has no bounding box.");
    await page.mouse.click(box.x + box.width - 16, box.y + box.height / 2);
  });
  return true;
}

async function chooseSizeByKeyboard(page, size) {
  await page.keyboard.press("Tab").catch(() => {});
  await page.waitForTimeout(200);
  await page.keyboard.press("Enter").catch(() => {});
  await page.waitForTimeout(500);
  await page.keyboard.type(size, { delay: 40 }).catch(() => {});
  await page.waitForTimeout(200);
  await page.keyboard.press("Enter").catch(() => {});
  await page.waitForTimeout(500);
  return verifySizeSelectedV2(page, size).catch(() => false);
}

async function clickSizeWrapperByMouse(page) {
  const point = await page.evaluate(() => {
    const choose = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const candidates = [...document.querySelectorAll("div")]
      .filter((el) => String(el.className || "").includes("mo-select__wrapper"))
      .filter((el) => norm(el.innerText || el.textContent || "").includes(choose));
    const target = candidates[candidates.length - 1];
    if (!target) return null;
    const rect = target.getBoundingClientRect();
    return { x: rect.right - 18, y: rect.top + rect.height / 2 };
  });
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  return true;
}

async function saveSizeOpenDiagnostics(page, size) {
  const base = path.join(logsDir, `size-open-${safeName(size)}-${Date.now()}`);
  await page.screenshot({ path: `${base}.png`, fullPage: true }).catch(() => {});
  const options = await page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    return [...document.querySelectorAll("button,a,[role='button'],div,span,label")]
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          className: String(el.className || "").slice(0, 120),
          text: (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 80),
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) }
        };
      })
      .filter((entry) => entry.text && entry.text.length <= 40)
      .slice(-120);
  }).catch(() => []);
  fs.writeFileSync(`${base}.json`, JSON.stringify({ options }, null, 2), "utf8");
}

async function openSizeDropdownV2(page) {
  const scrollSteps = [0, 180, 360, 540, 720, 900, 1120, 1360];
  for (const top of scrollSteps) {
    await page.mouse.move(680, 720).catch(() => {});
    if (top > 0) {
      await page.mouse.wheel(0, 260).catch(() => {});
      await page.waitForTimeout(180);
    }
    const opened = await page.evaluate((scrollTop) => {
      const label = "\u0420\u0430\u0437\u043c\u0435\u0440";
      const choose = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
      const enter = "\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
      const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
      };
      const scrollables = [document.scrollingElement, ...document.querySelectorAll("div,section,main")]
        .filter(Boolean)
        .filter((el) => el.scrollHeight > el.clientHeight + 40);
      for (const el of scrollables) {
        el.scrollTop = Math.min(scrollTop, el.scrollHeight);
      }

      const controls = [...document.querySelectorAll("button,[role='button'],input,div,span")]
        .filter(visible)
        .map((el) => ({ el, text: norm(`${el.innerText || el.textContent || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`) }))
        .filter(({ text }) => text.includes(choose) || text.includes(enter));
      const direct = controls.sort((a, b) => a.text.length - b.text.length)[0];
      if (direct) {
        direct.el.scrollIntoView({ block: "center", inline: "center" });
        direct.el.click();
        return true;
      }

      const blocks = [...document.querySelectorAll("div,label,section")]
        .filter(visible)
        .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
        .filter(({ text }) => text.includes(label) && text.includes(choose));
      const block = blocks.sort((a, b) => a.text.length - b.text.length)[0];
      if (!block) return false;
      block.el.scrollIntoView({ block: "center", inline: "center" });
      const inner = [...block.el.querySelectorAll("button,[role='button'],input,div,span")]
        .filter(visible)
        .find((el) => norm(`${el.innerText || el.textContent || ""} ${el.placeholder || ""}`).includes(choose));
      (inner || block.el).click();
      return true;
    }, top);
    if (opened) return true;
    await page.waitForTimeout(150);
  }
  return false;
}

async function verifySizeSelectedV2(page, size) {
  await page.waitForTimeout(300);
  return page.evaluate((value) => {
    const label = "\u0420\u0430\u0437\u043c\u0435\u0440";
    const choose = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const enter = "\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const blocks = [...document.querySelectorAll("div,label,section")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => text.includes(label));
    return blocks.some(({ text }) => {
      const tokens = text.split(/\s+/);
      return tokens.includes(value) && !text.includes(choose) && !text.includes(enter);
    });
  }, size);
}

async function fillSize(page, item) {
  const size = extractSize(item);
  if (!size) return;

  await page.getByText("Размер", { exact: true }).first().scrollIntoViewIfNeeded().catch(() => {});
  const filled = await page.evaluate((value) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const inputs = [...document.querySelectorAll("input")]
      .filter(visible)
      .filter((input) => /размер/i.test(norm(`${input.name || ""} ${input.placeholder || ""} ${input.closest("label")?.innerText || ""}`)));
    const input = inputs[0];
    if (!input) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();
    return true;
  }, size);

  if (!filled) {
    await chooseSizeControl(page, size);
    return;
  }
  await page.waitForTimeout(400);
}

async function chooseSizeControl(page, size) {
  const opened = await page.evaluate(() => {
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("button,[role='button'],div,input")]
      .filter(visible)
      .filter((el) => /выберите размер|укажите размер|размер/i.test(norm(`${el.innerText || ""} ${el.textContent || ""} ${el.placeholder || ""}`)));
    const target = candidates.find((el) => /выберите размер|укажите размер/i.test(norm(`${el.innerText || ""} ${el.textContent || ""} ${el.placeholder || ""}`))) || candidates[0];
    if (!target) return false;
    target.click();
    return true;
  });
  if (!opened) throw new Error(`Поле размера не найдено для значения ${size}.`);
  await page.waitForTimeout(700);

  const selected = await clickVisibleExactText(page, size, { label: "Размер", optional: true });
  if (selected) return;

  const active = await page.locator("input:visible").last();
  if (await active.count().catch(() => 0)) {
    await active.fill(size).catch(() => {});
    await page.keyboard.press("Enter").catch(() => {});
    await page.waitForTimeout(500);
    return;
  }

  throw new Error(`Не удалось выбрать размер ${size}.`);
}

function extractSize(item) {
  const source = `${item.size || ""} ${item.characteristics || ""} ${item.description || ""} ${item.title || ""}`;
  const match = source.match(/размер\s*[:\-]?\s*([0-9]{2,3}|[XSML]{1,4}|[А-ЯA-Z]{1,4})/i);
  return match?.[1]?.trim() || "";
}

async function setCheckbox(page, selectorList, rawValue, options = {}) {
  if (rawValue === "" || rawValue == null) return;
  const desired = ["true", "1", "yes", "да", "y"].includes(String(rawValue).trim().toLowerCase());
  const locator = await firstVisible(page, selectorList, { includeHidden: true });
  if (!locator) {
    if (options.optional) return;
    throw new Error("Чекбокс не найден. Обновите selectors.json.");
  }

  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  const type = await locator.getAttribute("type").catch(() => "");
  if (tagName === "input" && type === "checkbox") {
    const checked = await locator.isChecked();
    if (checked !== desired) await locator.setChecked(desired);
    return;
  }

  const ariaChecked = await locator.getAttribute("aria-checked").catch(() => null);
  if ((ariaChecked === "true") !== desired) await locator.click();
}

async function choosePickupPoint(page, pickupPoint) {
  const trigger = await firstVisible(page, selectors.fields.pickupPoint);
  if (!trigger) return;

  const tagName = await trigger.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  const readonly = await trigger.getAttribute("readonly").catch(() => null);
  if (["input", "textarea"].includes(tagName) && readonly === null) {
    if (pickupPoint) await trigger.fill(String(pickupPoint));
    return;
  }

  await trigger.click();
  await page.waitForTimeout(1200);
  await fillPickupSearch(page, pickupPoint);

  const selected = await page.evaluate((wantedRaw) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const compact = (value) => norm(value).toLowerCase().replace(/[.,]/g, "").replace(/\s+/g, "");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };

    const wanted = norm(wantedRaw).toLowerCase();
    const wantedCompact = compact(wantedRaw);
    const addressNodes = [...document.querySelectorAll("[class*='addressItemNameText'], [class*='listAddressBtnWrap'], button, [role='button']")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => text && !/выберите пункт выдачи/i.test(text));

    let candidate = null;
    if (wanted && !/по умолчанию|default/i.test(wanted)) {
      candidate = addressNodes.find(({ text }) => compact(text).includes(wantedCompact));
      candidate ||= addressNodes.find(({ text }) => {
        const value = compact(text);
        return value.includes("москва") && value.includes("новоспасск") && (value.includes("3к2") || value.includes("3корп2") || value.includes("3к2"));
      });
      candidate ||= addressNodes.find(({ text }) => {
        const value = compact(text);
        return value.includes("новоспасск") && value.includes("3") && value.includes("2");
      });
    }

    if (!candidate) return false;
    const clickable = candidate.el.closest("button,[role='button'],[class*='listAddressBtnWrap'],label") || candidate.el;
    clickable.click();
    return true;
  }, pickupPoint || "");

  if (!selected) {
    const screenshot = path.join(logsDir, `pickup-not-found-${Date.now()}.png`);
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`ПВЗ "${pickupPoint}" не найден в открытом окне WB. Случайный ПВЗ не выбираю. Скрин: ${screenshot}`);
  }

  await page.waitForTimeout(500);
  await confirmPickupPoint(page);
  await page.waitForTimeout(1200);
}

async function fillPickupSearch(page, pickupPoint) {
  if (!pickupPoint) return;
  const filled = await page.evaluate((value) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const inputs = [...document.querySelectorAll("input:not([type='file']), textarea")].filter(visible);
    const target =
      inputs.find((input) => /адрес|пункт|поиск|улиц|пвз/i.test(`${input.placeholder || ""} ${input.name || ""}`)) ||
      inputs[inputs.length - 1];
    if (!target) return false;
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(target), "value")?.set;
    setter?.call(target, value);
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }, pickupPoint);
  if (filled) {
    await page.keyboard.press("Enter").catch(() => {});
    await page.waitForTimeout(1800);
  }
}

async function setAcceptRulesV2(page, rawValue) {
  if (rawValue === "" || rawValue == null) return;
  const desired = ["true", "1", "yes", "да", "y"].includes(String(rawValue).trim().toLowerCase());
  if (!desired) return;

  await scrollSaleModalToBottom(page);

  const clicked = await clickAcceptRulesControl(page);
  if (!clicked) {
    await forceCheckAcceptRulesInput(page);
  }

  const checked = await page.evaluate(() => {
    const phrases = [
      "\u041d\u0430\u0436\u0438\u043c\u0430\u044f",
      "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438"
    ];
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const legal = [...document.querySelectorAll("label, div, span, p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => phrases.some((phrase) => text.includes(phrase)))
      .sort((a, b) => a.text.length - b.text.length)[0]?.el;
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    if (legal && inputs.length) {
      const legalRect = legal.getBoundingClientRect();
      const nearest = inputs
        .map((input) => ({ input, rect: input.getBoundingClientRect() }))
        .sort((a, b) => Math.abs(a.rect.top - legalRect.top) - Math.abs(b.rect.top - legalRect.top))[0]?.input;
      if (nearest?.checked) return true;
    }
    return [...document.querySelectorAll("[aria-checked='true'], [class*='checked'], [class*='Checked']")]
      .filter(visible)
      .some((el) => {
        const text = norm(el.closest("label, div")?.innerText || el.closest("label, div")?.textContent || "");
        return phrases.some((phrase) => text.includes(phrase));
      });
  });

  if (!checked) {
    const screenshot = path.join(logsDir, `accept-rules-not-checked-${Date.now()}.png`);
    const diagnostics = path.join(logsDir, `accept-rules-not-checked-${Date.now()}.json`);
    await saveCheckboxDiagnostics(page, diagnostics).catch(() => {});
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`Чекбокс соглашения с правилами не включился. Скрин: ${screenshot}. Диагностика: ${diagnostics}`);
  }
}

async function clickAcceptRulesControl(page) {
  const rulesText = "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438";
  const rulesLocator = page.getByText(rulesText, { exact: false }).last();
  const rulesVisible = await rulesLocator.count().then((count) => count > 0).catch(() => false);
  if (rulesVisible) {
    await rulesLocator.scrollIntoViewIfNeeded().catch(() => {});
    await page.waitForTimeout(300);
  }

  const clickedNearText = await page.evaluate(() => {
    const phrases = [
      "\u041d\u0430\u0436\u0438\u043c\u0430\u044f",
      "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438"
    ];
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const legal = [...document.querySelectorAll("label, div, span, p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => phrases.some((phrase) => text.includes(phrase)))
      .sort((a, b) => a.text.length - b.text.length)[0]?.el;
    if (!legal) return false;

    legal.scrollIntoView({ block: "center", inline: "center" });
    const labels = [legal.closest("label"), legal.querySelector("label")].filter(Boolean);
    for (const label of labels) {
      label.click();
      return true;
    }

    const legalRect = legal.getBoundingClientRect();
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    const nearest = inputs
      .map((input) => ({ input, rect: input.getBoundingClientRect() }))
      .sort((a, b) => Math.abs(a.rect.top - legalRect.top) - Math.abs(b.rect.top - legalRect.top))[0]?.input;
    if (nearest) {
      nearest.click();
      return true;
    }
    return false;
  }).catch(() => false);
  await page.waitForTimeout(400);
  if (await isAcceptRulesChecked(page)) return true;

  const clickedLastInput = await clickLastCheckboxInput(page);
  if (clickedLastInput) {
    await page.waitForTimeout(400);
    if (await isAcceptRulesChecked(page)) return true;
  }

  if (rulesVisible) {
    const box = await rulesLocator.boundingBox().catch(() => null);
    if (box) {
      await page.mouse.click(Math.max(6, box.x - 24), box.y + Math.min(14, box.height / 2));
      await page.waitForTimeout(400);
      if (await isAcceptRulesChecked(page)) return true;
    }
  }

  return clickedNearText || clickedLastInput;
}

async function clickLastCheckboxInput(page) {
  const boxes = page.locator("input[type='checkbox']");
  const count = await boxes.count().catch(() => 0);
  if (!count) return false;
  const target = boxes.nth(count - 1);
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await page.waitForTimeout(200);
  await target.click({ force: true, timeout: 3000 }).catch(async () => {
    const box = await target.boundingBox().catch(() => null);
    if (!box) throw new Error("Accept rules checkbox has no bounding box.");
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  });
  return true;
}

async function isAcceptRulesChecked(page) {
  return page.evaluate(() => {
    const phrases = [
      "\u041d\u0430\u0436\u0438\u043c\u0430\u044f",
      "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438"
    ];
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const legal = [...document.querySelectorAll("label, div, span, p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => phrases.some((phrase) => text.includes(phrase)))
      .sort((a, b) => a.text.length - b.text.length)[0]?.el;
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    if (legal && inputs.length) {
      const legalRect = legal.getBoundingClientRect();
      const nearest = inputs
        .map((input) => ({ input, rect: input.getBoundingClientRect() }))
        .sort((a, b) => Math.abs(a.rect.top - legalRect.top) - Math.abs(b.rect.top - legalRect.top))[0]?.input;
      if (nearest?.checked) return true;
    }
    return Boolean(inputs.at(-1)?.checked);
  }).catch(() => false);
}

async function forceCheckAcceptRulesInput(page) {
  await page.evaluate(() => {
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    const target = inputs[inputs.length - 1];
    if (!target) return false;
    const checkedSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
    checkedSetter?.call(target, true);
    target.checked = true;
    target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
    checkedSetter?.call(target, true);
    target.checked = true;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }).catch(() => false);
  await page.waitForTimeout(300);
}

async function scrollSaleModalToBottom(page) {
  await page.evaluate(() => {
    const all = [...document.querySelectorAll("*")];
    const scrollables = all.filter((el) => {
      const style = getComputedStyle(el);
      return /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
    });
    for (const el of scrollables) {
      el.scrollTop = el.scrollHeight;
    }
    const publish = all.find((el) => String(el.innerText || el.textContent || "").trim() === "\u041e\u043f\u0443\u0431\u043b\u0438\u043a\u043e\u0432\u0430\u0442\u044c");
    publish?.scrollIntoView({ block: "center", inline: "center" });
  }).catch(() => {});
  await page.waitForTimeout(500);
  await page.mouse.move(680, 760).catch(() => {});
  await page.mouse.wheel(0, 900).catch(() => {});
  await page.waitForTimeout(300);
}

async function saveCheckboxDiagnostics(page, filePath) {
  const data = await page.evaluate(() => {
    return [...document.querySelectorAll("input[type='checkbox']")].map((input, index) => {
      const rect = input.getBoundingClientRect();
      const host = input.closest("label, div");
      return {
        index,
        checked: input.checked,
        disabled: input.disabled,
        ariaChecked: input.getAttribute("aria-checked"),
        rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
        text: String(host?.innerText || host?.textContent || "").trim().replace(/\s+/g, " ").slice(0, 300),
        html: input.outerHTML.slice(0, 500)
      };
    });
  });
  await fs.writeFile(filePath, JSON.stringify(data, null, 2), "utf8");
}

async function setAcceptRules(page, rawValue) {
  if (rawValue === "" || rawValue == null) return;
  const desired = ["true", "1", "yes", "да", "y"].includes(String(rawValue).trim().toLowerCase());
  if (!desired) return;

  const checked = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    };

    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    const byLegalText = [...document.querySelectorAll("label, div, span, p")]
      .find((el) => visible(el) && /нажимая|правилами торговой площадки/i.test(norm(el.innerText || el.textContent || "")));

    let target = null;
    if (byLegalText) {
      target = byLegalText.querySelector("input[type='checkbox']");
      target ||= byLegalText.closest("label")?.querySelector("input[type='checkbox']");
      target ||= byLegalText.parentElement?.querySelector("input[type='checkbox']");
    }
    target ||= inputs[inputs.length - 1];

    if (target) {
      if (!target.checked) target.click();
      return target.checked || true;
    }

    const label = byLegalText?.closest("label") || byLegalText;
    if (label) {
      label.click();
      return true;
    }

    return false;
  });

  if (!checked) throw new Error("Чекбокс согласия с правилами не найден.");
}

async function confirmPickupPoint(page) {
  const clicked = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const buttons = [...document.querySelectorAll("button")].filter(visible);
    const target = buttons.find((button) => /^отправлю отсюда$/i.test(norm(button.innerText || button.textContent || "")));
    if (!target) return false;
    target.click();
    return true;
  });
  if (!clicked) throw new Error("Кнопка подтверждения ПВЗ \"Отправлю отсюда\" не найдена.");
  await page.waitForFunction(() => {
    const text = document.body?.innerText || "";
    return !/Выберите пункт выдачи/i.test(text) || !/Отправлю отсюда/i.test(text);
  }, null, { timeout: 7000 }).catch(() => {});
}

async function uploadPhotos(page, selectorList, rawPhotos) {
  if (!rawPhotos) return;
  const photoRefs = rawPhotos
    .split(",")
    .map((photo) => photo.trim())
    .filter(Boolean);

  const files = [];
  for (const [index, photo] of photoRefs.entries()) {
    const source = /^https?:\/\//i.test(photo) ? await downloadRemotePhoto(photo, index) : path.resolve(rootDir, photo);
    files.push(prepareLocalPhotoForUpload(source, index));
  }
  log(`Prepared ${files.length} photo(s) for upload.`);

  const missing = files.filter((file) => !fs.existsSync(file));
  if (missing.length) throw new Error(`Фото не найдены: ${missing.join(", ")}`);
  if (files.length < 3 || files.length > 30) throw new Error(`WB требует от 3 до 30 фото. Сейчас: ${files.length}.`);

  const locator = await firstVisible(page, selectorList, { includeHidden: true });
  if (!locator) throw new Error("Поле загрузки фото не найдено.");
  await locator.setInputFiles(files);
  await waitForPhotoUpload(page, files.length);
}

async function downloadRemotePhoto(url, index = 0) {
  const filename = `${crypto.createHash("sha1").update(`${url}:${index}:source`).digest("hex")}${imageExtFromUrl(url)}`;
  const targetPath = path.join(remotePhotosDir, filename);
  if (fs.existsSync(targetPath) && fs.statSync(targetPath).size > 0) return targetPath;

  const { buffer, status } = await fetchImageWithTimeout(url, 30_000);
  if (status < 200 || status >= 300) throw new Error(`Не удалось скачать фото ${url}: HTTP ${status}`);
  if (!buffer.length) throw new Error(`Фото ${url} пустое`);
  fs.writeFileSync(targetPath, buffer);
  return targetPath;
}

function prepareLocalPhotoForUpload(sourcePath, index = 0) {
  const stats = fs.statSync(sourcePath);
  const fingerprint = `${sourcePath}:${stats.size}:${stats.mtimeMs}:${index}`;
  const filename = `${crypto.createHash("sha1").update(fingerprint).digest("hex")}.jpg`;
  const targetPath = path.join(remotePhotosDir, filename);
  if (fs.existsSync(targetPath) && fs.statSync(targetPath).size > 0) return targetPath;

  normalizeImageForUpload(sourcePath, targetPath);
  if (!fs.existsSync(targetPath) || fs.statSync(targetPath).size === 0) {
    throw new Error(`Не удалось подготовить фото для WB: ${sourcePath}`);
  }
  return targetPath;
}

async function fetchImageWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { signal: controller.signal });
    const buffer = Buffer.from(await response.arrayBuffer());
    return { status: response.status, buffer };
  } catch (error) {
    if (error.name === "AbortError") throw new Error(`Таймаут скачивания фото ${url}`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function imageExtFromUrl(url) {
  try {
    const ext = path.extname(new URL(url).pathname).toLowerCase();
    if ([".jpg", ".jpeg", ".png", ".webp"].includes(ext)) return ext === ".jpeg" ? ".jpg" : ext;
  } catch {}
  return ".jpg";
}

function normalizeImageForUpload(sourcePath, targetPath) {
  const script = `
Add-Type -AssemblyName System.Drawing
$src = [System.IO.Path]::GetFullPath('${escapePowerShellSingleQuoted(sourcePath)}')
$dst = [System.IO.Path]::GetFullPath('${escapePowerShellSingleQuoted(targetPath)}')
$img = [System.Drawing.Image]::FromFile($src)
try {
  $minW = 900
  $minH = 1200
  $scale = [Math]::Max($minW / $img.Width, $minH / $img.Height)
  if ($scale -lt 1.0) { $scale = 1.0 }
  $w = [Math]::Max($minW, [int][Math]::Round($img.Width * $scale))
  $h = [Math]::Max($minH, [int][Math]::Round($img.Height * $scale))
  $bmp = New-Object System.Drawing.Bitmap($w, $h)
  try {
    $graphics = [System.Drawing.Graphics]::FromImage($bmp)
    try {
      $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
      $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
      $graphics.DrawImage($img, 0, 0, $w, $h)
    } finally {
      $graphics.Dispose()
    }
    $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
    $params = New-Object System.Drawing.Imaging.EncoderParameters(1)
    $params.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality, [int64]95)
    $bmp.Save($dst, $codec, $params)
  } finally {
    if ($bmp) { $bmp.Dispose() }
  }
} finally {
  $img.Dispose()
}
`;
  const result = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], {
    encoding: "utf8",
    windowsHide: true,
    timeout: 30_000
  });
  if (result.status !== 0 || !fs.existsSync(targetPath)) {
    const details = [result.stderr, result.stdout].filter(Boolean).join(" ").trim();
    throw new Error(`Не удалось изменить разрешение фото ${sourcePath}${details ? `: ${details}` : ""}`);
  }
}

function escapePowerShellSingleQuoted(value) {
  return String(value).replaceAll("'", "''");
}

async function clickFirst(page, selectorList, label = "Элемент", options = {}) {
  const locator = await firstVisible(page, selectorList);
  if (!locator) {
    if (options.optional) return false;
    throw new Error(`${label} не найдена.`);
  }
  await locator.click();
  return true;
}

async function verifySubmission(page, item) {
  await page.waitForTimeout(9000);
  const base = path.join(logsDir, `${safeName(item.id)}-post-submit-${Date.now()}`);
  const screenshotPath = `${base}.png`;
  const jsonPath = `${base}.json`;
  await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});

  const state = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const text = norm(document.body?.innerText || "");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const buttons = [...document.querySelectorAll("button")]
      .filter(visible)
      .map((el) => norm(el.innerText || el.textContent || ""))
      .filter(Boolean);
    const inputs = [...document.querySelectorAll("input,textarea")]
      .filter(visible)
      .map((el) => norm(`${el.getAttribute("name") || ""} ${el.getAttribute("placeholder") || ""} ${el.value || ""}`))
      .filter(Boolean);
    return { url: location.href, title: document.title, text, buttons, inputs };
  });

  fs.writeFileSync(jsonPath, JSON.stringify({ ...state, networkEvents: networkEvents.slice(-30) }, null, 2), "utf8");
  log(`Post-submit diagnostics saved: ${screenshotPath}`);

  const text = state.text.toLowerCase();
  const successPatterns = [
    "на провер",
    "модерац",
    "объявление создан",
    "объявление размещ",
    "мои объявления",
    "отправлено"
  ];
  if (successPatterns.some((pattern) => text.includes(pattern))) return;

  const stillOnForm =
    text.includes("объявление о продаже") ||
    state.buttons.some((button) => /опубликовать/i.test(button)) ||
    state.inputs.some((input) => /adname|что прода/i.test(input));
  if (stillOnForm) {
    const visibleText = state.text.slice(0, 1200);
    throw new Error(`WB не подтвердил публикацию после клика. Форма осталась открыта. Скрин: ${screenshotPath}. Текст страницы: ${visibleText}`);
  }

  throw new Error(`WB не подтвердил публикацию после клика. Скрин: ${screenshotPath}. URL: ${state.url}`);
}

async function firstVisible(page, selectorList, options = {}) {
  for (const selector of selectorList ?? []) {
    const locator = page.locator(selector).first();
    const count = await locator.count().catch(() => 0);
    if (!count) continue;
    if (options.includeHidden) return locator;
    if (await locator.isVisible().catch(() => false)) return locator;
  }
  return null;
}

async function nthVisibleTextInput(page, index) {
  const locators = await page.locator("input:not([type='file']):not([type='checkbox']):not([type='radio']), textarea").all();
  let visibleIndex = 0;
  for (const locator of locators) {
    if (!(await locator.isVisible().catch(() => false))) continue;
    if (visibleIndex === index) return locator;
    visibleIndex += 1;
  }
  return null;
}

async function hasAnyVisible(page, selectorList) {
  return Boolean(await firstVisible(page, selectorList));
}

async function clickVisibleByText(page, patterns) {
  return page.evaluate((sources) => {
    const regexes = sources.map((source) => new RegExp(source, "i"));
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span")]
      .map((el) => ({ el, text: (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ") }))
      .filter(({ el, text }) => {
        const rect = el.getBoundingClientRect();
        const visible = rect.width > 5 && rect.height > 5 && getComputedStyle(el).visibility !== "hidden";
        return visible && text && text.length < 80 && regexes.some((regex) => regex.test(text));
      });
    const candidate = candidates[0];
    if (!candidate) return "";
    candidate.el.click();
    return candidate.text;
  }, patterns.map((pattern) => pattern.source));
}

async function clickVisibleExactText(page, text, options = {}) {
  const clicked = await page.evaluate((target) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span,label")]
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ el, text }) => {
        const rect = el.getBoundingClientRect();
        const visible = rect.width > 5 && rect.height > 5 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).display !== "none";
        return visible && text === target;
      });
    const preferred = candidates.find(({ el }) => String(el.className || "").includes("listItemContent")) || candidates[0];
    if (!preferred) return false;
    preferred.el.click();
    return true;
  }, text);
  if (!clicked && !options.optional) throw new Error(`${options.label || "Значение"} "${text}" не найдено в списке.`);
  return clicked;
}

async function fillCategorySearch(page, text) {
  const searchInputs = await page.locator("input[placeholder*='Поиск'], input[type='search']").all();
  for (const input of searchInputs.reverse()) {
    if (!(await input.isVisible().catch(() => false))) continue;
    await input.fill(String(text));
    await page.waitForTimeout(900);
    return true;
  }
  return false;
}

async function clickVisibleContainsText(page, text, options = {}) {
  const clicked = await page.evaluate((targetRaw) => {
    const target = String(targetRaw || "").trim().toLowerCase();
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span,label")]
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ el, text }) => visible(el) && text.length < 120 && text.toLowerCase().includes(target));
    const preferred =
      candidates.find(({ text }) => text.includes(" / ")) ||
      candidates.find(({ el }) => String(el.className || "").includes("listItem")) ||
      candidates[0];
    if (!preferred) return false;
    preferred.el.click();
    return true;
  }, text);
  if (!clicked && !options.optional) throw new Error(`${options.label || "Значение"} "${text}" не найдено в списке.`);
  return clicked;
}

async function visibleDiagnostics(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      return rect.width > 5 && rect.height > 5 && getComputedStyle(el).visibility !== "hidden";
    };
    const clickables = [...document.querySelectorAll("button,a,[role='button']")]
      .filter(visible)
      .map((el) => (el.innerText || el.textContent || el.getAttribute("aria-label") || "").trim().replace(/\s+/g, " "))
      .filter(Boolean);
    const inputs = [...document.querySelectorAll("input,textarea,select")]
      .filter(visible)
      .map((el) => `${el.tagName.toLowerCase()} ${el.getAttribute("name") || ""} ${el.getAttribute("placeholder") || ""}`.trim());
    const sizeLabel = "\u0420\u0430\u0437\u043c\u0435\u0440";
    const sizeChoice = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const sizeBlocks = [...document.querySelectorAll("button,a,[role='button'],input,textarea,select,div,span,label")]
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          role: el.getAttribute("role") || "",
          className: String(el.className || "").slice(0, 180),
          text: (el.innerText || el.textContent || el.getAttribute("placeholder") || "").trim().replace(/\s+/g, " ").slice(0, 220),
          placeholder: el.getAttribute("placeholder") || "",
          value: el.value || "",
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) }
        };
      })
      .filter((entry) => entry.text.includes(sizeLabel) || entry.text.includes(sizeChoice) || entry.placeholder.includes(sizeLabel) || entry.placeholder.includes(sizeChoice))
      .sort((a, b) => a.text.length - b.text.length)
      .slice(0, 40);
    return { clickables, inputs, sizeBlocks, url: location.href, title: document.title };
  });
}

async function saveDiagnostics(page, itemId, error) {
  const base = path.join(logsDir, `${safeName(itemId)}-${Date.now()}`);
  const screenshotPath = `${base}.png`;
  const jsonPath = `${base}.json`;
  const details = await visibleDiagnostics(page).catch(() => ({}));
  await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});
  fs.writeFileSync(jsonPath, JSON.stringify({ error, details }, null, 2), "utf8");
  log(`Diagnostics saved: ${screenshotPath}`);
  return screenshotPath;
}

function shouldPublish(item) {
  return autoPublish && String(item.draft_only).trim().toLowerCase() === "false";
}

function appendLog(fileName, row) {
  const target = path.join(logsDir, fileName);
  const exists = fs.existsSync(target);
  const line = [row.id, row.title, row.status, row.error ?? ""]
    .map((value) => `"${String(value).replaceAll('"', '""')}"`)
    .join(";") + "\n";
  if (!exists) fs.writeFileSync(target, "id;title;status;error\n", "utf8");
  fs.appendFileSync(target, line, "utf8");
}

function parseSemicolonCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  const source = String(text || "").replace(/^\uFEFF/, "");

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (char === '"' && source[i + 1] === '"') {
      cell += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === ";" && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && source[i + 1] === "\n") i += 1;
      row.push(cell);
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }

  row.push(cell);
  if (row.some((value) => value !== "")) rows.push(row);

  const headers = rows.shift() || [];
  return rows.map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function log(message) {
  console.log(message);
  emit({ type: "log", message });
}

function emit(payload) {
  console.log(`EVENT_JSON:${JSON.stringify({ time: new Date().toISOString(), ...payload })}`);
}

function safeName(value) {
  return String(value).replace(/[^a-z0-9_-]+/gi, "_");
}

async function waitForPhotoUpload(page, expectedCount) {
  await page.waitForFunction((count) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 20 && rect.height > 20 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialog = [...document.querySelectorAll("div,section")]
      .filter(visible)
      .find((el) => {
        const text = el.innerText || el.textContent || "";
        return text.includes("\u041e\u0431\u044a\u044f\u0432\u043b\u0435\u043d\u0438\u0435 \u043e \u043f\u0440\u043e\u0434\u0430\u0436\u0435") && text.includes("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435");
      });
    const root = dialog || document;
    const images = [...root.querySelectorAll("img")]
      .filter(visible)
      .filter((img) => {
        const rect = img.getBoundingClientRect();
        return rect.width <= 180 && rect.height <= 180;
      });
    const text = root.innerText || root.textContent || "";
    return images.length >= count || text.includes("\u0413\u041b\u0410\u0412\u041d\u0410\u042f");
  }, expectedCount, { timeout: 30000 });
  await page.waitForTimeout(700);
}

async function setPageZoom(page, zoom) {
  await page.evaluate((value) => {
    document.documentElement.style.zoom = String(value);
    document.body.style.zoom = String(value);
  }, zoom).catch(() => {});
  await page.waitForTimeout(300);
}
