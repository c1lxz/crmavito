@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo WB Resale RPA
echo.
set AUTO_PUBLISH=1
set AUTO_OPEN_FORM=1
if not exist node_modules (
  echo Installing dependencies...
  call npm install
)
call npm run publish
echo.
pause
