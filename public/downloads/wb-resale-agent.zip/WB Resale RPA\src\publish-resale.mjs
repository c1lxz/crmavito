import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { fileURLToPath } from "node:url";
import { chromium, firefox } from "playwright";
import { defaultProfileDirectory, resolveBrowserExecutable } from "./browser-launch.mjs";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const csvPath = path.join(rootDir, "items.csv");
const selectorsPath = path.join(rootDir, "selectors.json");
const logsDir = path.join(rootDir, "logs");
const remotePhotosDir = path.join(rootDir, "remote-photos");
const LISTING_QUANTITY = "14";

fs.mkdirSync(logsDir, { recursive: true });
fs.mkdirSync(remotePhotosDir, { recursive: true });

const rl = readline.createInterface({ input, output });
const selectors = JSON.parse(fs.readFileSync(selectorsPath, "utf8"));
let items = parseSemicolonCsv(fs.readFileSync(csvPath, "utf8"));
const itemOffset = Number(process.env.ITEM_OFFSET || 0);
if (itemOffset > 0) items = items.slice(itemOffset);
const itemLimit = Number(process.env.ITEM_LIMIT || 0);
if (itemLimit > 0) items = items.slice(0, itemLimit);
const autoPublish = process.env.AUTO_PUBLISH !== "0";
const autoOpenForm = process.env.AUTO_OPEN_FORM !== "0";
const noPause = process.env.NO_PAUSE === "1";
const inspectForm = process.env.INSPECT_FORM === "1";
const inspectPickup = process.env.INSPECT_PICKUP === "1";
const stopAfterSize = process.env.STOP_AFTER_SIZE === "1";
const traceSize = process.env.SIZE_TRACE === "1";
const sizeOnlyTest = process.env.SIZE_ONLY_TEST === "1";
const observeSizeMs = Number(process.env.OBSERVE_SIZE_MS || 0);
const observeCdpPort = Number(process.env.OBSERVE_CDP_PORT || 0);
const waitForLogin = process.env.WAIT_FOR_LOGIN !== "0";
const startUrl = process.env.START_URL || selectors.startUrl;
const browser = resolveBrowserExecutable({
  playwrightExecutablePaths: {
    chromium: chromium.executablePath(),
    firefox: firefox.executablePath()
  }
});
const browserType = browser.engine === "firefox" ? firefox : chromium;
const userDataDir = process.env.BROWSER_PROFILE
  ? path.resolve(process.env.BROWSER_PROFILE)
  : defaultProfileDirectory(rootDir, browser.id);
let hadErrors = false;
const networkEvents = [];

log(`Loaded ${items.length} item(s)`);
log(`Browser: ${browser.name} (${browser.executablePath})`);
log(`Browser profile: ${userDataDir}`);
emit({ type: "run", status: "starting", total: items.length });

if (process.env.PARSE_ONLY === "1") {
  console.log(JSON.stringify({
    count: items.length,
    first: items[0] ? parseOnlySummary(items[0]) : null,
    last: items.at(-1) ? parseOnlySummary(items.at(-1)) : null
  }, null, 2));
  process.exit(0);
}

function parseOnlySummary(item) {
  return {
    id: item.id,
    title: item.title,
    category: item.category,
    size: extractSize(item),
    quantity: LISTING_QUANTITY,
    descriptionLines: String(item.description || "").split(/\r?\n/).length,
    descriptionHasSizeRange: String(item.description || "").includes("XXS / XS / S / M / L / XL / 2XL")
  };
}

let context = null;
let page = null;
try {
  context = await browserType.launchPersistentContext(userDataDir, {
    executablePath: browser.executablePath,
    headless: false,
    viewport: null,
    args: [
      "--start-maximized",
      ...(observeCdpPort > 0 ? [`--remote-debugging-port=${observeCdpPort}`] : [])
    ],
    ...(browser.engine === "firefox" ? {} : { ignoreDefaultArgs: ["--no-sandbox"] }),
    locale: "ru-RU"
  });

  page = context.pages()[0] ?? await context.newPage();
  page.setDefaultTimeout(5000);
  page.on("response", async (response) => {
    const request = response.request();
    if (!["xhr", "fetch"].includes(request.resourceType())) return;
    const status = response.status();
    const isListingSubmit = /resale-api\.wildberries\.ru\/api\/v1\/listings\/external/i.test(response.url());
    if (status < 400 && !isListingSubmit) return;
    const body = await response.text().catch(() => "");
    networkEvents.push({
      time: new Date().toISOString(),
      status,
      method: request.method(),
      url: response.url(),
      body: body.slice(0, 1500)
    });
    if (networkEvents.length > 80) networkEvents.shift();
  });

  await openStartPage(page);
  if (waitForLogin) await waitForWbLogin(page);
  log("Auto mode is enabled. Log in to Wildberries in the opened browser if needed.");

  for (const item of items) {
    networkEvents.length = 0;
    const result = { id: item.id, title: item.title, status: "started", error: "" };
    try {
      emit({ type: "item", id: item.id, title: item.title, status: "running", message: "Открываю форму" });
      log(`Filling: ${item.id} - ${item.title}`);
      validateItemFields(item);

      await ensureCreateForm(page);
      await fillText(page, selectors.fields.title, item.title, { fieldName: "Название", fallbackIndex: 0 });
      await chooseCategory(page, item);
      if (sizeOnlyTest) {
        await fillSizeV2(page, item);
        result.status = "inspected";
        result.error = `Размер ${extractSize(item)} выбран`;
        emit({ type: "item", id: item.id, status: "inspected", message: result.error });
        log(result.error);
        break;
      }
      await uploadPhotos(page, selectors.fields.photos, item.photos);
      await fillText(page, selectors.fields.price, item.price, { fieldName: "Цена" });
      await setCheckbox(page, selectors.fields.allowOffers, item.allow_offers, { optional: true });
      await fillText(page, selectors.fields.quantity, LISTING_QUANTITY, { fieldName: "Количество" });
      await selectCondition(page, item.condition);
      await fillDescription(page, item.description);
      if (inspectForm) {
        const inspection = await inspectCharacteristicsForm(page, item);
        result.status = "inspected";
        result.error = inspection;
        appendLog("inspected.csv", result);
        emit({ type: "item", id: item.id, status: "inspected", message: inspection });
        log(inspection);
        break;
      }
      await chooseCharacteristics(page, item);
      if (observeSizeMs > 0) {
        log(`Observation pause before size: ${observeSizeMs}ms`);
        await page.waitForTimeout(observeSizeMs);
      }
      await fillSizeV2(page, item);
      if (stopAfterSize) {
        result.status = "inspected";
        result.error = `Размер ${extractSize(item)} выбран`;
        emit({ type: "item", id: item.id, status: "inspected", message: result.error });
        log(result.error);
        break;
      }
      if (inspectPickup) {
        const inspection = await inspectPickupForm(page, item);
        result.status = "inspected";
        result.error = inspection;
        emit({ type: "item", id: item.id, status: "inspected", message: inspection });
        log(inspection);
        break;
      }
      await choosePickupPoint(page, item.pickup_point);
      await setAcceptRulesV2(page, item.accept_rules);
      await savePreparedDiagnostics(page, item);

      if (shouldPublish(item)) {
        emit({ type: "item", id: item.id, status: "publishing", message: "Нажимаю Опубликовать" });
        await clickFirst(page, selectors.submitButton, "Кнопка публикации");
        const submission = await verifySubmission(page, item);
        result.status = "submitted";
        emit({
          type: "item",
          id: item.id,
          status: "submitted",
          message: "Отправлено на публикацию",
          listing_url: submission.listingUrl || "",
        });
      } else {
        result.status = "draft_review";
        emit({ type: "item", id: item.id, status: "draft_review", message: "Заполнено без публикации" });
      }

      appendLog("published.csv", result);
    } catch (error) {
      hadErrors = true;
      result.status = "error";
      result.error = error?.message ?? String(error);
      appendLog("errors.csv", result);
      const screenshot = await saveDiagnostics(page, item.id, result.error);
      emit({ type: "item", id: item.id, status: "error", message: result.error, screenshot });
      log(`Error on ${item.id}: ${result.error}`);

      if (/too many listings|слишком много объявлений|достигнут лимит|слишком много черновиков/i.test(result.error)) {
        emit({
          type: "run",
          status: "failed",
          message: "WB не принимает новые объявления: достигнут лимит аккаунта. Удалите старые черновики или снимите старые объявления и запустите очередь снова.",
        });
        break;
      }

      if (!noPause) {
        await rl.question("Fix the page or skip this item, then press Enter...");
      } else {
        emit({
          type: "run",
          status: "failed",
          message: "Остановлено после первой ошибки, чтобы WB не создавал пустые черновики.",
        });
        break;
      }
    }

    await resetForNextItem(page);
  }

  emit({ type: "run", status: hadErrors ? "failed" : "done", message: hadErrors ? "Завершено с ошибками" : "Готово" });
  log(`${hadErrors ? "Finished with errors" : "Done"}. Logs are in: ${logsDir}`);
  if (hadErrors) process.exitCode = 1;
} catch (error) {
  hadErrors = true;
  const message = fatalRunMessage(error);
  emit({ type: "run", status: "failed", message });
  log(`Fatal RPA error: ${error?.stack || error?.message || String(error)}`);
  process.exitCode = 1;
} finally {
  if (!noPause) {
    await rl.question("Press Enter to close the browser...");
  }
  await context?.close().catch(() => {});
  rl.close();
}

async function openStartPage(targetPage) {
  let lastError = null;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      await targetPage.goto(startUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
      await targetPage.waitForTimeout(1500);
      const state = await targetPage.evaluate(() => ({
        url: location.href,
        text: String(document.body?.innerText || "").trim(),
        title: document.title
      }));
      if (!/^about:blank|^chrome-error:/i.test(state.url) && (state.text || state.title)) return;
      lastError = new Error(`WB открыл пустую страницу (${state.url || "без адреса"}).`);
    } catch (error) {
      lastError = error;
    }
    log(`WB start page attempt ${attempt}/3 failed: ${lastError?.message || lastError}`);
    if (attempt < 3) {
      await targetPage.waitForTimeout(2000);
      await targetPage.reload({ waitUntil: "domcontentloaded", timeout: 30000 }).catch(() => {});
    }
  }
  throw new Error(`Не удалось загрузить страницу WB после 3 попыток: ${lastError?.message || lastError || "неизвестная ошибка"}`);
}

async function waitForWbLogin(targetPage) {
  if (!/^https?:/i.test(targetPage.url())) return;

  let waiting = false;
  while (true) {
    if (targetPage.isClosed()) throw new Error("Окно WB было закрыто во время авторизации.");
    const loginRequired = await isWbLoginRequired(targetPage).catch(() => true);
    if (!loginRequired) break;

    if (!waiting) {
      waiting = true;
      emit({
        type: "run",
        status: "waiting_auth",
        message: "Войдите в профиль Wildberries в открытом окне. Агент продолжит автоматически после входа."
      });
      log("Waiting for Wildberries login. The browser will stay open.");
    }
    await targetPage.waitForTimeout(1000);
  }

  if (waiting) {
    emit({ type: "run", status: "starting", message: "Вход выполнен. Возвращаюсь к публикации." });
    await openStartPage(targetPage);
  }
}

async function isWbLoginRequired(targetPage) {
  if (/\/(?:security\/)?login(?:[/?#]|$)/i.test(targetPage.url())) return true;
  return targetPage.evaluate(() => {
    const visible = (element) => {
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
    };
    const loginControl = [...document.querySelectorAll("a, button")]
      .find((element) => visible(element) && /^(войти|вход)$/i.test(String(element.textContent || "").trim()));
    return Boolean(loginControl);
  });
}

function fatalRunMessage(error) {
  const raw = String(error?.message || error || "неизвестная ошибка");
  if (/browser.*closed|target page.*closed|process.*closed/i.test(raw)) {
    return `Chrome закрылся до начала публикации. Закройте все окна Chrome и запустите агент снова. Причина: ${raw}`;
  }
  if (/goto|navigation|ERR_|страниц[ау] WB|timeout/i.test(raw)) {
    return `Не удалось открыть WB. Проверьте интернет, VPN/антивирус и доступ к wildberries.ru, затем повторите запуск. Причина: ${raw}`;
  }
  return `Агент остановился до публикации: ${raw}`;
}

async function ensureCreateForm(page) {
  if (await hasAdvertForm(page)) return;
  if (page.url().startsWith("file:")) {
    await page.locator("#create").click({ force: true });
    await page.waitForTimeout(100);
    if (await hasAnyVisible(page, selectors.fields.title)) return;
  }

  if (autoOpenForm) {
    if (!(await pageHasUsableContent(page))) await openStartPage(page);
    await page.waitForLoadState("networkidle", { timeout: 15000 }).catch(() => {});
    for (let attempt = 0; attempt < 8; attempt += 1) {
      await page.waitForTimeout(2500);
      if (await hasAdvertForm(page)) return;

      const chooserOpen = await isProductChooserOpen(page);
      if (chooserOpen) {
        const clickedOther = await clickOtherProduct(page);
        if (clickedOther) {
          log("Clicked product type: Другой товар");
          await page.waitForTimeout(2500);
          if (await hasAdvertForm(page)) return;
        } else {
          log("Product chooser is still loading; waiting for Другой товар");
        }
        continue;
      }

      const beforeOther = await visibleDiagnostics(page).catch(() => ({ clickables: [] }));
      log(`Product type candidates: ${beforeOther.clickables.slice(0, 30).join(" | ") || "none"}`);
      if (await clickFirst(page, selectors.createButton, "Кнопка создания объявления", { optional: true })) {
        log(`Clicked create-form step ${attempt + 1}`);
        await page.waitForTimeout(2500);
        if (await hasAdvertForm(page)) return;
        continue;
      }

      const clickedText = await clickVisibleByText(page, [/^продать что[-‑]то сво[её]$/i, /^разместить объявление$/i, /^создать объявление$/i]);
      if (clickedText) {
        log(`Clicked auto candidate: ${clickedText}`);
        await page.waitForTimeout(2500);
        if (await hasAdvertForm(page)) return;
        continue;
      }
    }
  }

  const details = await visibleDiagnostics(page);
  throw new Error(
    "Не удалось открыть форму создания объявления. Проверьте, что аккаунт WB вошёл в систему. " +
      `Видимые кнопки/ссылки: ${details.clickables.slice(0, 12).join(" | ") || "нет"}`
  );
}

async function hasAdvertForm(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const title = document.querySelector("input[name='adName']");
    const category = document.querySelector("#adCategory,input[name='adCategory']");
    return visible(title) && visible(category);
  }).catch(() => false);
}

async function isProductChooserOpen(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    return [...document.querySelectorAll("[role='dialog'],[class*='modal'],[class*='popup']")]
      .filter(visible)
      .some((dialog) => /Что хотите продать/i.test(String(dialog.innerText || dialog.textContent || "")));
  }).catch(() => false);
}

async function clickOtherProduct(page) {
  return page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialog = [...document.querySelectorAll("[role='dialog'],[class*='modal'],[class*='popup']")]
      .filter(visible)
      .find((el) => /Что хотите продать/i.test(norm(el.innerText || el.textContent || "")));
    if (!dialog) return false;
    const textNode = [...dialog.querySelectorAll("article,button,[role='button'],div,span")]
      .filter(visible)
      .find((el) => norm(el.innerText || el.textContent || "") === "Другой товар");
    if (!textNode) return false;
    const target = textNode.closest("article,button,[role='button']") || textNode;
    target.scrollIntoView({ block: "center", inline: "center" });
    target.click();
    return true;
  }).catch(() => false);
}

async function resetForNextItem(page) {
  await openStartPage(page);
  await page.waitForTimeout(800).catch(() => {});
}

async function pageHasUsableContent(targetPage) {
  return targetPage.evaluate(() => {
    const url = location.href;
    const text = String(document.body?.innerText || "").trim();
    return !/^about:blank|^chrome-error:/i.test(url) && Boolean(text || document.title);
  }).catch(() => false);
}

async function fillText(page, selectorList, value, options = {}) {
  if (!value) return;
  let locator = options.fieldName === "Описание"
    ? await fieldNearLabelLocator(page, "Описание", { prefer: ["textarea", "input", "contenteditable"] })
    : null;
  if (!locator) locator = await firstVisible(page, selectorList);
  if (!locator && Number.isInteger(options.fallbackIndex)) {
    locator = await nthVisibleTextInput(page, options.fallbackIndex);
  }
  if (!locator) {
    const details = await visibleDiagnostics(page);
    throw new Error(
      `${options.fieldName || "Поле"} не найдено. Видимые поля: ${details.inputs.slice(0, 12).join(" | ") || "нет"}`
    );
  }

  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  if (tagName === "button" || (await locator.getAttribute("role").catch(() => "")) === "button") {
    await locator.click();
    await page.keyboard.type(String(value), { delay: 20 });
    await page.keyboard.press("Enter");
    return;
  }

  await locator.fill(String(value));
  await verifyControlValue(locator, value, options.fieldName || "Поле");
}

function validateItemFields(item) {
  const description = String(item.description || "").trim();
  const pickup = String(item.pickup_point || "").trim();
  const characteristics = String(item.characteristics || "").trim();
  log(`Item fields: description=${previewValue(description)}; characteristics=${previewValue(characteristics)}; pickup=${previewValue(pickup)}`);
  if (description.length < 20) {
    throw new Error("Описание пустое или слишком короткое. Публикация остановлена.");
  }
  if (pickup && description && normalizeComparable(description) === normalizeComparable(pickup)) {
    throw new Error(`В данных объявления описание равно адресу ПВЗ: "${pickup}". Публикацию останавливаю, чтобы не отправить неверное описание.`);
  }
}

function previewValue(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text ? `"${text.slice(0, 90)}${text.length > 90 ? "..." : ""}"` : "<empty>";
}

function normalizeComparable(value) {
  return String(value || "").toLowerCase().replace(/\s+/g, " ").replace(/[.,;:]/g, "").trim();
}

async function fillDescription(page, value) {
  if (!value) return;
  const direct = page.locator("textarea#adDescription").first();
  if (await direct.count().catch(() => 0)) {
    await direct.scrollIntoViewIfNeeded().catch(() => {});
    await direct.fill(String(value));
    await verifyControlValue(direct, value, "Описание");
    return;
  }
  const token = `wbr-description-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const found = await page.evaluate((token) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };

    const byPlaceholder = [...document.querySelectorAll("textarea,input")]
      .filter(visible)
      .filter((el) => /Расскажите о товаре|Описание/i.test(norm(el.getAttribute("placeholder") || "")))
      .sort((a, b) => {
        const at = a.tagName.toLowerCase() === "textarea" ? 0 : 1;
        const bt = b.tagName.toLowerCase() === "textarea" ? 0 : 1;
        return at - bt;
      })[0];
    if (byPlaceholder) {
      byPlaceholder.scrollIntoView({ block: "center", inline: "center" });
      byPlaceholder.setAttribute("data-wbr-description-token", token);
      return true;
    }

    const labels = [...document.querySelectorAll("label,div,span,p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
      .filter(({ text }) => text === "Описание")
      .sort((a, b) => a.rect.top - b.rect.top);
    for (const label of labels) {
      const labelRect = label.rect;
      const target = [...document.querySelectorAll("textarea,input")]
        .filter(visible)
        .filter((el) => !el.matches("input[type='hidden'],input[type='file'],input[type='checkbox'],input[type='radio']"))
        .map((el) => ({ el, rect: el.getBoundingClientRect() }))
        .filter(({ rect }) => rect.top >= labelRect.bottom - 12 && rect.top <= labelRect.bottom + 160)
        .sort((a, b) => {
          const at = a.el.tagName.toLowerCase() === "textarea" ? 0 : 1;
          const bt = b.el.tagName.toLowerCase() === "textarea" ? 0 : 1;
          return at - bt || a.rect.top - b.rect.top;
        })[0]?.el;
      if (target) {
        target.scrollIntoView({ block: "center", inline: "center" });
        target.setAttribute("data-wbr-description-token", token);
        return true;
      }
    }
    return false;
  }, token).catch(() => false);
  if (!found) {
    const details = await visibleDiagnostics(page);
    throw new Error(`Описание не найдено. Видимые поля: ${details.inputs.slice(0, 12).join(" | ") || "нет"}`);
  }
  const locator = page.locator(`[data-wbr-description-token="${token}"]`).first();
  await locator.fill(String(value));
  await verifyControlValue(locator, value, "Описание");
}

async function chooseFieldValue(page, selectorList, value, fieldName, options = {}) {
  if (!value) return;
  let locator = fieldName === "Характеристики"
    ? await fieldNearLabelLocator(page, "Характеристики", { prefer: ["input", "textarea", "button", "rolebutton", "contenteditable"] })
    : null;
  if (!locator) locator = await firstVisible(page, selectorList);
  if (!locator) {
    if (options.optional) return;
    throw new Error(`${fieldName} не найдено. Обновите selectors.json.`);
  }

  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  const readonly = await locator.getAttribute("readonly").catch(() => null);
  if (readonly !== null) {
    await locator.click();
    await page.waitForTimeout(700);
    await clickVisibleExactText(page, String(value), { optional: options.optional, label: fieldName });
    return;
  }
  if (["input", "textarea"].includes(tagName)) {
    await locator.fill(String(value));
    await page.keyboard.press("Enter").catch(() => {});
    await verifyControlValue(locator, value, fieldName);
    return;
  }

  await locator.click();
  await page.waitForTimeout(700);
  await page.keyboard.type(String(value), { delay: 20 }).catch(() => {});
  await page.keyboard.press("Enter").catch(() => {});
}

async function chooseCharacteristics(page, item) {
  if (page.url().startsWith("file:")) {
    const field = page.locator("[name='characteristics']").first();
    if (await field.count()) await field.fill(String(item.characteristics || ""));
    return;
  }
  const specs = parseCharacteristics(item);
  const values = [
    ["Бренд", /без\s+бренд/i.test(specs.brand || "") ? "" : specs.brand],
    ["Пол", specs.gender],
    ["Цвет", specs.color],
    ["Состав", specs.composition],
    ["Страна производства", specs.country],
    ["Фактура материала", specs.texture],
    ["Вырез горловины", specs.neckline],
    ["Особенности модели", specs.features],
    ["Декоративные элементы", specs.decor],
    ["Тип карманов", specs.pockets],
    ["Уход за вещами", specs.care]
  ].filter(([, value]) => value);

  if (!values.length) return;

  const clickedOpen = await openCharacteristicsModal(page);
  if (!clickedOpen) throw new Error("Характеристики не найдены: не могу открыть окно выбора.");
  await page.waitForTimeout(900);

  const opened = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const text = norm(document.body?.innerText || "");
    return text.includes("Характеристики") && text.includes("Бренд") && text.includes("Пол") && text.includes("Сохранить") && (
      text.includes("Цвет") || text.includes("Состав") || text.includes("Материал верха")
    );
  }).catch(() => false);
  if (!opened) {
    const screenshot = path.join(logsDir, `characteristics-modal-not-open-${Date.now()}.png`);
    const scrollJson = path.join(logsDir, `characteristics-scrollables-${Date.now()}.json`);
    await saveScrollDiagnostics(page, scrollJson).catch(() => {});
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`Окно характеристик WB не открылось. Скрин: ${screenshot}. Скролл: ${scrollJson}`);
  }

  const selected = [];
  const missed = [];
  for (const [label, rawValue] of values) {
    const value = normalizeCharacteristicValue(label, rawValue);
    if (!value) continue;
    const ok = await selectCharacteristicDropdownValue(page, label, value, { optional: true });
    if (ok) selected.push(`${label}: ${value}`);
    else missed.push(`${label}: ${value}`);
  }

  const blockingMissed = missed.filter((item) => /^(Цвет|Состав):/.test(item));
  if (blockingMissed.length) {
    const screenshot = path.join(logsDir, `characteristics-not-selected-${Date.now()}.png`);
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`Не удалось выбрать обязательные характеристики WB: ${blockingMissed.join("; ")}. Скрин: ${screenshot}`);
  }

  const characteristicModal = page.locator(".mo-modal__paper").filter({ hasText: "Характеристики" }).last();
  const saveButton = characteristicModal.locator("button[class*='saveBtn']").first();
  if (!(await saveButton.count().catch(() => 0))) throw new Error("Не нашел кнопку Сохранить в окне характеристик.");
  const modalToken = `wbr-characteristic-modal-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  await characteristicModal.evaluate((el, token) => el.setAttribute("data-wbr-modal-token", token), modalToken);
  await saveButton.click({ force: true });
  const closed = await page.locator(`[data-wbr-modal-token="${modalToken}"]`).waitFor({ state: "detached", timeout: 5000 }).then(() => true).catch(() => false);
  if (!closed) throw new Error("WB не закрыл окно характеристик после сохранения.");
  await page.waitForTimeout(450);

  log(`Characteristics selected: ${selected.join("; ") || "none"}${missed.length ? `. Not found: ${missed.join("; ")}` : ""}`);
}

async function inspectCharacteristicsForm(page, item) {
  const opened = await openCharacteristicsModal(page);
  if (!opened) throw new Error("Диагностика: окно характеристик не открылось.");
  await page.waitForTimeout(900);

  const data = await page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const modal = [...document.querySelectorAll("[class*='modalContent'],[role='dialog'],div")]
      .filter(visible)
      .filter((el) => {
        const text = norm(el.innerText || el.textContent || "");
        return text.includes("Бренд") && text.includes("Пол") && text.includes("Сохранить");
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return ar.width * ar.height - br.width * br.height;
      })[0];
    if (!modal) return { error: "modal-not-found", elements: [] };

    const elements = [...modal.querySelectorAll("*")].map((el, index) => {
      const rect = el.getBoundingClientRect();
      return {
        index,
        tag: el.tagName.toLowerCase(),
        id: el.id || "",
        className: String(el.className || "").slice(0, 300),
        role: el.getAttribute("role") || "",
        name: el.getAttribute("name") || "",
        placeholder: el.getAttribute("placeholder") || "",
        value: "value" in el ? String(el.value || "") : "",
        text: norm(el.innerText || el.textContent || "").slice(0, 300),
        visible: visible(el),
        rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) },
        parentIndex: el.parentElement === modal ? -1 : [...modal.querySelectorAll("*")].indexOf(el.parentElement),
        attributes: Object.fromEntries([...el.attributes].map((attr) => [attr.name, attr.value]).slice(0, 20))
      };
    });
    return {
      modal: {
        tag: modal.tagName.toLowerCase(),
        className: String(modal.className || ""),
        text: norm(modal.innerText || modal.textContent || ""),
        scrollTop: modal.scrollTop,
        scrollHeight: modal.scrollHeight,
        clientHeight: modal.clientHeight
      },
      elements,
      html: modal.outerHTML.slice(0, 500000)
    };
  });

  const base = path.join(logsDir, `form-inspection-${safeName(item.id)}-${Date.now()}`);
  fs.writeFileSync(`${base}.json`, JSON.stringify(data, null, 2), "utf8");
  fs.writeFileSync(`${base}.html`, data.html || "", "utf8");
  await page.screenshot({ path: `${base}.png`, fullPage: true }).catch(() => {});
  const optionData = await inspectCharacteristicOptions(page, base);
  fs.writeFileSync(`${base}-options.json`, JSON.stringify(optionData, null, 2), "utf8");
  return `Диагностика формы сохранена: ${base}.json`;
}

async function inspectCharacteristicOptions(page, base) {
  const labels = [
    "Бренд",
    "Пол",
    "Цвет",
    "Состав",
    "Особенности модели",
    "Вырез горловины",
    "Страна производства",
    "Покрой",
    "Фактура материала",
    "Декоративные элементы",
    "Тип карманов",
    "Уход за вещами"
  ];
  const queries = {
    "Бренд": "Без бренда",
    "Пол": "Унисекс",
    "Цвет": "черный",
    "Состав": "хлопок",
    "Покрой": "приталенный"
  };
  const output = [];

  for (const [index, label] of labels.entries()) {
    const modalPresent = await page.locator(".mo-modal__paper").filter({ hasText: "Характеристики" }).count().catch(() => 0);
    if (!modalPresent) {
      await openCharacteristicsModal(page);
      await page.waitForTimeout(500);
    }
    const token = `wbr-inspect-${index}-${Date.now()}`;
    const found = await page.evaluate(({ label, token }) => {
      const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
      const content = [...document.querySelectorAll("[class*='modalContent']")]
        .find((el) => norm(el.innerText || el.textContent || "").includes("Бренд"));
      if (!content) return false;
      const heading = [...content.querySelectorAll("h4")]
        .find((el) => norm(el.innerText || el.textContent || "").replace(/\s+\d+\/\d+$/, "") === label);
      const field = heading?.parentElement;
      const wrapper = field?.querySelector(".mo-select__wrapper");
      if (!wrapper) return false;
      wrapper.scrollIntoView({ block: "center", inline: "center" });
      wrapper.setAttribute("data-wbr-inspect-token", token);
      return true;
    }, { label, token }).catch(() => false);

    if (!found) {
      output.push({ label, error: "field-not-found" });
      continue;
    }

    await page.waitForTimeout(120);
    const point = await page.locator(`[data-wbr-inspect-token="${token}"]`).boundingBox().catch(() => null);
    if (!point) {
      output.push({ label, error: "field-has-no-bounds" });
      continue;
    }
    await page.mouse.click(point.x + point.width - 24, point.y + point.height / 2).catch(() => {});
    await page.waitForTimeout(500);
    const query = queries[label] || "";
    if (query) {
      const searchInputs = page.locator("input[placeholder='Поиск']:visible");
      const searchCount = await searchInputs.count().catch(() => 0);
      if (searchCount) {
        await searchInputs.last().fill(query).catch(() => {});
        const dropdown = searchInputs.last().locator("xpath=ancestor::*[contains(concat(' ', normalize-space(@class), ' '), ' mo-dropdown ')][1]");
        await dropdown.locator(".mo-skeleton").first().waitFor({ state: "detached", timeout: 5000 }).catch(() => {});
        await page.waitForTimeout(500);
      }
    }
    const state = await page.evaluate(() => {
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
      };
      const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
      const searchInputs = [...document.querySelectorAll("input[placeholder='Поиск']")].filter(visible);
      const search = searchInputs.at(-1);
      const ancestors = [];
      let current = search?.parentElement || null;
      for (let depth = 0; current && current !== document.body && depth < 10; depth += 1, current = current.parentElement) {
        const rect = current.getBoundingClientRect();
        ancestors.push({
          depth,
          tag: current.tagName.toLowerCase(),
          className: String(current.className || "").slice(0, 260),
          text: norm(current.innerText || current.textContent || "").slice(0, 1000),
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) }
        });
      }
      const root = ancestors.length
        ? search.closest(".mo-dropdown") || search.parentElement?.parentElement?.parentElement
        : null;
      const scope = root || document;
      const candidates = [...scope.querySelectorAll("input,li,button,[role='option'],[role='listbox'],[role='menuitem'],div,span")]
        .filter(visible)
        .map((el) => {
          const rect = el.getBoundingClientRect();
          const className = String(el.className || "");
          return {
            tag: el.tagName.toLowerCase(),
            className: className.slice(0, 260),
            role: el.getAttribute("role") || "",
            placeholder: el.getAttribute("placeholder") || "",
            value: "value" in el ? String(el.value || "") : "",
            text: norm(el.innerText || el.textContent || "").slice(0, 260),
            rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) }
          };
        })
        .filter((item) => item.text.length <= 260 || /поиск/i.test(item.placeholder))
        .filter((item, index, all) => {
          const key = `${item.tag}|${item.className}|${item.role}|${item.placeholder}|${item.value}|${item.text}|${item.rect.x}|${item.rect.y}`;
          return all.findIndex((other) => `${other.tag}|${other.className}|${other.role}|${other.placeholder}|${other.value}|${other.text}|${other.rect.x}|${other.rect.y}` === key) === index;
        })
        .slice(0, 500);
      return { opened: Boolean(search), ancestors, candidates, html: root?.outerHTML?.slice(0, 300000) || "" };
    }).catch((error) => ({ error: error?.message || String(error), candidates: [] }));

    output.push({ label, query, ...state });
    await page.screenshot({ path: `${base}-options-${String(index + 1).padStart(2, "0")}-${safeName(label)}.png` }).catch(() => {});
    if (state.opened) await page.keyboard.press("Escape").catch(() => {});
    await page.waitForTimeout(220);
  }

  return output;
}

async function openCharacteristicsModal(page) {
  for (let scroll = 0; scroll < 8; scroll += 1) {
    await scrollSaleForm(page, scroll * 340);
    const box = await findCharacteristicsTriggerBox(page);
    if (box) {
      await page.mouse.click(box.clickX, box.clickY);
      await page.waitForTimeout(700);
      return true;
    }
    const clicked = await page.evaluate((scroll) => {
      const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
      };
      const scrollables = [document.scrollingElement, ...document.querySelectorAll("div,section,main")]
        .filter(Boolean)
        .filter((el) => el.scrollHeight > el.clientHeight + 30);
      for (const el of scrollables) el.scrollTop = Math.min(scroll * 320, el.scrollHeight);

      const direct = [...document.querySelectorAll("button,[role='button'],input,div,span")]
        .filter(visible)
        .map((el) => ({ el, text: norm(`${el.innerText || el.textContent || ""} ${el.getAttribute("placeholder") || ""}`), rect: el.getBoundingClientRect() }))
        .filter(({ text }) => /Выберите характеристики|Характеристики/.test(text) && !/Бренд|Пол|Цвет|Состав|Сохранить/.test(text))
        .sort((a, b) => a.text.length - b.text.length || a.rect.top - b.rect.top)[0]?.el;
      if (direct) {
        const wrapper = closestClickableWrapper(direct);
        wrapper.scrollIntoView({ block: "center", inline: "center" });
        wrapper.click();
        return true;
      }

      const labels = [...document.querySelectorAll("label,div,span,p")]
        .filter(visible)
        .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
        .filter(({ text }) => text === "Характеристики")
        .sort((a, b) => a.rect.top - b.rect.top);
      for (const label of labels) {
        const labelRect = label.rect;
        const target = [...document.querySelectorAll("button,[role='button'],input,div,span")]
          .filter(visible)
          .map((el) => ({ el, text: norm(`${el.innerText || el.textContent || ""} ${el.getAttribute("placeholder") || ""}`), rect: el.getBoundingClientRect() }))
          .filter(({ text, rect }) => rect.top >= labelRect.bottom - 12 && rect.top <= labelRect.bottom + 170 && /Выберите|характеристики/i.test(text))
          .sort((a, b) => a.rect.top - b.rect.top || a.text.length - b.text.length)[0]?.el;
        if (target) {
          const wrapper = closestClickableWrapper(target);
          wrapper.scrollIntoView({ block: "center", inline: "center" });
          wrapper.click();
          return true;
        }
      }
      return false;

      function closestClickableWrapper(el) {
        const preferred = el.closest("button,[role='button'],[class*='mo-select'],[class*='select'],[class*='input-field'],[class*='field']");
        if (preferred && visible(preferred)) return preferred;
        let current = el;
        for (let i = 0; i < 5 && current?.parentElement; i += 1) {
          current = current.parentElement;
          const rect = current.getBoundingClientRect();
          if (visible(current) && rect.width >= 180 && rect.height >= 36 && rect.height <= 90) return current;
        }
        return el;
      }
    }, scroll).catch(() => false);
    if (clicked) return true;
    await page.mouse.move(690, 760).catch(() => {});
    await page.mouse.wheel(0, 420).catch(() => {});
    await page.waitForTimeout(220);
  }
  return false;
}

async function findCharacteristicsTriggerBox(page) {
  return page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("button,[role='button'],input,div,span,label")]
      .filter(visible)
      .map((el) => ({ el, text: norm(`${el.innerText || el.textContent || ""} ${el.getAttribute("placeholder") || ""}`), rect: el.getBoundingClientRect() }))
      .filter(({ text }) => text === "Выберите характеристики" || text.includes("Выберите характеристики"))
      .sort((a, b) => a.text.length - b.text.length || b.rect.width - a.rect.width);
    const target = candidates[0];
    if (!target) return null;
    const wrapper = closestClickableWrapper(target.el);
    wrapper.scrollIntoView({ block: "center", inline: "center" });
    const rect = wrapper.getBoundingClientRect();
    return {
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height,
      clickX: Math.min(rect.right - 18, rect.left + Math.max(24, rect.width / 2)),
      clickY: rect.top + rect.height / 2
    };

    function closestClickableWrapper(el) {
      const preferred = el.closest("button,[role='button'],[class*='mo-select'],[class*='select'],[class*='input-field'],[class*='field']");
      if (preferred && visible(preferred)) return preferred;
      let current = el;
      for (let i = 0; i < 6 && current?.parentElement; i += 1) {
        current = current.parentElement;
        const rect = current.getBoundingClientRect();
        if (visible(current) && rect.width >= 180 && rect.height >= 36 && rect.height <= 90) return current;
      }
      return el;
    }
  }).catch(() => null);
}

async function scrollSaleForm(page, top) {
  await page.evaluate((top) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("div,section,form")]
      .filter(visible)
      .filter((el) => {
        const className = String(el.className || "");
        const text = String(el.innerText || el.textContent || "");
        return el.scrollHeight > el.clientHeight + 20 && (
          /popupContent|adFormWrapper|formContent|modal|scroll/i.test(className) ||
          (text.includes("Объявление о продаже") && text.includes("Укажите количество"))
        );
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return (ar.width * ar.height) - (br.width * br.height);
      });
    for (const el of candidates) {
      el.scrollTop = Math.min(top, el.scrollHeight);
    }
  }, top).catch(() => {});
  await page.waitForTimeout(160);
}

async function saveScrollDiagnostics(page, filePath) {
  const data = await page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    return [...document.querySelectorAll("*")]
      .filter(visible)
      .filter((el) => el.scrollHeight > el.clientHeight + 10)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          className: String(el.className || "").slice(0, 220),
          id: el.id || "",
          scrollTop: el.scrollTop,
          scrollHeight: el.scrollHeight,
          clientHeight: el.clientHeight,
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) },
          text: String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 3000)
        };
      });
  });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf8");
}

async function selectCharacteristicDropdownValue(page, label, value, options = {}) {
  const fieldToken = await openCharacteristicDropdown(page, label);
  if (!fieldToken) {
    if (options.optional) return false;
    throw new Error(`Характеристика "${label}" не найдена.`);
  }
  const dropdown = page.locator(".mo-dropdown:visible").last();
  const search = dropdown.locator("input[placeholder='Поиск']").first();
  if (!(await search.count().catch(() => 0))) {
    await page.keyboard.press("Escape").catch(() => {});
    return false;
  }

  const candidates = [value, ...characteristicAliases(value)]
    .map((item) => String(item || "").trim())
    .filter((item, index, all) => item && all.findIndex((other) => other.toLowerCase() === item.toLowerCase()) === index);
  let selectedValue = "";
  for (const candidate of candidates) {
    await search.click({ force: true });
    await search.press("Control+A").catch(() => {});
    await search.fill("");
    await search.type(candidate, { delay: 45 });
    await page.waitForTimeout(1100);
    let optionTexts = [];
    for (let attempt = 0; attempt < 20; attempt += 1) {
      await page.waitForTimeout(300);
      const loading = await dropdown.locator(".mo-skeleton").count().catch(() => 0);
      optionTexts = await dropdown.locator("li").allTextContents().catch(() => []);
      const normalizedOptions = optionTexts.map((text) => String(text || "").trim().toLowerCase()).filter(Boolean);
      const searchFinished = normalizedOptions.some((text) => text === candidate.toLowerCase() || text.includes(candidate.toLowerCase())) ||
        normalizedOptions.some((text) => /по вашему запросу ничего не нашли/i.test(text));
      if (!loading && searchFinished) break;
    }
    log(`Characteristic "${label}" search "${candidate}": ${optionTexts.map((text) => String(text || "").trim()).filter(Boolean).slice(0, 8).join(" | ") || "no options"}`);
    const targetIndex = optionTexts
      .map((text, index) => ({ text: String(text || "").trim().toLowerCase(), index }))
      .filter(({ text }) => text === candidate.toLowerCase() || text.includes(candidate.toLowerCase()))
      .sort((a, b) => a.text.length - b.text.length)[0]?.index ?? -1;
    if (targetIndex < 0) continue;
    await dropdown.locator("li").nth(targetIndex).click({ force: true });
    selectedValue = optionTexts[targetIndex].trim();
    break;
  }

  await page.waitForTimeout(300);
  if (await dropdown.count().catch(() => 0)) await page.keyboard.press("Escape").catch(() => {});
  if (!selectedValue) return false;

  const selected = await page.locator(`[data-wbr-characteristic-token="${fieldToken}"]`).evaluate((el, expected) => {
    const text = String(el.parentElement?.innerText || el.innerText || "").trim().replace(/\s+/g, " ").toLowerCase();
    return text.includes(String(expected || "").trim().toLowerCase());
  }, selectedValue).catch(() => false);
  if (!selected) throw new Error(`WB не сохранил значение "${selectedValue}" в характеристике "${label}".`);
  return true;
}

async function collectOpenDropdownOptions(page) {
  return page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    return [...document.querySelectorAll("[role='option'],li,button,div,span")]
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = norm(el.innerText || el.textContent || "");
        return { text, rect, className: String(el.className || "") };
      })
      .filter(({ text, rect, className }) => {
        if (!text || text.length > 80) return false;
        const central = rect.left >= 380 && rect.right <= 980 && rect.top >= 300 && rect.bottom <= 980;
        const dropdownLike = /option|list|menu|select|dropdown|item/i.test(className);
        return central && (dropdownLike || !/Характеристики|Сохранить|Выберите из списка/.test(text));
      })
      .map(({ text }) => text)
      .filter((text, index, list) => list.indexOf(text) === index)
      .slice(0, 30);
  }).catch(() => []);
}

async function verifyCharacteristicSelected(page, label, value) {
  const values = [value, ...characteristicAliases(value)].map((item) => String(item || "").toLowerCase()).filter(Boolean);
  return page.evaluate(({ label, values }) => {
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ").toLowerCase();
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const labels = [...document.querySelectorAll("label,div,span,p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
      .filter(({ text }) => text === norm(label) || text.startsWith(`${norm(label)} `) || text.startsWith(`${norm(label)} 0/`));
    for (const item of labels) {
      const area = [...document.querySelectorAll("button,[role='button'],input,div,span")]
        .filter(visible)
        .map((el) => ({ text: norm(`${el.value || ""} ${el.innerText || el.textContent || ""}`), rect: el.getBoundingClientRect() }))
        .filter(({ rect }) => rect.top >= item.rect.top - 8 && rect.top <= item.rect.bottom + 130 && Math.abs(rect.left - item.rect.left) < 120)
        .map(({ text }) => text)
        .join(" ");
      if (values.some((value) => area.includes(value))) return true;
    }
    return false;
  }, { label, values }).catch(() => false);
}

async function openCharacteristicDropdown(page, label) {
  const token = `wbr-characteristic-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const found = await page.evaluate(({ label, token }) => {
      const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
      const content = [...document.querySelectorAll("[class*='modalContent']")]
        .find((el) => [...el.querySelectorAll("h4")].some((heading) => (
          norm(heading.innerText || heading.textContent || "").replace(/\s+\d+\/\d+$/, "") === label
        )));
      if (!content) return false;
      const heading = [...content.querySelectorAll("h4")]
        .find((el) => norm(el.innerText || el.textContent || "").replace(/\s+\d+\/\d+$/, "") === label);
      const wrapper = heading?.parentElement?.querySelector(".mo-select__wrapper");
      if (!wrapper) return false;
      wrapper.scrollIntoView({ block: "center", inline: "center" });
      wrapper.setAttribute("data-wbr-characteristic-token", token);
      return true;
    }, { label, token }).catch(() => false);
  if (!found) return "";
  const wrapper = page.locator(`[data-wbr-characteristic-token="${token}"]`).first();
  await page.waitForTimeout(180);
  await wrapper.click({ force: true });
  const opened = await page.locator(".mo-dropdown:visible input[placeholder='Поиск']").last().waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false);
  return opened ? token : "";
}

function parseCharacteristics(item) {
  const raw = `${item.characteristics || ""}, ${item.description || ""}, ${item.title || ""}`;
  const specs = {};
  for (const part of raw.split(/[,;\n]+/)) {
    const cleaned = part.replace(/^[•\-\*]\s*/, "").trim();
    if (!cleaned) continue;
    const match = cleaned.match(/^([^:]+?)\s*[:\-]\s*(.+)$/) || cleaned.match(/^(Размер|Цвет|Бренд|Материал|Состав|Пол|Страна производства|Покрой|Фактура материала|Вырез горловины|Особенности модели|Декоративные элементы|Тип карманов|Уход за вещами)\s+(.+)$/i);
    if (!match) continue;
    const key = match[1].trim().toLowerCase();
    const value = match[2].trim();
    if (/бренд/.test(key)) specs.brand = value;
    else if (/пол/.test(key)) specs.gender = value;
    else if (/цвет/.test(key)) specs.color = value;
    else if (/материал|состав/.test(key)) specs.composition = value;
    else if (/страна/.test(key)) specs.country = value;
    else if (/покрой|посадка/.test(key)) specs.fit = value;
    else if (/фактура/.test(key)) specs.texture = value;
    else if (/горловин|вырез/.test(key)) specs.neckline = value;
    else if (/особенности/.test(key)) specs.features = value;
    else if (/декоратив/.test(key)) specs.decor = value;
    else if (/карман/.test(key)) specs.pockets = value;
    else if (/уход/.test(key)) specs.care = value;
  }

  const source = raw.toLowerCase();
  if (!specs.gender) {
    if (/женск|девоч/.test(source)) specs.gender = "Женский";
    else if (/мужск|мальчик/.test(source)) specs.gender = "Мужской";
    else specs.gender = "Унисекс";
  }
  if (!specs.color) {
    if (/ч[её]рн/.test(source)) specs.color = "Черный";
    else if (/бел/.test(source)) specs.color = "Белый";
  }
  if (!specs.composition) {
    if (/хлоп/.test(source)) specs.composition = "Хлопок";
  }
  return specs;
}

function normalizeCharacteristicValue(label, value) {
  const text = String(value || "").trim();
  if (!text) return "";
  if (label === "Цвет") {
    if (/ч[её]рн/i.test(text)) return "Черный";
    if (/бел/i.test(text)) return "Белый";
  }
  if (label === "Состав" || label === "Материал верха") {
    if (/хлоп/i.test(text)) return "Хлопок";
  }
  if (label === "Бренд" && /без\s+бренд/i.test(text)) return "Без бренда";
  if (label === "Пол") {
    if (/муж/i.test(text)) return "Мужской";
    if (/жен/i.test(text)) return "Женский";
    if (/уни/i.test(text)) return "Унисекс";
  }
  if (label === "Покрой" && /притал/i.test(text)) return "облегающий";
  return text.replace(/\s*\([^)]*\)\s*/g, " ").replace(/\s+/g, " ").trim();
}

function characteristicAliases(value) {
  const text = String(value || "").toLowerCase();
  if (/черн|чёрн/.test(text)) return ["Чёрный", "черный", "чёрный"];
  if (/без бренда/.test(text)) return ["Без бренда", "Нет бренда", "no brand"];
  if (/хлоп/.test(text)) return ["хлопок", "Хлопок"];
  // WB currently has no "Унисекс" option for this category. Use the
  // marketplace's available apparel classification so sizes are populated.
  if (/унисекс/.test(text)) return ["Унисекс", "унисекс", "Мужской"];
  return [];
}

async function fieldNearLabelLocator(page, labelText, options = {}) {
  const token = `wbr-field-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const found = await page.evaluate(({ labelText, token, prefer }) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const controlKind = (el) => {
      const tag = el.tagName.toLowerCase();
      if (tag === "textarea") return "textarea";
      if (tag === "input") return "input";
      if (tag === "button") return "button";
      if (el.getAttribute("role") === "button") return "rolebutton";
      if (el.isContentEditable) return "contenteditable";
      return "";
    };
    const controls = [...document.querySelectorAll("textarea,input,button,[role='button'],[contenteditable='true']")]
      .filter(visible)
      .filter((el) => {
        if (el.matches("input[type='hidden'],input[type='file'],input[type='checkbox'],input[type='radio']")) return false;
        return controlKind(el);
      });
    const labels = [...document.querySelectorAll("label,div,span,p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
      .filter(({ text }) => text === labelText || (text.startsWith(labelText) && text.length <= labelText.length + 32))
      .sort((a, b) => a.text.length - b.text.length || a.rect.top - b.rect.top);

    for (const label of labels) {
      const inside = controls.find((control) => label.el.contains(control));
      if (inside) {
        inside.setAttribute("data-wbr-field-token", token);
        return true;
      }

      const labelRect = label.rect;
      const target = controls
        .map((control) => {
          const rect = control.getBoundingClientRect();
          const kind = controlKind(control);
          const preferred = Array.isArray(prefer) ? prefer.indexOf(kind) : -1;
          const dy = rect.top - labelRect.bottom;
          const dx = Math.abs(rect.left - labelRect.left);
          return { control, preferred: preferred < 0 ? 99 : preferred, dy, dx, rect };
        })
        .filter(({ dy, rect }) => dy >= -12 && dy <= 190 && rect.bottom > labelRect.top)
        .sort((a, b) => a.dy - b.dy || a.preferred - b.preferred || a.dx - b.dx)[0]?.control;

      if (target) {
        target.scrollIntoView({ block: "center", inline: "center" });
        target.setAttribute("data-wbr-field-token", token);
        return true;
      }
    }
    return false;
  }, { labelText, token, prefer: options.prefer || [] }).catch(() => false);

  if (!found) return null;
  return page.locator(`[data-wbr-field-token="${token}"]`).first();
}

async function verifyControlValue(locator, expected, label) {
  const ok = await locator.evaluate((el, expected) => {
    const actual = "value" in el ? el.value : el.textContent;
    if (/^\d+$/.test(String(expected || "").trim())) {
      return String(actual || "").replace(/\D/g, "") === String(expected || "").replace(/\D/g, "");
    }
    return String(actual || "").trim() === String(expected || "").trim();
  }, String(expected)).catch(() => true);
  if (!ok) throw new Error(`${label} не заполнилось. WB не принял введенный текст.`);
}

async function chooseCategory(page, item) {
  await throwIfDraftLimit(page);
  const target = normalizeCategory(item);
  let locator = await firstVisible(page, selectors.fields.category);
  if (!locator) {
    locator = await fieldNearLabelLocator(page, "Категория", {
      prefer: ["input", "button", "rolebutton"]
    });
  }
  if (!locator) {
    const details = await visibleDiagnostics(page);
    throw new Error(
      `Категория не найдена. Видимые поля: ${details.inputs.slice(0, 12).join(" | ") || "нет"}`
    );
  }
  const shortTarget = target.split("/").map((part) => part.trim()).filter(Boolean).at(-1) || target;
  const currentCategory = String(await locator.inputValue().catch(() => "")).trim();
  if (normalizeComparable(currentCategory).includes(normalizeComparable(shortTarget))) {
    return;
  }

  let clicked = await clickDropdownOption(page, target, { exact: true })
    || await clickDropdownOption(page, shortTarget, { exact: true });
  if (clicked) {
    await page.waitForTimeout(700);
    await verifyCategorySelected(page, shortTarget);
    return;
  }

  await closeStaleFloatingDropdowns(page);
  await locator.click({ force: true });
  await page.waitForTimeout(900);

  log(`Category picker opened: ${JSON.stringify(await categoryDiagnostics(page))}`);

  clicked = await clickDropdownOption(page, target, { exact: true });
  if (!clicked) clicked = await clickDropdownOption(page, shortTarget, { exact: true });
  if (!clicked) clicked = await clickDropdownOption(page, shortTarget, { exact: false });
  if (!clicked) {
    await locator.fill(shortTarget).catch(() => {});
    await page.waitForTimeout(900);
    log(`Category search "${shortTarget}": ${JSON.stringify(await categoryDiagnostics(page))}`);
    clicked = await clickDropdownOption(page, shortTarget, { exact: true })
      || await clickDropdownOption(page, shortTarget, { exact: false });
  }
  if (!clicked) {
    await fillCategorySearch(page, shortTarget);
    clicked = await clickDropdownOption(page, shortTarget, { exact: true })
      || await clickDropdownOption(page, shortTarget, { exact: false });
  }
  if (!clicked) {
    await fillCategorySearch(page, target);
    clicked = await clickDropdownOption(page, shortTarget, { exact: true })
      || await clickDropdownOption(page, shortTarget, { exact: false });
  }
  if (!clicked) {
    const typedCategory = String(await locator.inputValue().catch(() => "")).trim();
    if (normalizeComparable(typedCategory).includes(normalizeComparable(shortTarget))) {
      clicked = true;
    }
  }
  if (!clicked) throw new Error(`Категория "${shortTarget}" не найдено в списке.`);
  await page.waitForTimeout(700);
  log(`Category after click: ${JSON.stringify(await categoryDiagnostics(page))}`);
  await verifyCategorySelected(page, shortTarget);
}

async function throwIfDraftLimit(page) {
  const blocked = await page.evaluate(() => {
    const text = String(document.body?.innerText || "");
    return /Пока не получится сохранять черновики/i.test(text)
      || /черновик[а-яё]* накопилось слишком много/i.test(text);
  }).catch(() => false);
  if (blocked) {
    throw new Error(
      "WB не принимает новое объявление: накопилось слишком много черновиков. " +
      "Нужно удалить пустые старые черновики и запустить очередь снова."
    );
  }
}

async function categoryDiagnostics(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const inputs = [...document.querySelectorAll("input")]
      .filter(visible)
      .map((el) => ({
        name: el.name || "",
        type: el.type || "",
        placeholder: el.placeholder || "",
        value: el.value || "",
        readOnly: el.readOnly,
        ariaExpanded: el.getAttribute("aria-expanded") || ""
      }));
    const options = [...document.querySelectorAll("li,[role='option'],[role='menuitem'],[class*='option'],[class*='listItem']")]
      .filter(visible)
      .map((el) => norm(el.innerText || el.textContent || ""))
      .filter(Boolean)
      .filter((value, index, all) => all.indexOf(value) === index)
      .slice(0, 30);
    return { inputs, options };
  }).catch(() => ({ inputs: [], options: [] }));
}

async function verifyCategorySelected(page, expected) {
  const ok = await page.evaluate((expected) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const categoryInput = document.querySelector("#adCategory,input[name='adCategory']");
    if (categoryInput) {
      const value = norm(categoryInput.value || categoryInput.getAttribute("value") || "");
      if (!value || value.includes("Выберите категорию")) return false;
      return value.includes(expected) || value.includes("Футбол");
    }
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    return [...document.querySelectorAll("input,button,[role='button'],div")]
      .filter(visible)
      .map((el) => norm(`${el.value || ""} ${el.innerText || el.textContent || ""}`))
      .some((text) => text.includes(expected) && !text.includes("Выберите категорию"));
  }, expected).catch(() => false);
  if (!ok) throw new Error(`Категория "${expected}" не выбралась: WB оставил поле пустым.`);
}

function normalizeCategory(item) {
  const raw = String(item.category || "").trim();
  if (raw.includes("/")) return raw;
  if (/футбол/i.test(raw)) return "Одежда / Футболки";
  if (/одежд/i.test(raw)) return "Одежда";
  const title = `${item.title || ""} ${item.description || ""}`.toLowerCase();
  if (title.includes("футбол")) return "Одежда / Футболки";
  if (title.includes("куртк") || title.includes("худи") || title.includes("рубаш") || title.includes("джинс")) return "Одежда";
  return raw || "Одежда";
}

async function selectCondition(page, condition) {
  if (!condition) return;
  const value = String(condition).trim();
  const direct = page.getByText(value, { exact: true }).first();
  if (await direct.count().catch(() => 0)) {
    await direct.click().catch(async () => {
      await direct.locator("xpath=ancestor::label[1]").click();
    });
    return;
  }
  await chooseFieldValue(page, selectors.fields.condition, value, "Состояние", { optional: true });
}

async function fillSizeV2(page, item) {
  const size = extractSize(item);
  if (!size) return;
  const wbSize = normalizeWbSize(size);
  if (await verifySizeSelectedV2(page, wbSize).catch(() => false)) {
    log(`Size already selected: ${wbSize}`);
    return;
  }

  if (page.url().startsWith("file:")) {
    const mockSize = page.locator("[name='size']").first();
    if (await mockSize.count()) {
      await mockSize.selectOption(size);
      return;
    }
  }

  await chooseSizeControlV3(page, wbSize);
  if (!(await verifySizeSelectedV2(page, wbSize))) {
    const screenshot = path.join(logsDir, `${safeName(item.id)}-size-not-selected-${Date.now()}.png`);
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`Размер ${size} не выбран на форме WB. Скрин: ${screenshot}`);
  }
}

async function chooseSizeControlV2(page, size) {
  const selectedByKeyboard = await chooseSizeByKeyboard(page, size);
  if (selectedByKeyboard) return;

  throw new Error(`Не удалось выбрать размер ${size} через клавиатуру.`);

  const selectedByLocator = await page.getByText(size, { exact: true }).last().click({ timeout: 5000 }).then(() => true).catch(() => false);
  const selected = selectedByLocator || await clickVisibleExactText(page, size, { label: "Размер", optional: true });
  if (selected) return;

  const typed = await page.evaluate((value) => {
    const input = document.activeElement?.tagName === "INPUT"
      ? document.activeElement
      : [...document.querySelectorAll("input")].find((el) => {
          const rect = el.getBoundingClientRect();
          const style = getComputedStyle(el);
          return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
        });
    if (!input) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    setter?.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }, size);
  if (typed) {
    await page.keyboard.press("Enter").catch(() => {});
    await page.waitForTimeout(500);
    await clickVisibleExactText(page, size, { label: "Размер", optional: true }).catch(() => false);
    return;
  }

  throw new Error(`Не удалось выбрать размер ${size}.`);
}

async function chooseSizeControlV3(page, size) {
  await saveSizeTrace(page, size, "before-click");
  const opened = await clickSizeSelectLocator(page);
  if (opened) {
    await saveSizeTrace(page, size, "dropdown-open");
    const items = page.locator(".mo-dropdown:visible li");
    await items.first().waitFor({ state: "visible", timeout: 15000 }).catch(() => {});
    const texts = await items.allTextContents().catch(() => []);
    const matching = texts
      .map((text, index) => ({ text: String(text || "").trim(), index }))
      .filter((item) => item.text.toLowerCase() === String(size).trim().toLowerCase());
    if (matching.length === 1) {
      await items.nth(matching[0].index).click({ force: true });
      await page.waitForTimeout(300);
      await saveSizeTrace(page, size, "after-select");
      if (await verifySizeSelectedV2(page, size).catch(() => false)) {
        log(`Size selected: ${size}`);
        return;
      }
    }
  }

  await saveSizeOpenDiagnostics(page, size).catch(() => {});
  const screenshot = path.join(logsDir, `size-select-failed-${safeName(size)}-${Date.now()}.png`);
  await page.screenshot({ path: screenshot, fullPage: false }).catch(() => {});
  throw new Error(`Не удалось выбрать размер ${size}. Скрин: ${screenshot}`);
}

async function saveSizeTrace(page, size, stage) {
  if (!traceSize) return;
  const screenshot = path.join(logsDir, `size-trace-${safeName(size)}-${stage}-${Date.now()}.png`);
  await page.screenshot({ path: screenshot, fullPage: false }).catch(() => {});
  log(`Size trace ${stage}: ${screenshot}`);
}

async function clickOpenDropdownValue(page, value) {
  return page.evaluate((targetValue) => {
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialog = [...document.querySelectorAll("[role='dialog']")].filter(visible).at(-1);
    const roots = [...document.querySelectorAll(
      ".mo-dropdown, [role='listbox'], [role='menu'], [class*='selectMenu'], [class*='dropdown'], [data-floating-ui-portal]"
    )].filter((root) => visible(root) && root !== dialog && !root.contains(dialog));
    const sizeToken = /^(?:\d?XL|XS|XXS|S|M|L)$/i.test(targetValue)
      ? new RegExp(`(^|[\\s/(),;-])${targetValue.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|[\\s/(),;-])`, "i")
      : null;
    const candidates = roots
      .flatMap((root) => [...root.querySelectorAll("button,[role='option'],[role='menuitem'],li,div,span")])
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => text === targetValue || (sizeToken && sizeToken.test(text) && text.length <= 80))
      .sort((a, b) => {
        const aClickable = a.el.matches("button,[role='option'],[role='menuitem'],li") ? 0 : 1;
        const bClickable = b.el.matches("button,[role='option'],[role='menuitem'],li") ? 0 : 1;
        return aClickable - bClickable || a.text.length - b.text.length;
      });
    const target = candidates[0]?.el;
    if (!target) return false;
    target.scrollIntoView({ block: "nearest", inline: "nearest" });
    target.click();
    return true;
  }, String(value)).catch(() => false);
}

async function closeStaleFloatingDropdowns(page) {
  return page.evaluate(() => {
    const portals = [...document.querySelectorAll("[data-floating-ui-portal]")];
    let removed = 0;
    for (const portal of portals) {
      // The advert form itself also lives in a floating-ui portal. Remove only
      // detached dropdown portals; deleting the dialog portal destroys the form.
      if (portal.querySelector("[role='dialog']")) continue;
      if (!portal.querySelector(".mo-dropdown,[role='listbox'],[class*='dropdown'],[class*='selectMenu']")) continue;
      portal.remove();
      removed += 1;
    }
    return removed;
  }).catch(() => 0);
}

async function clickSizeSelectLocator(page) {
  const dialog = page.locator("[role='dialog']:visible").last();
  const select = dialog.locator(".mo-select").filter({ hasText: "Выберите размер" }).first();
  if (await select.count().catch(() => 0) !== 1) {
    log("Size select not found by its placeholder");
    return false;
  }

  const combobox = select.locator("button[role='combobox']");
  if (await combobox.count().catch(() => 0) !== 1) {
    log("Size combobox is missing inside the matched size field");
    return false;
  }
  await select.scrollIntoViewIfNeeded();
  await page.waitForTimeout(250);
  const wrapper = select.locator(".mo-select__wrapper");
  let opened = await wrapper.evaluate((element) => element.dataset.state === "open").catch(() => false);
  if (opened) return true;
  // The semantic combobox is intentionally zero-width and Playwright refuses
  // a coordinate click. Native button.click() still runs the exact React event.
  await combobox.evaluate((button) => button.click());
  opened = await wrapper.evaluate((element) => element.dataset.state === "open").catch(() => false);
  if (!opened) {
    await wrapper.evaluate((element) => element.click()).catch(() => {});
    await page.waitForTimeout(300);
    opened = await wrapper.evaluate((element) => element.dataset.state === "open").catch(() => false);
  }
  if (!opened) {
    // Verified against the live WB form: this combobox opens on Space while
    // mouse/click events are ignored after the characteristics dialog closes.
    await combobox.focus().catch(() => {});
    await combobox.press("Space").catch(() => {});
    await page.waitForTimeout(400);
    opened = await wrapper.evaluate((element) => element.dataset.state === "open").catch(() => false);
  }
  if (!opened) {
    const box = await wrapper.boundingBox().catch(() => null);
    if (box) {
      // A trusted mouse event is required by the current WB select component
      // in the fully populated form. Click the chevron area, which is stable
      // across desktop and laptop resolutions because it is relative to the field.
      await page.mouse.click(box.x + box.width - 24, box.y + box.height / 2);
      await page.waitForTimeout(400);
      opened = await wrapper.evaluate((element) => element.dataset.state === "open").catch(() => false);
    }
  }
  if (!opened) log("Size select did not open after native button and wrapper clicks");
  return opened;
}

async function chooseSizeByKeyboard(page, size) {
  await page.keyboard.press("Tab").catch(() => {});
  await page.waitForTimeout(200);
  await page.keyboard.press("Enter").catch(() => {});
  await page.waitForTimeout(500);
  await page.keyboard.type(size, { delay: 40 }).catch(() => {});
  await page.waitForTimeout(200);
  await page.keyboard.press("Enter").catch(() => {});
  await page.waitForTimeout(500);
  return verifySizeSelectedV2(page, size).catch(() => false);
}

async function clickSizeWrapperByMouse(page) {
  const point = await page.evaluate(() => {
    const choose = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const candidates = [...document.querySelectorAll("div")]
      .filter((el) => String(el.className || "").includes("mo-select__wrapper"))
      .filter((el) => norm(el.innerText || el.textContent || "").includes(choose));
    const target = candidates[candidates.length - 1];
    if (!target) return null;
    const rect = target.getBoundingClientRect();
    return { x: rect.right - 18, y: rect.top + rect.height / 2 };
  });
  if (!point) return false;
  await page.mouse.click(point.x, point.y);
  return true;
}

async function saveSizeOpenDiagnostics(page, size) {
  const base = path.join(logsDir, `size-open-${safeName(size)}-${Date.now()}`);
  await page.screenshot({ path: `${base}.png`, fullPage: false }).catch(() => {});
  const details = await page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialog = [...document.querySelectorAll("[role='dialog']")].filter(visible).at(-1);
    const select = dialog
      ? [...dialog.querySelectorAll(".mo-select")].find((el) =>
          visible(el) && String(el.innerText || el.textContent || "").includes("\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440"))
      : null;
    const rect = select?.getBoundingClientRect();
    const points = rect
      ? [
          { name: "center", x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
          { name: "arrow", x: rect.right - 22, y: rect.top + rect.height / 2 },
        ]
      : [];
    const pointStacks = points.map((point) => ({
      ...point,
      stack: document.elementsFromPoint(point.x, point.y).slice(0, 8).map((el) => ({
        tag: el.tagName.toLowerCase(),
        className: String(el.className || "").slice(0, 160),
        text: String(el.innerText || el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 80),
      })),
    }));
    const reactHandlers = [];
    for (let el = select; el && reactHandlers.length < 12; el = el.parentElement) {
      for (const key of Object.keys(el).filter((key) => key.startsWith("__reactProps$"))) {
        const props = el[key] || {};
        reactHandlers.push({
          tag: el.tagName.toLowerCase(),
          className: String(el.className || "").slice(0, 160),
          handlers: Object.keys(props).filter((name) => /^on[A-Z]/.test(name)),
          role: props.role || "",
          tabIndex: props.tabIndex ?? null,
        });
      }
    }
    const options = [...document.querySelectorAll("button,a,[role='button'],div,span,label")]
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          className: String(el.className || "").slice(0, 120),
          text: (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 80),
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) }
        };
      })
      .filter((entry) => entry.text && entry.text.length <= 40)
      .slice(-120);
    return {
      selectOuterHtml: String(select?.outerHTML || "").slice(0, 12000),
      activeElement: String(document.activeElement?.outerHTML || "").slice(0, 2000),
      pointStacks,
      reactHandlers,
      options,
    };
  }).catch(() => []);
  fs.writeFileSync(`${base}.json`, JSON.stringify(details, null, 2), "utf8");
}

async function openSizeDropdownV2(page) {
  const scrollSteps = [0, 180, 360, 540, 720, 900, 1120, 1360];
  for (const top of scrollSteps) {
    await page.mouse.move(680, 720).catch(() => {});
    if (top > 0) {
      await page.mouse.wheel(0, 260).catch(() => {});
      await page.waitForTimeout(180);
    }
    const opened = await page.evaluate((scrollTop) => {
      const label = "\u0420\u0430\u0437\u043c\u0435\u0440";
      const choose = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
      const enter = "\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
      const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
      const visible = (el) => {
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
      };
      const scrollables = [document.scrollingElement, ...document.querySelectorAll("div,section,main")]
        .filter(Boolean)
        .filter((el) => el.scrollHeight > el.clientHeight + 40);
      for (const el of scrollables) {
        el.scrollTop = Math.min(scrollTop, el.scrollHeight);
      }

      const controls = [...document.querySelectorAll("button,[role='button'],input,div,span")]
        .filter(visible)
        .map((el) => ({ el, text: norm(`${el.innerText || el.textContent || ""} ${el.placeholder || ""} ${el.getAttribute("aria-label") || ""}`) }))
        .filter(({ text }) => text.includes(choose) || text.includes(enter));
      const direct = controls.sort((a, b) => a.text.length - b.text.length)[0];
      if (direct) {
        direct.el.scrollIntoView({ block: "center", inline: "center" });
        direct.el.click();
        return true;
      }

      const blocks = [...document.querySelectorAll("div,label,section")]
        .filter(visible)
        .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
        .filter(({ text }) => text.includes(label) && text.includes(choose));
      const block = blocks.sort((a, b) => a.text.length - b.text.length)[0];
      if (!block) return false;
      block.el.scrollIntoView({ block: "center", inline: "center" });
      const inner = [...block.el.querySelectorAll("button,[role='button'],input,div,span")]
        .filter(visible)
        .find((el) => norm(`${el.innerText || el.textContent || ""} ${el.placeholder || ""}`).includes(choose));
      (inner || block.el).click();
      return true;
    }, top);
    if (opened) return true;
    await page.waitForTimeout(150);
  }
  return false;
}

async function verifySizeSelectedV2(page, size) {
  await page.waitForTimeout(300);
  return page.evaluate((value) => {
    const choose = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const enter = "\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialog = [...document.querySelectorAll("[role='dialog']")].filter(visible).at(-1);
    if (!dialog) return false;
    const selects = [...dialog.querySelectorAll(".mo-select")].filter(visible);
    for (const select of selects) {
      const text = norm(select.innerText || select.textContent || "");
      if (text.includes(choose) || text.includes(enter)) continue;
      if (text === value || text.split(/\s+/).includes(value)) return true;
    }
    return false;
  }, size);
}

async function fillSize(page, item) {
  const size = extractSize(item);
  if (!size) return;

  await page.getByText("Размер", { exact: true }).first().scrollIntoViewIfNeeded().catch(() => {});
  const filled = await page.evaluate((value) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const inputs = [...document.querySelectorAll("input")]
      .filter(visible)
      .filter((input) => /размер/i.test(norm(`${input.name || ""} ${input.placeholder || ""} ${input.closest("label")?.innerText || ""}`)));
    const input = inputs[0];
    if (!input) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    input.blur();
    return true;
  }, size);

  if (!filled) {
    await chooseSizeControl(page, size);
    return;
  }
  await page.waitForTimeout(400);
}

async function chooseSizeControl(page, size) {
  const opened = await page.evaluate(() => {
    const norm = (text) => String(text || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("button,[role='button'],div,input")]
      .filter(visible)
      .filter((el) => /выберите размер|укажите размер|размер/i.test(norm(`${el.innerText || ""} ${el.textContent || ""} ${el.placeholder || ""}`)));
    const target = candidates.find((el) => /выберите размер|укажите размер/i.test(norm(`${el.innerText || ""} ${el.textContent || ""} ${el.placeholder || ""}`))) || candidates[0];
    if (!target) return false;
    target.click();
    return true;
  });
  if (!opened) throw new Error(`Поле размера не найдено для значения ${size}.`);
  await page.waitForTimeout(700);

  const selected = await clickVisibleExactText(page, size, { label: "Размер", optional: true });
  if (selected) return;

  const active = await page.locator("input:visible").last();
  if (await active.count().catch(() => 0)) {
    await active.fill(size).catch(() => {});
    await page.keyboard.press("Enter").catch(() => {});
    await page.waitForTimeout(500);
    return;
  }

  throw new Error(`Не удалось выбрать размер ${size}.`);
}

function extractSize(item) {
  const source = `${item.size || ""} ${item.characteristics || ""} ${item.description || ""} ${item.title || ""}`;
  const match = source.match(/размер\s*[:\-]?\s*(XXS|XS|S|M|L|XL|2XL|[0-9]{2,3})/i);
  return match?.[1]?.trim() || "";
}

function normalizeWbSize(size) {
  return String(size || "").trim().toUpperCase();
}

async function setCheckbox(page, selectorList, rawValue, options = {}) {
  if (rawValue === "" || rawValue == null) return;
  const desired = ["true", "1", "yes", "да", "y"].includes(String(rawValue).trim().toLowerCase());
  const locator = await firstVisible(page, selectorList, { includeHidden: true });
  if (!locator) {
    if (options.optional) return;
    throw new Error("Чекбокс не найден. Обновите selectors.json.");
  }

  const tagName = await locator.evaluate((el) => el.tagName.toLowerCase()).catch(() => "");
  const type = await locator.getAttribute("type").catch(() => "");
  if (tagName === "input" && type === "checkbox") {
    const checked = await locator.isChecked();
    if (checked !== desired) await locator.setChecked(desired);
    return;
  }

  const ariaChecked = await locator.getAttribute("aria-checked").catch(() => null);
  if ((ariaChecked === "true") !== desired) await locator.click();
}

async function choosePickupPoint(page, pickupPoint) {
  if (!pickupPoint) return;
  if (page.url().startsWith("file:")) {
    const field = page.locator("[name='pickup_point']").first();
    if (await field.count()) await field.fill(String(pickupPoint));
    return;
  }
  const descriptionBefore = await page.locator("textarea#adDescription").inputValue().catch(() => "");
  await scrollSaleModalToBottom(page);
  const trigger = page.locator("button:has-text('Выберите пункт')").first();
  if (!(await trigger.count().catch(() => 0))) throw new Error("Кнопка выбора ПВЗ не найдена.");
  await trigger.click({ force: true });
  await page.getByText("Выберите пункт выдачи", { exact: true }).last().waitFor({ state: "visible", timeout: 5000 });

  const addressNodes = page.locator("[class*='addressItemNameText']");
  const addressTexts = await addressNodes.allTextContents().catch(() => []);
  const compact = (value) => String(value || "").toLowerCase().replace(/[.,]/g, "").replace(/\s+/g, "");
  const wantedCompact = compact(pickupPoint);
  const addressIndex = addressTexts.findIndex((text) => compact(text) === wantedCompact);
  const addressLabel = addressIndex >= 0 ? addressNodes.nth(addressIndex).locator("xpath=ancestor::label[1]") : null;
  const selected = Boolean(addressLabel && await addressLabel.count().catch(() => 0));

  if (!selected) {
    const screenshot = path.join(logsDir, `pickup-not-found-${Date.now()}.png`);
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`ПВЗ "${pickupPoint}" не найден в открытом окне WB. Случайный ПВЗ не выбираю. Скрин: ${screenshot}`);
  }

  await addressLabel.scrollIntoViewIfNeeded().catch(() => {});
  await addressLabel.click({ force: true });
  const radio = addressLabel.locator("input[type='radio']").first();
  const radioSelected = await radio.isChecked().catch(() => false);
  if (!radioSelected) throw new Error(`ПВЗ "${pickupPoint}" найден, но radio-кнопка WB не включилась.`);
  await page.waitForTimeout(500);
  await confirmPickupPoint(page);
  await page.waitForTimeout(900);

  const descriptionAfter = await page.locator("textarea#adDescription").inputValue().catch(() => "");
  if (descriptionAfter !== descriptionBefore) throw new Error("Выбор ПВЗ изменил описание. Публикация остановлена.");
  const chooseStillVisible = await page.getByRole("button", { name: "Выберите пункт", exact: true }).isVisible().catch(() => false);
  if (chooseStillVisible) throw new Error(`WB не подтвердил ПВЗ "${pickupPoint}" в основной форме.`);
}

async function inspectPickupForm(page, item) {
  await scrollSaleModalToBottom(page);
  const trigger = page.locator("button:has-text('Выберите пункт')").first();
  if (!(await trigger.count().catch(() => 0))) throw new Error("Диагностика ПВЗ: кнопка выбора не найдена.");
  await trigger.click({ force: true });
  await page.waitForTimeout(1500);
  const data = await page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const nodes = [...document.querySelectorAll("input,textarea,[contenteditable='true'],button,[role='button']")]
      .filter(visible)
      .map((el) => ({
        tag: el.tagName.toLowerCase(),
        type: el.getAttribute("type") || "",
        name: el.getAttribute("name") || "",
        placeholder: el.getAttribute("placeholder") || "",
        ariaLabel: el.getAttribute("aria-label") || "",
        className: String(el.className || "").slice(0, 220),
        value: "value" in el ? String(el.value || "") : "",
        text: norm(el.innerText || el.textContent || "").slice(0, 300)
      }));
    const addresses = [...document.querySelectorAll("[class*='addressItemNameText']")].filter(visible).map((el) => {
      const ancestors = [];
      let current = el;
      for (let depth = 0; current && depth < 7; depth += 1, current = current.parentElement) {
        ancestors.push({
          depth,
          tag: current.tagName.toLowerCase(),
          className: String(current.className || "").slice(0, 260),
          role: current.getAttribute("role") || "",
          ariaChecked: current.getAttribute("aria-checked") || "",
          text: norm(current.innerText || current.textContent || "").slice(0, 500)
        });
      }
      return { text: norm(el.innerText || el.textContent || ""), ancestors, html: el.parentElement?.parentElement?.outerHTML?.slice(0, 20000) || "" };
    });
    const portal = [...document.querySelectorAll("[data-floating-ui-portal], [role='dialog'], .mo-modal__paper")]
      .filter(visible)
      .sort((a, b) => (a.getBoundingClientRect().width * a.getBoundingClientRect().height) - (b.getBoundingClientRect().width * b.getBoundingClientRect().height))
      .at(-1);
    return { nodes, addresses, bodyText: norm(document.body?.innerText || "").slice(-12000), html: portal?.outerHTML?.slice(0, 800000) || "" };
  });
  const base = path.join(logsDir, `pickup-inspection-${safeName(item.id)}-${Date.now()}`);
  fs.writeFileSync(`${base}.json`, JSON.stringify(data, null, 2), "utf8");
  fs.writeFileSync(`${base}.html`, data.html || "", "utf8");
  await page.screenshot({ path: `${base}.png`, fullPage: true }).catch(() => {});
  return `Диагностика ПВЗ сохранена: ${base}.json`;
}

async function setAcceptRulesV2(page, rawValue) {
  if (rawValue === "" || rawValue == null) return;
  const desired = ["true", "1", "yes", "да", "y"].includes(String(rawValue).trim().toLowerCase());
  if (!desired) return;

  await scrollSaleModalToBottom(page);

  const clicked = await clickAcceptRulesControl(page);
  if (!clicked) {
    await forceCheckAcceptRulesInput(page);
  }

  const checked = await page.evaluate(() => {
    const phrases = [
      "\u041d\u0430\u0436\u0438\u043c\u0430\u044f",
      "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438"
    ];
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const legal = [...document.querySelectorAll("label, div, span, p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => phrases.some((phrase) => text.includes(phrase)))
      .sort((a, b) => a.text.length - b.text.length)[0]?.el;
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    if (legal && inputs.length) {
      const legalRect = legal.getBoundingClientRect();
      const nearest = inputs
        .map((input) => ({ input, rect: input.getBoundingClientRect() }))
        .sort((a, b) => Math.abs(a.rect.top - legalRect.top) - Math.abs(b.rect.top - legalRect.top))[0]?.input;
      if (nearest?.checked) return true;
    }
    return [...document.querySelectorAll("[aria-checked='true'], [class*='checked'], [class*='Checked']")]
      .filter(visible)
      .some((el) => {
        const text = norm(el.closest("label, div")?.innerText || el.closest("label, div")?.textContent || "");
        return phrases.some((phrase) => text.includes(phrase));
      });
  });

  if (!checked) {
    const screenshot = path.join(logsDir, `accept-rules-not-checked-${Date.now()}.png`);
    const diagnostics = path.join(logsDir, `accept-rules-not-checked-${Date.now()}.json`);
    await saveCheckboxDiagnostics(page, diagnostics).catch(() => {});
    await page.screenshot({ path: screenshot, fullPage: true }).catch(() => {});
    throw new Error(`Чекбокс соглашения с правилами не включился. Скрин: ${screenshot}. Диагностика: ${diagnostics}`);
  }
}

async function clickAcceptRulesControl(page) {
  const rulesText = "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438";
  const rulesLocator = page.getByText(rulesText, { exact: false }).last();
  const rulesVisible = await rulesLocator.count().then((count) => count > 0).catch(() => false);
  if (rulesVisible) {
    await rulesLocator.scrollIntoViewIfNeeded().catch(() => {});
    await page.waitForTimeout(300);
  }

  const clickedNearText = await page.evaluate(() => {
    const phrases = [
      "\u041d\u0430\u0436\u0438\u043c\u0430\u044f",
      "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438"
    ];
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const legal = [...document.querySelectorAll("label, div, span, p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => phrases.some((phrase) => text.includes(phrase)))
      .sort((a, b) => a.text.length - b.text.length)[0]?.el;
    if (!legal) return false;

    legal.scrollIntoView({ block: "center", inline: "center" });
    const labels = [legal.closest("label"), legal.querySelector("label")].filter(Boolean);
    for (const label of labels) {
      label.click();
      return true;
    }

    const legalRect = legal.getBoundingClientRect();
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    const nearest = inputs
      .map((input) => ({ input, rect: input.getBoundingClientRect() }))
      .sort((a, b) => Math.abs(a.rect.top - legalRect.top) - Math.abs(b.rect.top - legalRect.top))[0]?.input;
    if (nearest) {
      nearest.click();
      return true;
    }
    return false;
  }).catch(() => false);
  await page.waitForTimeout(400);
  if (await isAcceptRulesChecked(page)) return true;

  const clickedLastInput = await clickLastCheckboxInput(page);
  if (clickedLastInput) {
    await page.waitForTimeout(400);
    if (await isAcceptRulesChecked(page)) return true;
  }

  if (rulesVisible) {
    const box = await rulesLocator.boundingBox().catch(() => null);
    if (box) {
      await page.mouse.click(Math.max(6, box.x - 24), box.y + Math.min(14, box.height / 2));
      await page.waitForTimeout(400);
      if (await isAcceptRulesChecked(page)) return true;
    }
  }

  return clickedNearText || clickedLastInput;
}

async function clickLastCheckboxInput(page) {
  const boxes = page.locator("input[type='checkbox']");
  const count = await boxes.count().catch(() => 0);
  if (!count) return false;
  const target = boxes.nth(count - 1);
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await page.waitForTimeout(200);
  await target.click({ force: true, timeout: 3000 }).catch(async () => {
    const box = await target.boundingBox().catch(() => null);
    if (!box) throw new Error("Accept rules checkbox has no bounding box.");
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  });
  return true;
}

async function isAcceptRulesChecked(page) {
  return page.evaluate(() => {
    const phrases = [
      "\u041d\u0430\u0436\u0438\u043c\u0430\u044f",
      "\u043f\u0440\u0430\u0432\u0438\u043b\u0430\u043c\u0438 \u0442\u043e\u0440\u0433\u043e\u0432\u043e\u0439 \u043f\u043b\u043e\u0449\u0430\u0434\u043a\u0438"
    ];
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const legal = [...document.querySelectorAll("label, div, span, p")]
      .filter(visible)
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ text }) => phrases.some((phrase) => text.includes(phrase)))
      .sort((a, b) => a.text.length - b.text.length)[0]?.el;
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    if (legal && inputs.length) {
      const legalRect = legal.getBoundingClientRect();
      const nearest = inputs
        .map((input) => ({ input, rect: input.getBoundingClientRect() }))
        .sort((a, b) => Math.abs(a.rect.top - legalRect.top) - Math.abs(b.rect.top - legalRect.top))[0]?.input;
      if (nearest?.checked) return true;
    }
    return Boolean(inputs.at(-1)?.checked);
  }).catch(() => false);
}

async function forceCheckAcceptRulesInput(page) {
  await page.evaluate(() => {
    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    const target = inputs[inputs.length - 1];
    if (!target) return false;
    const checkedSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
    checkedSetter?.call(target, true);
    target.checked = true;
    target.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
    checkedSetter?.call(target, true);
    target.checked = true;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }).catch(() => false);
  await page.waitForTimeout(300);
}

async function scrollSaleModalToBottom(page) {
  await page.evaluate(() => {
    const all = [...document.querySelectorAll("*")];
    const scrollables = all.filter((el) => {
      const style = getComputedStyle(el);
      return /(auto|scroll)/.test(`${style.overflowY} ${style.overflow}`) && el.scrollHeight > el.clientHeight + 20;
    });
    for (const el of scrollables) {
      el.scrollTop = el.scrollHeight;
    }
    const publish = all.find((el) => String(el.innerText || el.textContent || "").trim() === "\u041e\u043f\u0443\u0431\u043b\u0438\u043a\u043e\u0432\u0430\u0442\u044c");
    publish?.scrollIntoView({ block: "center", inline: "center" });
  }).catch(() => {});
  await page.waitForTimeout(500);
  await page.mouse.move(680, 760).catch(() => {});
  await page.mouse.wheel(0, 900).catch(() => {});
  await page.waitForTimeout(300);
}

async function saveCheckboxDiagnostics(page, filePath) {
  const data = await page.evaluate(() => {
    return [...document.querySelectorAll("input[type='checkbox']")].map((input, index) => {
      const rect = input.getBoundingClientRect();
      const host = input.closest("label, div");
      return {
        index,
        checked: input.checked,
        disabled: input.disabled,
        ariaChecked: input.getAttribute("aria-checked"),
        rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
        text: String(host?.innerText || host?.textContent || "").trim().replace(/\s+/g, " ").slice(0, 300),
        html: input.outerHTML.slice(0, 500)
      };
    });
  });
  await fs.writeFile(filePath, JSON.stringify(data, null, 2), "utf8");
}

async function setAcceptRules(page, rawValue) {
  if (rawValue === "" || rawValue == null) return;
  const desired = ["true", "1", "yes", "да", "y"].includes(String(rawValue).trim().toLowerCase());
  if (!desired) return;

  const checked = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    };

    const inputs = [...document.querySelectorAll("input[type='checkbox']")];
    const byLegalText = [...document.querySelectorAll("label, div, span, p")]
      .find((el) => visible(el) && /нажимая|правилами торговой площадки/i.test(norm(el.innerText || el.textContent || "")));

    let target = null;
    if (byLegalText) {
      target = byLegalText.querySelector("input[type='checkbox']");
      target ||= byLegalText.closest("label")?.querySelector("input[type='checkbox']");
      target ||= byLegalText.parentElement?.querySelector("input[type='checkbox']");
    }
    target ||= inputs[inputs.length - 1];

    if (target) {
      if (!target.checked) target.click();
      return target.checked || true;
    }

    const label = byLegalText?.closest("label") || byLegalText;
    if (label) {
      label.click();
      return true;
    }

    return false;
  });

  if (!checked) throw new Error("Чекбокс согласия с правилами не найден.");
}

async function confirmPickupPoint(page) {
  const clicked = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const buttons = [...document.querySelectorAll("button")].filter(visible);
    const target = buttons.find((button) => /^отправлю отсюда$/i.test(norm(button.innerText || button.textContent || "")));
    if (!target) return false;
    target.click();
    return true;
  });
  if (!clicked) throw new Error("Кнопка подтверждения ПВЗ \"Отправлю отсюда\" не найдена.");
  await page.waitForFunction(() => {
    const text = document.body?.innerText || "";
    return !/Выберите пункт выдачи/i.test(text) || !/Отправлю отсюда/i.test(text);
  }, null, { timeout: 7000 }).catch(() => {});
}

async function uploadPhotos(page, selectorList, rawPhotos) {
  if (!rawPhotos) return;
  const photoRefs = rawPhotos
    .split(",")
    .map((photo) => photo.trim())
    .filter(Boolean);

  const files = [];
  for (const [index, photo] of photoRefs.entries()) {
    const source = /^https?:\/\//i.test(photo) ? await downloadRemotePhoto(photo, index) : path.resolve(rootDir, photo);
    files.push(prepareLocalPhotoForUpload(source, index));
  }
  log(`Prepared ${files.length} photo(s) for upload.`);

  const missing = files.filter((file) => !fs.existsSync(file));
  if (missing.length) throw new Error(`Фото не найдены: ${missing.join(", ")}`);
  if (files.length < 3 || files.length > 30) throw new Error(`WB требует от 3 до 30 фото. Сейчас: ${files.length}.`);

  const locator = await firstVisible(page, selectorList, { includeHidden: true });
  if (!locator) throw new Error("Поле загрузки фото не найдено.");
  let lastError = null;
  for (let attempt = 1; attempt <= 2; attempt += 1) {
    try {
      if (attempt > 1) {
        await locator.setInputFiles([]).catch(() => {});
        await page.waitForTimeout(700);
      }
      await locator.setInputFiles(files);
      await waitForPhotoUpload(page, files.length);
      if (attempt > 1) log(`Photo upload succeeded on retry ${attempt}`);
      return;
    } catch (error) {
      lastError = error;
      log(`Photo upload attempt ${attempt} failed: ${error?.message || error}`);
      if (attempt < 2) await page.waitForTimeout(1500);
    }
  }
  throw lastError || new Error("Не удалось загрузить фото в WB.");
}

async function downloadRemotePhoto(url, index = 0) {
  const filename = `${crypto.createHash("sha1").update(`${url}:${index}:source`).digest("hex")}${imageExtFromUrl(url)}`;
  const targetPath = path.join(remotePhotosDir, filename);
  if (fs.existsSync(targetPath) && fs.statSync(targetPath).size > 0) return targetPath;

  const { buffer, status } = await fetchImageWithTimeout(url, 30_000);
  if (status < 200 || status >= 300) throw new Error(`Не удалось скачать фото ${url}: HTTP ${status}`);
  if (!buffer.length) throw new Error(`Фото ${url} пустое`);
  fs.writeFileSync(targetPath, buffer);
  return targetPath;
}

function prepareLocalPhotoForUpload(sourcePath, index = 0) {
  const stats = fs.statSync(sourcePath);
  const fingerprint = `${sourcePath}:${stats.size}:${stats.mtimeMs}:${index}`;
  const filename = `${crypto.createHash("sha1").update(fingerprint).digest("hex")}.jpg`;
  const targetPath = path.join(remotePhotosDir, filename);
  if (fs.existsSync(targetPath) && fs.statSync(targetPath).size > 0) return targetPath;

  normalizeImageForUpload(sourcePath, targetPath);
  if (!fs.existsSync(targetPath) || fs.statSync(targetPath).size === 0) {
    throw new Error(`Не удалось подготовить фото для WB: ${sourcePath}`);
  }
  return targetPath;
}

async function fetchImageWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { signal: controller.signal });
    const buffer = Buffer.from(await response.arrayBuffer());
    return { status: response.status, buffer };
  } catch (error) {
    if (error.name === "AbortError") throw new Error(`Таймаут скачивания фото ${url}`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function imageExtFromUrl(url) {
  try {
    const ext = path.extname(new URL(url).pathname).toLowerCase();
    if ([".jpg", ".jpeg", ".png", ".webp"].includes(ext)) return ext === ".jpeg" ? ".jpg" : ext;
  } catch {}
  return ".jpg";
}

function normalizeImageForUpload(sourcePath, targetPath) {
  const script = `
Add-Type -AssemblyName System.Drawing
$src = [System.IO.Path]::GetFullPath('${escapePowerShellSingleQuoted(sourcePath)}')
$dst = [System.IO.Path]::GetFullPath('${escapePowerShellSingleQuoted(targetPath)}')
$img = [System.Drawing.Image]::FromFile($src)
try {
  $minW = 900
  $minH = 1200
  $scale = [Math]::Max($minW / $img.Width, $minH / $img.Height)
  if ($scale -lt 1.0) { $scale = 1.0 }
  $w = [Math]::Max($minW, [int][Math]::Round($img.Width * $scale))
  $h = [Math]::Max($minH, [int][Math]::Round($img.Height * $scale))
  $bmp = New-Object System.Drawing.Bitmap($w, $h)
  try {
    $graphics = [System.Drawing.Graphics]::FromImage($bmp)
    try {
      $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
      $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
      $graphics.DrawImage($img, 0, 0, $w, $h)
    } finally {
      $graphics.Dispose()
    }
    $codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' } | Select-Object -First 1
    $params = New-Object System.Drawing.Imaging.EncoderParameters(1)
    $params.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter([System.Drawing.Imaging.Encoder]::Quality, [int64]95)
    $bmp.Save($dst, $codec, $params)
  } finally {
    if ($bmp) { $bmp.Dispose() }
  }
} finally {
  $img.Dispose()
}
`;
  const result = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], {
    encoding: "utf8",
    windowsHide: true,
    timeout: 30_000
  });
  if (result.status !== 0 || !fs.existsSync(targetPath)) {
    const details = [result.stderr, result.stdout].filter(Boolean).join(" ").trim();
    throw new Error(`Не удалось изменить разрешение фото ${sourcePath}${details ? `: ${details}` : ""}`);
  }
}

function escapePowerShellSingleQuoted(value) {
  return String(value).replaceAll("'", "''");
}

async function clickFirst(page, selectorList, label = "Элемент", options = {}) {
  await clearBlockingPromotionOverlays(page);
  const locator = await firstVisible(page, selectorList);
  if (!locator) {
    if (options.optional) return false;
    throw new Error(`${label} не найдена.`);
  }
  try {
    await locator.click({ timeout: 5000 });
  } catch (error) {
    const cleared = await clearBlockingPromotionOverlays(page);
    if (!cleared) throw error;
    await locator.click({ timeout: 5000 });
  }
  return true;
}

async function clearBlockingPromotionOverlays(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const overlays = [...document.querySelectorAll(
      "[class*='promotionOnboardingOverlay'], [class*='promotion-onboarding-overlay']"
    )].filter(visible);

    for (const overlay of overlays) {
      overlay.style.setProperty("pointer-events", "none", "important");
      overlay.setAttribute("aria-hidden", "true");
    }
    return overlays.length;
  }).catch(() => 0);
}

async function verifySubmission(page, item) {
  await page.waitForTimeout(9000);
  const base = path.join(logsDir, `${safeName(item.id)}-post-submit-${Date.now()}`);
  const screenshotPath = `${base}.png`;
  const jsonPath = `${base}.json`;
  await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});

  const state = await page.evaluate(() => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const text = norm(document.body?.innerText || "");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const buttons = [...document.querySelectorAll("button")]
      .filter(visible)
      .map((el) => norm(el.innerText || el.textContent || ""))
      .filter(Boolean);
    const inputs = [...document.querySelectorAll("input,textarea")]
      .filter(visible)
      .map((el) => norm(`${el.getAttribute("name") || ""} ${el.getAttribute("placeholder") || ""} ${el.value || ""}`))
      .filter(Boolean);
    return { url: location.href, title: document.title, text, buttons, inputs };
  });

  fs.writeFileSync(jsonPath, JSON.stringify({ ...state, networkEvents: networkEvents.slice(-30) }, null, 2), "utf8");
  log(`Post-submit diagnostics saved: ${screenshotPath}`);

  const submitError = [...networkEvents].reverse().find((event) =>
    /resale-api\.wildberries\.ru\/api\/v1\/listings\/external/i.test(event.url) &&
    event.status >= 400
  );
  if (submitError) {
    let message = "";
    try {
      const payload = JSON.parse(submitError.body || "{}");
      message = payload.error_text || payload.message || "";
    } catch {}
    throw new Error(message || `WB отклонил публикацию: HTTP ${submitError.status}`);
  }

  const text = state.text.toLowerCase();
  const stillOnForm =
    text.includes("объявление о продаже") ||
    state.buttons.some((button) => /опубликовать/i.test(button)) ||
    state.inputs.some((input) => /adname|что прода/i.test(input));
  if (stillOnForm) {
    const visibleText = state.text.slice(0, 1200);
    throw new Error(`WB не подтвердил публикацию после клика. Форма осталась открыта. Скрин: ${screenshotPath}. Текст страницы: ${visibleText}`);
  }

  const submitSuccess = [...networkEvents].reverse().some((event) =>
    /resale-api\.wildberries\.ru\/api\/v1\/listings\/external/i.test(event.url) &&
    event.status >= 200 &&
    event.status < 300
  );
  const listingPublished = await page.evaluate((expectedTitle) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ").toLowerCase();
    const expected = norm(expectedTitle);
    const titleNode = [...document.querySelectorAll("a,div,span,p")]
      .find((el) => norm(el.innerText || el.textContent || "") === expected);
    if (!titleNode) return false;
    let card = titleNode;
    for (let depth = 0; card && depth < 8; depth += 1, card = card.parentElement) {
      const text = norm(card.innerText || card.textContent || "");
      if (/опубликовано|на проверке|модерац/.test(text) && !/черновик/.test(text)) return true;
    }
    return false;
  }, item.title).catch(() => false);
  const listingUrl = await findSubmittedListingUrl(page, item.title);
  if (submitSuccess || listingPublished) {
    return { listingUrl };
  }

  throw new Error(`WB не подтвердил публикацию после клика. Скрин: ${screenshotPath}. URL: ${state.url}`);
}

async function findSubmittedListingUrl(page, title) {
  return page.evaluate((expectedTitle) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ").toLowerCase();
    const expected = norm(expectedTitle);
    const anchors = [...document.querySelectorAll("a[href]")];
    const exact = anchors.find((anchor) => norm(anchor.innerText || anchor.textContent || "") === expected);
    const containing = anchors.find((anchor) => norm(anchor.innerText || anchor.textContent || "").includes(expected));
    return (exact || containing)?.href || location.href;
  }, title).catch(() => page.url());
}

async function firstVisible(page, selectorList, options = {}) {
  for (const selector of selectorList ?? []) {
    const locator = page.locator(selector).first();
    const count = await locator.count().catch(() => 0);
    if (!count) continue;
    if (options.includeHidden) return locator;
    if (await locator.isVisible().catch(() => false)) return locator;
  }
  return null;
}

async function nthVisibleTextInput(page, index) {
  const locators = await page.locator("input:not([type='file']):not([type='checkbox']):not([type='radio']), textarea").all();
  let visibleIndex = 0;
  for (const locator of locators) {
    if (!(await locator.isVisible().catch(() => false))) continue;
    if (visibleIndex === index) return locator;
    visibleIndex += 1;
  }
  return null;
}

async function hasAnyVisible(page, selectorList) {
  return Boolean(await firstVisible(page, selectorList));
}

async function clickVisibleByText(page, patterns) {
  return page.evaluate((sources) => {
    const regexes = sources.map((source) => new RegExp(source, "i"));
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span")]
      .map((el) => ({ el, text: (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ") }))
      .filter(({ el, text }) => {
        const rect = el.getBoundingClientRect();
        const visible = rect.width > 5 && rect.height > 5 && getComputedStyle(el).visibility !== "hidden";
        return visible && text && text.length < 80 && regexes.some((regex) => regex.test(text));
      });
    const candidate = candidates[0];
    if (!candidate) return "";
    candidate.el.click();
    return candidate.text;
  }, patterns.map((pattern) => pattern.source));
}

async function clickProductType(page, patterns) {
  return page.evaluate((sources) => {
    const regexes = sources.map((source) => new RegExp(source, "i"));
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialogs = [...document.querySelectorAll("[role='dialog'],[class*='modal'],[class*='popup'],[class*='sheet']")]
      .filter(visible)
      .filter((el) => /Другой товар/i.test(norm(el.innerText || el.textContent || "")))
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return (ar.width * ar.height) - (br.width * br.height);
      });
    const dialog = dialogs[0];
    if (!dialog) return "";
    const candidates = [...dialog.querySelectorAll("button,a,[role='button'],div,span,label")]
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
      .filter(({ el, text, rect }) => {
        if (!visible(el) || !text || text.length > 140) return false;
        if (!regexes.some((regex) => regex.test(text))) return false;
        const className = String(el.className || "");
        return /card|option|item|button/i.test(className) || Boolean(el.closest("button,a,[role='button'],label"));
      })
      .sort((a, b) => a.text.length - b.text.length || a.rect.top - b.rect.top);
    const candidate = candidates[0];
    if (!candidate) return "";
    candidate.el.scrollIntoView({ block: "center", inline: "center" });
    candidate.el.click();
    return candidate.text;
  }, patterns.map((pattern) => pattern.source)).catch(() => "");
}

async function clickVisibleExactText(page, text, options = {}) {
  const clicked = await page.evaluate((target) => {
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span,label")]
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ el, text }) => {
        const rect = el.getBoundingClientRect();
        const visible = rect.width > 5 && rect.height > 5 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).display !== "none";
        return visible && text === target;
      });
    const preferred = candidates.find(({ el }) => String(el.className || "").includes("listItemContent")) || candidates[0];
    if (!preferred) return false;
    preferred.el.click();
    return true;
  }, text);
  if (!clicked && !options.optional) throw new Error(`${options.label || "Значение"} "${text}" не найдено в списке.`);
  return clicked;
}

async function fillCategorySearch(page, text) {
  const searchInputs = await page.locator("input[placeholder*='Поиск'], input[type='search']").all();
  for (const input of searchInputs.reverse()) {
    if (!(await input.isVisible().catch(() => false))) continue;
    await input.fill(String(text));
    await page.waitForTimeout(900);
    return true;
  }
  return false;
}

async function clickVisibleContainsText(page, text, options = {}) {
  const clicked = await page.evaluate((targetRaw) => {
    const target = String(targetRaw || "").trim().toLowerCase();
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span,label")]
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || "") }))
      .filter(({ el, text }) => visible(el) && text.length < 120 && text.toLowerCase().includes(target));
    const preferred =
      candidates.find(({ text }) => text.includes(" / ")) ||
      candidates.find(({ el }) => String(el.className || "").includes("listItem")) ||
      candidates[0];
    if (!preferred) return false;
    preferred.el.click();
    return true;
  }, text);
  if (!clicked && !options.optional) throw new Error(`${options.label || "Значение"} "${text}" не найдено в списке.`);
  return clicked;
}

async function clickDropdownOption(page, text, options = {}) {
  const clicked = await page.evaluate(({ text, exact }) => {
    const target = String(text || "").trim().toLowerCase();
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 5 && rect.height > 5 && style.visibility !== "hidden" && style.display !== "none";
    };
    const candidates = [...document.querySelectorAll("button,a,[role='button'],div,span,label,li")]
      .map((el) => ({ el, text: norm(el.innerText || el.textContent || ""), rect: el.getBoundingClientRect() }))
      .filter(({ el, text, rect }) => {
        if (!visible(el) || !text || text.length > 160) return false;
        const lower = text.toLowerCase();
        const matches = exact ? lower === target : lower.includes(target);
        if (!matches) return false;
        const inModalArea = rect.left > 330 && rect.left < 980 && rect.top > 180;
        const className = String(el.className || "");
        const inDropdown = /select|dropdown|list|popup|modal|option/i.test(className) || el.closest("[class*='select'],[class*='dropdown'],[class*='popup'],[class*='modal'],[role='listbox']");
        return inModalArea || inDropdown;
      })
      .sort((a, b) => {
        const ad = Math.abs(a.rect.left - 480) + Math.abs(a.rect.top - 520);
        const bd = Math.abs(b.rect.left - 480) + Math.abs(b.rect.top - 520);
        return a.text.length - b.text.length || ad - bd;
      });
    const targetEl = candidates[0]?.el;
    if (!targetEl) return false;
    targetEl.scrollIntoView({ block: "center", inline: "center" });
    targetEl.click();
    return true;
  }, { text, exact: options.exact !== false }).catch(() => false);
  return Boolean(clicked);
}

async function visibleDiagnostics(page) {
  return page.evaluate(() => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      return rect.width > 5 && rect.height > 5 && getComputedStyle(el).visibility !== "hidden";
    };
    const clickables = [...document.querySelectorAll("button,a,[role='button']")]
      .filter(visible)
      .map((el) => (el.innerText || el.textContent || el.getAttribute("aria-label") || "").trim().replace(/\s+/g, " "))
      .filter(Boolean);
    const inputs = [...document.querySelectorAll("input,textarea,select")]
      .filter(visible)
      .map((el) => `${el.tagName.toLowerCase()} ${el.getAttribute("name") || ""} placeholder=${el.getAttribute("placeholder") || ""} value=${el.value || ""}`.trim());
    const sizeLabel = "\u0420\u0430\u0437\u043c\u0435\u0440";
    const sizeChoice = "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440";
    const sizeBlocks = [...document.querySelectorAll("button,a,[role='button'],input,textarea,select,div,span,label")]
      .filter(visible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          role: el.getAttribute("role") || "",
          className: String(el.className || "").slice(0, 180),
          text: (el.innerText || el.textContent || el.getAttribute("placeholder") || "").trim().replace(/\s+/g, " ").slice(0, 220),
          placeholder: el.getAttribute("placeholder") || "",
          value: el.value || "",
          rect: { x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height) }
        };
      })
      .filter((entry) => entry.text.includes(sizeLabel) || entry.text.includes(sizeChoice) || entry.placeholder.includes(sizeLabel) || entry.placeholder.includes(sizeChoice))
      .sort((a, b) => a.text.length - b.text.length)
      .slice(0, 40);
    return { clickables, inputs, sizeBlocks, url: location.href, title: document.title };
  });
}

async function savePreparedDiagnostics(page, item) {
  const base = path.join(logsDir, `prepared-${safeName(item.id)}-${Date.now()}`);
  const details = await page.evaluate(() => {
    const value = (selector) => document.querySelector(selector)?.value || "";
    const text = (selector) => String(document.querySelector(selector)?.innerText || "").trim().replace(/\s+/g, " ");
    const bodyText = String(document.body?.innerText || "").replace(/\s+/g, " ");
    const characteristicLabel = [...document.querySelectorAll("h1,h2,h3,h4,label,div,span,p")]
      .find((el) => String(el.innerText || el.textContent || "").trim() === "Характеристики");
    const characteristicBlock = characteristicLabel?.parentElement;
    return {
      url: location.href,
      title: value("input[name='adName']"),
      category: value("input[name='adCategory']"),
      price: value("input[placeholder*='цену']"),
      quantity: value("input[name='adQuantity']"),
      description: value("textarea#adDescription"),
      characteristics: String(characteristicBlock?.innerText || "").trim().replace(/\s+/g, " "),
      pickupPointSelected: ![...document.querySelectorAll("button")].some((button) => String(button.innerText || button.textContent || "").trim() === "Выберите пункт"),
      checkedCheckboxes: [...document.querySelectorAll("input[type='checkbox']")].filter((el) => el.checked).length,
      uploadedImages: [...document.querySelectorAll("img")].filter((img) => {
        const rect = img.getBoundingClientRect();
        return rect.width >= 40 && rect.height >= 40 && rect.top > 200;
      }).length
    };
  });
  fs.writeFileSync(`${base}.json`, JSON.stringify(details, null, 2), "utf8");
  await page.screenshot({ path: `${base}.png`, fullPage: true }).catch(() => {});
  log(`Prepared form verified: ${base}.json`);
  return details;
}

async function saveDiagnostics(page, itemId, error) {
  const base = path.join(logsDir, `${safeName(itemId)}-${Date.now()}`);
  const screenshotPath = `${base}.png`;
  const jsonPath = `${base}.json`;
  const details = await visibleDiagnostics(page).catch(() => ({}));
  await page.screenshot({ path: screenshotPath, fullPage: true }).catch(() => {});
  fs.writeFileSync(jsonPath, JSON.stringify({ error, details }, null, 2), "utf8");
  log(`Diagnostics saved: ${screenshotPath}`);
  return screenshotPath;
}

function shouldPublish(item) {
  return autoPublish && String(item.draft_only).trim().toLowerCase() === "false";
}

function appendLog(fileName, row) {
  const target = path.join(logsDir, fileName);
  const exists = fs.existsSync(target);
  const line = [row.id, row.title, row.status, row.error ?? ""]
    .map((value) => `"${String(value).replaceAll('"', '""')}"`)
    .join(";") + "\n";
  if (!exists) fs.writeFileSync(target, "id;title;status;error\n", "utf8");
  fs.appendFileSync(target, line, "utf8");
}

function parseSemicolonCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  const source = String(text || "").replace(/^\uFEFF/, "");

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (char === '"' && source[i + 1] === '"') {
      cell += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === ";" && !quoted) {
      row.push(cell);
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && source[i + 1] === "\n") i += 1;
      row.push(cell);
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }

  row.push(cell);
  if (row.some((value) => value !== "")) rows.push(row);

  const headers = rows.shift() || [];
  return rows.map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""])));
}

function log(message) {
  console.log(message);
  emit({ type: "log", message });
}

function emit(payload) {
  console.log(`EVENT_JSON:${JSON.stringify({ time: new Date().toISOString(), ...payload })}`);
}

function safeName(value) {
  return String(value).replace(/[^a-z0-9_-]+/gi, "_");
}

async function waitForPhotoUpload(page, expectedCount) {
  if (page.url().startsWith("file:")) return;
  const result = await page.waitForFunction((count) => {
    const visible = (el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return rect.width > 20 && rect.height > 20 && style.visibility !== "hidden" && style.display !== "none";
    };
    const dialog = [...document.querySelectorAll("div,section")]
      .filter(visible)
      .find((el) => {
        const text = el.innerText || el.textContent || "";
        return text.includes("\u041e\u0431\u044a\u044f\u0432\u043b\u0435\u043d\u0438\u0435 \u043e \u043f\u0440\u043e\u0434\u0430\u0436\u0435") && text.includes("\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435");
      });
    const root = dialog || document;
    const images = [...root.querySelectorAll("img")]
      .filter(visible)
      .filter((img) => {
        const rect = img.getBoundingClientRect();
        return rect.width <= 180 && rect.height <= 180;
      });
    const text = root.innerText || root.textContent || "";
    if (/Не удалось загрузить фото|попробуйте ещё раз/i.test(text)) return "error";
    if (images.length >= count || text.includes("\u0413\u041b\u0410\u0412\u041d\u0410\u042f")) return "ready";
    return "";
  }, expectedCount, { timeout: 30000 }).then((handle) => handle.jsonValue());
  if (result === "error") throw new Error("WB не принял фото, выполняю повторную загрузку.");
  await page.waitForTimeout(700);
}

async function setPageZoom(page, zoom) {
  await page.evaluate((value) => {
    document.documentElement.style.zoom = String(value);
    document.body.style.zoom = String(value);
  }, zoom).catch(() => {});
  await page.waitForTimeout(300);
}
