const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

test("XML import replaces only the pending publication queue", { timeout: 15_000 }, async () => {
  const sourceDir = path.resolve(__dirname, "..");
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "wbr-import-replace-"));
  const crmDir = path.join(tempRoot, "Desktop", "WB Resale CRM");
  const rpaDir = path.join(tempRoot, "Desktop", "WB Resale RPA");
  const port = 34_000 + Math.floor(Math.random() * 1_000);
  fs.mkdirSync(crmDir, { recursive: true });
  fs.mkdirSync(path.join(rpaDir, "src"), { recursive: true });
  for (const file of ["server.js", "agent-profiles.js", "publication-xml.js"]) {
    fs.copyFileSync(path.join(sourceDir, file), path.join(crmDir, file));
  }

  const child = spawn(process.execPath, ["server.js"], {
    cwd: crmDir,
    env: { ...process.env, PORT: String(port), USERPROFILE: tempRoot },
    stdio: "ignore",
    windowsHide: true,
  });

  try {
    await waitForAgent(port);
    await createListing(port, "old-ready", "Старая позиция", "ready");
    await createListing(port, "old-error", "Старая ошибка", "error");
    await createListing(port, "history-item", "История модерации", "moderation");

    const response = await fetch(`http://127.0.0.1:${port}/api/import/xml`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        publish: false,
        xml: `<?xml version="1.0" encoding="UTF-8"?>
          <Ads><Ad>
            <Id>NEW-1</Id><Title>Новая позиция</Title><Price>1570</Price>
            <Images>
              <Image url="https://example.test/1.jpg"/>
              <Image url="https://example.test/2.jpg"/>
              <Image url="https://example.test/3.jpg"/>
            </Images>
          </Ad></Ads>`,
      }),
    });
    assert.equal(response.status, 200);
    const imported = await response.json();
    assert.equal(imported.imported, 1);
    assert.equal(imported.replaced, 2);

    const listings = await fetch(`http://127.0.0.1:${port}/api/listings`).then((result) => result.json());
    assert.deepEqual(
      listings.map(({ sku, status }) => ({ sku, status })).sort((a, b) => a.sku.localeCompare(b.sku)),
      [
        { sku: "history-item", status: "moderation" },
        { sku: "new-1", status: "ready" },
      ].sort((a, b) => a.sku.localeCompare(b.sku)),
    );
  } finally {
    child.kill();
    await new Promise((resolve) => child.once("exit", resolve));
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
});

async function createListing(port, sku, title, status) {
  const response = await fetch(`http://127.0.0.1:${port}/api/listings`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      sku,
      title,
      category: "Одежда",
      photos: "https://example.test/1.jpg,https://example.test/2.jpg,https://example.test/3.jpg",
      price: 1570,
      quantity: 14,
      condition: "Новое",
      allow_offers: true,
      accept_rules: true,
      status,
    }),
  });
  assert.equal(response.status, 200);
}

async function waitForAgent(port) {
  let lastError;
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/rpa/status`);
      if (response.ok) return;
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw lastError || new Error("Temporary agent did not start.");
}
