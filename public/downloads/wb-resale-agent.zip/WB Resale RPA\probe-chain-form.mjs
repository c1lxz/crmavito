﻿import fs from 'node:fs';
import { chromium } from 'playwright';
const selectors = JSON.parse(fs.readFileSync('selectors.json','utf8'));
const context = await chromium.launchPersistentContext('.browser-profile', { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(8000);
await page.goto(selectors.startUrl, { waitUntil: 'domcontentloaded' });
for (let attempt=0; attempt<4; attempt++) {
  await page.waitForTimeout(2200);
  const titleVisible = await page.locator(selectors.fields.title.join(',')).first().isVisible().catch(()=>false);
  console.log('attempt', attempt, 'url', page.url(), 'titleVisible', titleVisible);
  if (titleVisible) break;
  let clicked = false;
  for (const selector of selectors.createButton) {
    const loc = page.locator(selector).first();
    if (await loc.count().catch(()=>0) && await loc.isVisible().catch(()=>false)) {
      console.log('CLICK', selector, await loc.innerText().catch(()=>''));
      await loc.click(); clicked = true; break;
    }
  }
  if (!clicked) console.log('no create button');
}
await page.waitForTimeout(3000);
console.log('final url', page.url());
const diag = await page.evaluate(() => ({
 text: document.body.innerText.slice(0,2000),
 inputs: [...document.querySelectorAll('input,textarea,select')].map(el => ({tag:el.tagName,name:el.getAttribute('name'),placeholder:el.getAttribute('placeholder'),type:el.getAttribute('type'),visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible).slice(0,80),
 buttons: [...document.querySelectorAll('button,[role="button"],a')].map(el => ({tag:el.tagName,text:(el.innerText||el.textContent||'').trim().replace(/\s+/g,' '),href:el.href||el.getAttribute('href')||'',visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible && x.text).slice(0,80)
}));
console.log(JSON.stringify(diag,null,2));
await page.screenshot({ path: 'logs/probe-form-opened.png', fullPage: true });
await context.close();
