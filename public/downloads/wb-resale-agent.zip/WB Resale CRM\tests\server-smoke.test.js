const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");

test("local agent creates profiles, exports WB XML, and opens the installed Chrome profile", { timeout: 15_000 }, async () => {
  const sourceDir = path.resolve(__dirname, "..");
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "wbr-agent-smoke-"));
  const crmDir = path.join(tempRoot, "Desktop", "WB Resale CRM");
  const rpaDir = path.join(tempRoot, "Desktop", "WB Resale RPA");
  const capturePath = path.join(tempRoot, "profile-capture.json");
  const port = 33_000 + Math.floor(Math.random() * 1_000);
  fs.mkdirSync(crmDir, { recursive: true });
  fs.mkdirSync(path.join(rpaDir, "src"), { recursive: true });
  fs.writeFileSync(path.join(rpaDir, "src", "open-profile.mjs"), [
    'import fs from "node:fs";',
    'fs.writeFileSync(process.env.PROFILE_CAPTURE, JSON.stringify({ systemProfileDirectory: process.env.BROWSER_SYSTEM_PROFILE_DIRECTORY, browser: process.env.BROWSER }));',
  ].join("\n"));
  const chromeDir = path.join(tempRoot, "LocalAppData", "Google", "Chrome", "User Data");
  fs.mkdirSync(chromeDir, { recursive: true });
  fs.writeFileSync(path.join(chromeDir, "Local State"), JSON.stringify({
    profile: {
      profiles_order: ["Default", "Profile 2"],
      info_cache: {
        Default: { name: "Default" },
        "Profile 2": { name: "Smoke account", user_name: "smoke@example.test" },
      },
    },
  }));
  for (const file of ["server.js", "agent-profiles.js", "publication-xml.js"]) {
    fs.copyFileSync(path.join(sourceDir, file), path.join(crmDir, file));
  }

  const child = spawn(process.execPath, ["server.js"], {
    cwd: crmDir,
    env: { ...process.env, PORT: String(port), USERPROFILE: tempRoot, LOCALAPPDATA: path.join(tempRoot, "LocalAppData"), PROFILE_CAPTURE: capturePath },
    stdio: "ignore",
    windowsHide: true,
  });

  try {
    await waitForAgent(port);
    const listingResponse = await fetch(`http://127.0.0.1:${port}/api/listings`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        sku: "smoke-sku",
        title: "Smoke & XML",
        category: "Одежда",
        photos: "https://example.test/1.jpg,https://example.test/2.jpg,https://example.test/3.jpg",
        price: 2500,
        quantity: 1,
        condition: "Новое",
        description: "Проверка XML",
        characteristics: "Размер M",
        allow_offers: true,
        accept_rules: true,
        draft_only: false,
        status: "ready",
      }),
    });
    assert.equal(listingResponse.status, 200);

    const initial = await fetch(`http://127.0.0.1:${port}/api/rpa/profiles`).then((response) => response.json());
    assert.equal(initial.profiles.length, 1);
    assert.equal(initial.profiles[0].id, "default");
    assert.equal(initial.profiles[0].source, "system");
    assert.equal(initial.profiles[0].systemProfileDirectory, "Default");

    const createdResponse = await fetch(`http://127.0.0.1:${port}/api/rpa/profiles`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name: "Smoke account" }),
    });
    assert.equal(createdResponse.status, 201);
    const created = await createdResponse.json();
    assert.equal(created.profiles.length, 2);

    const xmlResponse = await fetch(`http://127.0.0.1:${port}/api/export.xml`);
    assert.equal(xmlResponse.status, 200);
    assert.match(xmlResponse.headers.get("content-disposition") || "", /wb-publication\.xml/);
    const xml = await xmlResponse.text();
    assert.match(xml, /target="Wildberries"/);
    assert.match(xml, /profileName="Smoke account"/);
    assert.match(xml, /Smoke &amp; XML/);

    const startResponse = await fetch(`http://127.0.0.1:${port}/api/rpa/start`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ profileId: created.profile.id }),
    });
    assert.equal(startResponse.status, 200);
    const started = await startResponse.json();
    assert.equal(started.profile.id, created.profile.id);
    assert.ok(fs.existsSync(started.xmlPath));
    await waitForFile(capturePath);
    const capture = JSON.parse(fs.readFileSync(capturePath, "utf8"));
    assert.equal(capture.browser, "chrome");
    assert.equal(capture.systemProfileDirectory, "Profile 2");
    assert.equal(started.profile.source, "system");
  } finally {
    child.kill();
    await new Promise((resolve) => child.once("exit", resolve));
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
});

async function waitForFile(filePath) {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    if (fs.existsSync(filePath)) return;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  throw new Error(`Expected file was not created: ${filePath}`);
}

async function waitForAgent(port) {
  let lastError;
  for (let attempt = 0; attempt < 40; attempt += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/rpa/status`);
      if (response.ok) return;
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw lastError || new Error("Temporary agent did not start.");
}
