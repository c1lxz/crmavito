import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";
import { defaultProfileDirectory, resolveBrowserExecutable } from "./browser-launch.mjs";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const logsDir = path.join(rootDir, "logs");
fs.mkdirSync(logsDir, { recursive: true });

const browser = resolveBrowserExecutable({
  playwrightExecutablePaths: { chromium: chromium.executablePath() },
});
const profile = defaultProfileDirectory(rootDir, browser.id);
const context = await chromium.launchPersistentContext(profile, {
  executablePath: browser.executablePath,
  headless: false,
  viewport: null,
  args: ["--start-maximized", "--disable-backgrounding-occluded-windows"],
});

const pages = context.pages();
const page = pages[0] || await context.newPage();
await page.goto("https://www.wildberries.ru/resale/ads", {
  waitUntil: "domcontentloaded",
  timeout: 45_000,
}).catch(() => {});
await page.waitForTimeout(5_000);

const stamp = Date.now();
const screenshot = path.join(logsDir, `size-window-${stamp}.png`);
const snapshot = path.join(logsDir, `size-window-${stamp}.json`);

if (process.env.OPEN_BLANK_FORM === "1") {
  const create = page.getByRole("button", { name: "\u0420\u0430\u0437\u043c\u0435\u0441\u0442\u0438\u0442\u044c \u043e\u0431\u044a\u044f\u0432\u043b\u0435\u043d\u0438\u0435", exact: true });
  if (await create.count() === 1) {
    await create.click();
    await page.waitForTimeout(1_500);
  }
  const other = page.getByText("\u0414\u0440\u0443\u0433\u043e\u0439 \u0442\u043e\u0432\u0430\u0440", { exact: true });
  if (await other.count() === 1) {
    await other.click();
    await page.waitForTimeout(2_000);
  }
}

let sizeExperiment = null;
if (process.env.INSPECT_SIZE_CONTROL === "1") {
  const category = page.locator("input[name='adCategory']");
  if (await category.count() === 1) {
    await category.click({ force: true });
    await page.waitForTimeout(500);
    const search = page.locator(".mo-dropdown:visible input[placeholder='\u041f\u043e\u0438\u0441\u043a']");
    if (await search.count() === 1) {
      await search.fill("\u0424\u0443\u0442\u0431\u043e\u043b\u043a\u0438");
      await page.waitForTimeout(900);
      const option = page.getByText("\u041e\u0434\u0435\u0436\u0434\u0430 / \u0424\u0443\u0442\u0431\u043e\u043b\u043a\u0438", { exact: true });
      if (await option.count() === 1) {
        await option.click();
        await page.waitForTimeout(900);
      }
    }
  }

  const sizeSelect = page.locator(".mo-select").filter({
    hasText: "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0430\u0437\u043c\u0435\u0440",
  });
  if (await sizeSelect.count() === 1) {
    await sizeSelect.evaluate((element) => element.setAttribute("data-inspect-size", "true"));
    const stableSizeSelect = page.locator("[data-inspect-size='true']");
    await stableSizeSelect.scrollIntoViewIfNeeded();
    await page.waitForTimeout(350);
    const wrapper = stableSizeSelect.locator(".mo-select__wrapper");
    const combobox = stableSizeSelect.locator("button[role='combobox']");
    const readState = () => wrapper.getAttribute("data-state");
    const attempts = [];

    await combobox.evaluate((button) => button.click());
    await page.waitForTimeout(250);
    attempts.push({ action: "combobox.nativeClick", state: await readState() });

    if (await readState() !== "open") {
      await wrapper.evaluate((element) => element.click());
      await page.waitForTimeout(250);
      attempts.push({ action: "wrapper.nativeClick", state: await readState() });
    }
    if (await readState() !== "open") {
      await wrapper.click({ force: true });
      await page.waitForTimeout(250);
      attempts.push({ action: "wrapper.playwrightClick", state: await readState() });
    }
    if (await readState() !== "open") {
      await combobox.press("ArrowDown").catch(() => {});
      await page.waitForTimeout(250);
      attempts.push({ action: "combobox.arrowDown", state: await readState() });
    }
    sizeExperiment = {
      attempts,
      finalState: await readState(),
      dropdowns: await page.locator(".mo-dropdown:visible,[role='listbox']:visible").count(),
    };
    const testSize = String(process.env.TEST_SELECT_SIZE || "").trim();
    if (testSize && sizeExperiment.finalState === "open") {
      const items = page.locator(".mo-dropdown:visible li");
      const texts = await items.allTextContents();
      const matches = texts
        .map((text, index) => ({ text: String(text || "").trim(), index }))
        .filter((item) => item.text.toLowerCase() === testSize.toLowerCase());
      if (matches.length === 1) {
        await items.nth(matches[0].index).click({ force: true });
        await page.waitForTimeout(250);
      }
      sizeExperiment.selection = {
        requested: testSize,
        exactMatches: matches.length,
        selectedText: String(await stableSizeSelect.innerText()).trim().replace(/\s+/g, " "),
        finalState: await readState(),
      };
    }
  }
}

await page.screenshot({ path: screenshot, fullPage: false });

const state = await page.evaluate(() => {
  const visible = (el) => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 5 && rect.height > 5 &&
      style.display !== "none" && style.visibility !== "hidden";
  };
  const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
  const controls = [...document.querySelectorAll(
    "button,a,input,[role='button'],[role='combobox'],[role='tab']"
  )]
    .filter(visible)
    .slice(0, 160)
    .map((el) => ({
      tag: el.tagName.toLowerCase(),
      role: el.getAttribute("role") || "",
      text: norm(el.innerText || el.textContent || el.value || el.placeholder).slice(0, 100),
      href: el.getAttribute("href") || "",
      aria: el.getAttribute("aria-label") || "",
    }));
  return {
    url: location.href,
    title: document.title,
    dialogs: [...document.querySelectorAll("[role='dialog']")].filter(visible).length,
    sizeControls: [...document.querySelectorAll(".mo-select")]
      .filter((el) => norm(el.innerText || el.textContent).includes("\u0440\u0430\u0437\u043c\u0435\u0440"))
      .slice(0, 8)
      .map((el) => ({
        text: norm(el.innerText || el.textContent),
        html: el.outerHTML.slice(0, 4000),
        state: el.querySelector(".mo-select__wrapper")?.getAttribute("data-state") || "",
      })),
    openDropdowns: [...document.querySelectorAll(".mo-dropdown,[role='listbox']")]
      .filter(visible)
      .slice(0, 4)
      .map((el) => ({
        tag: el.tagName.toLowerCase(),
        className: String(el.className || ""),
        html: el.outerHTML.slice(0, 12000),
        items: [...el.querySelectorAll("li,[role='option'],button,div")]
          .filter(visible)
          .map((item) => norm(item.innerText || item.textContent))
          .filter((text) => text && text.length <= 30)
          .slice(0, 40),
      })),
    controls,
  };
});
state.sizeExperiment = sizeExperiment;
fs.writeFileSync(snapshot, JSON.stringify(state, null, 2), "utf8");
console.log(JSON.stringify({ status: "ready", screenshot, snapshot, url: state.url }));

await new Promise((resolve) => {
  const timer = setTimeout(resolve, 15 * 60_000);
  process.once("SIGINT", () => { clearTimeout(timer); resolve(); });
  process.once("SIGTERM", () => { clearTimeout(timer); resolve(); });
});

await context.close();
