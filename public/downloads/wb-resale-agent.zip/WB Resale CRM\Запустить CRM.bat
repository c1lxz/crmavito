@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo WB Resale CRM
echo.
start "" "http://127.0.0.1:3017"
node server.js
echo.
pause
