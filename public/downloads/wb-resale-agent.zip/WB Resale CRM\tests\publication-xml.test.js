const assert = require("node:assert/strict");
const test = require("node:test");
const { buildWbPublicationXml } = require("../publication-xml");

test("WB publication XML contains the selected account and escaped listing data", () => {
  const xml = buildWbPublicationXml([{
    sku: "sku&1",
    title: "Футболка <Black>",
    category: "Одежда",
    price: 2500,
    quantity: 1,
    condition: "Новое",
    description: "A & B",
    characteristics: "Размер M",
    pickup_point: "Москва",
    allow_offers: true,
    draft_only: false,
    photos: "photos/1.jpg,photos/2.jpg,photos/1.jpg",
  }], {
    generatedAt: "2026-07-31T10:00:00.000Z",
    profileId: "shop-1",
    profileName: "Магазин & 1",
  });

  assert.match(xml, /^<\?xml version="1\.0" encoding="UTF-8"\?>/);
  assert.match(xml, /target="Wildberries"/);
  assert.match(xml, /profileId="shop-1" profileName="Магазин &amp; 1"/);
  assert.match(xml, /<Id>sku&amp;1<\/Id>/);
  assert.match(xml, /<Title>Футболка &lt;Black&gt;<\/Title>/);
  assert.equal((xml.match(/<Image /g) || []).length, 2);
});
