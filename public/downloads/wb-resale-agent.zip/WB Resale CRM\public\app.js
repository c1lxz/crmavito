const form = document.querySelector("#listingForm");
const listBody = document.querySelector("#listBody");
const statusFilter = document.querySelector("#statusFilter");
const saveState = document.querySelector("#saveState");
const clearButton = document.querySelector("#clearButton");
const refreshButton = document.querySelector("#refreshButton");
const exportButton = document.querySelector("#exportButton");
const dryRunRpaButton = document.querySelector("#dryRunRpaButton");
const startRpaButton = document.querySelector("#startRpaButton");
const stopRpaButton = document.querySelector("#stopRpaButton");
const clearLogButton = document.querySelector("#clearLogButton");
const runState = document.querySelector("#runState");
const runDot = document.querySelector("#runDot");
const rpaLog = document.querySelector("#rpaLog");
const photoInput = document.querySelector("#photoInput");
const photoButton = document.querySelector("#photoButton");
const photoDrop = document.querySelector("#photoDrop");
const photoPreview = document.querySelector("#photoPreview");

let listings = [];
let uploadedPhotos = [];

const statusLabels = {
  draft: "Черновик",
  ready: "К публикации",
  exported: "Выгружено",
  running: "В работе",
  moderation: "На проверке",
  posted: "Опубликовано",
  error: "Ошибка"
};

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  saveState.textContent = "Сохраняю...";
  const data = Object.fromEntries(new FormData(form).entries());
  if (!data.sku) data.sku = nextSku();
  data.status = "ready";
  data.allow_offers = form.allow_offers.checked;
  data.accept_rules = form.accept_rules.checked;
  data.draft_only = form.draft_only.checked;
  data.price = Number(data.price || 0);
  data.quantity = 1;
  data.photos = uploadedPhotos.map((photo) => photo.path).join(",");
  data.sizes = [...form.querySelectorAll("input[name='sizes']:checked")].map((input) => input.value);

  if (data.sizes.length > 1 && !confirm(`Создать ${data.sizes.length} объявлений по размерам: ${data.sizes.join(", ")}?`)) {
    saveState.textContent = "";
    return;
  }

  const result = await api("/api/listings", { method: "POST", body: JSON.stringify(data) });
  form.sku.value = nextSku();
  saveState.textContent = `Сохранено: ${result.saved.length}. Запускаю публикацию...`;
  await loadListings();
  await startPublishQueue();
  setTimeout(() => (saveState.textContent = ""), 4000);
});

clearButton.addEventListener("click", resetForm);
refreshButton.addEventListener("click", loadListings);
statusFilter.addEventListener("change", renderListings);

exportButton.addEventListener("click", async () => {
  await withBusy(exportButton, "Выгружаю...", async () => {
    const result = await api("/api/export-to-rpa", { method: "POST" });
    addLog({ type: "log", message: `CSV обновлён: ${result.path}` });
    await loadListings();
  });
});

startRpaButton.addEventListener("click", async () => {
  await withBusy(startRpaButton, "Запускаю...", async () => {
    await startPublishQueue();
  });
});

dryRunRpaButton.addEventListener("click", async () => {
  await withBusy(dryRunRpaButton, "Проверяю...", async () => {
    const result = await api("/api/rpa/dry-run", { method: "POST" });
    addLog({ type: "log", message: `Проверка WB без публикации запущена. CSV: ${result.csvPath}` });
    await refreshRpaStatus();
  });
});

stopRpaButton.addEventListener("click", async () => {
  await api("/api/rpa/stop", { method: "POST" });
  await refreshRpaStatus();
});

clearLogButton.addEventListener("click", async () => {
  await api("/api/rpa/clear-log", { method: "POST" });
  rpaLog.innerHTML = "";
});

photoButton.addEventListener("click", () => photoInput.click());
photoInput.addEventListener("change", () => uploadSelectedPhotos(photoInput.files));

for (const eventName of ["dragenter", "dragover"]) {
  photoDrop.addEventListener(eventName, (event) => {
    event.preventDefault();
    photoDrop.classList.add("is-dragging");
  });
}

for (const eventName of ["dragleave", "drop"]) {
  photoDrop.addEventListener(eventName, (event) => {
    event.preventDefault();
    photoDrop.classList.remove("is-dragging");
  });
}

photoDrop.addEventListener("drop", (event) => uploadSelectedPhotos(event.dataTransfer.files));

listBody.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const sku = button.dataset.sku;
  const row = listings.find((item) => item.sku === sku);
  if (!row) return;
  if (button.dataset.action === "edit") {
    fillForm(row);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  if (button.dataset.action === "ready") {
    await api(`/api/listings/${encodeURIComponent(sku)}`, { method: "PATCH", body: JSON.stringify({ status: "ready", note: row.note || "" }) });
    await loadListings();
  }
  if (button.dataset.action === "posted") {
    await api(`/api/listings/${encodeURIComponent(sku)}`, { method: "PATCH", body: JSON.stringify({ status: "posted", note: row.note || "" }) });
    await loadListings();
  }
  if (button.dataset.action === "delete" && confirm(`Удалить ${sku}?`)) {
    await api(`/api/listings/${encodeURIComponent(sku)}`, { method: "DELETE" });
    await loadListings();
  }
});

async function uploadSelectedPhotos(fileList) {
  const files = [...fileList].filter((file) => file.type.startsWith("image/"));
  if (!files.length) return;
  saveState.textContent = "Загружаю фото...";
  const payload = {
    sku: form.sku.value || nextSku(),
    files: await Promise.all(files.map(fileToPayload))
  };
  const result = await api("/api/uploads", { method: "POST", body: JSON.stringify(payload) });
  uploadedPhotos = result.photos;
  form.photos.value = result.photosText;
  renderPhotoPreview();
  saveState.textContent = `Фото загружены: ${uploadedPhotos.length}`;
  setTimeout(() => (saveState.textContent = ""), 4000);
}

function fileToPayload(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ name: file.name, type: file.type, data: reader.result });
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function loadListings() {
  listings = await api("/api/listings");
  renderMetrics();
  renderListings();
  if (!form.sku.value) form.sku.value = nextSku();
}

async function refreshRpaStatus() {
  const state = await api("/api/rpa/status");
  setRunningState(Boolean(state.running), state.exitCode);
  rpaLog.innerHTML = "";
  for (const event of state.events || []) addLog(event);
}

function connectEvents() {
  const source = new EventSource("/api/events");
  source.onmessage = async (message) => {
    const event = JSON.parse(message.data);
    if (event.type === "clear") {
      rpaLog.innerHTML = "";
      return;
    }
    addLog(event);
    if (event.type === "run") {
      const running = ["starting", "running"].includes(event.status);
      const stopped = ["done", "failed"].includes(event.status);
      if (running || stopped) {
        setRunningState(running, stopped && event.status === "done" ? 0 : null, event.message);
      }
    }
    if (event.type === "item" || event.type === "run") {
      await loadListings();
    }
  };
}

function setRunningState(running, exitCode = null, message = "") {
  runDot.classList.toggle("active", running);
  runState.textContent = running
    ? "RPA запущен, браузер работает"
    : `RPA не запущен${exitCode !== null ? `, последний код ${exitCode}` : message ? `: ${message}` : ""}`;
  startRpaButton.disabled = running;
  dryRunRpaButton.disabled = running;
  stopRpaButton.disabled = !running;
}

function renderMetrics() {
  document.querySelector("#metricTotal").textContent = listings.length;
  document.querySelector("#metricReady").textContent = listings.filter((item) => ["ready", "draft", "error"].includes(item.status)).length;
  document.querySelector("#metricRunning").textContent = listings.filter((item) => item.status === "running").length;
  document.querySelector("#metricErrors").textContent = listings.filter((item) => item.status === "error").length;
}

function renderListings() {
  const filter = statusFilter.value;
  const visible = listings.filter((item) => filter === "all" || item.status === filter);
  if (!visible.length) {
    listBody.innerHTML = `<div class="empty">Пока нет карточек в этом статусе</div>`;
    return;
  }
  listBody.innerHTML = visible.map((item) => {
    const photos = parsePhotos(item.photos);
    const size = extractSize(item.characteristics);
    const cover = photos[0] ? `/api/photos/${encodeURIComponent(photos[0]).replaceAll("%2F", "/")}` : "";
    return `
      <article class="listing-card">
        <div class="cover">${cover ? `<img src="${cover}" alt="">` : `<span>Нет фото</span>`}</div>
        <div class="listing-main">
          <div class="listing-top">
            <strong title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</strong>
            <span class="badge status-${item.status}">${statusLabels[item.status] || item.status}</span>
          </div>
          <div class="listing-meta">
            <span>${escapeHtml(item.sku)}</span>
            <span>${Number(item.price || 0).toLocaleString("ru-RU")} ₽</span>
            <span>${size ? `Размер ${escapeHtml(size)}` : "Размер не указан"}</span>
            <span>${photos.length} фото</span>
          </div>
          ${item.note ? `<small>${escapeHtml(item.note)}</small>` : ""}
        </div>
        <div class="row-actions">
          <button class="small-btn" data-action="edit" data-sku="${escapeHtml(item.sku)}">Открыть</button>
          <button class="small-btn" data-action="ready" data-sku="${escapeHtml(item.sku)}">В очередь</button>
          <button class="small-btn" data-action="posted" data-sku="${escapeHtml(item.sku)}">Опубл.</button>
          <button class="small-btn danger-text" data-action="delete" data-sku="${escapeHtml(item.sku)}">Удалить</button>
        </div>
      </article>`;
  }).join("");
}

function renderPhotoPreview() {
  if (!uploadedPhotos.length) {
    photoPreview.innerHTML = "";
    return;
  }
  photoPreview.innerHTML = uploadedPhotos.map((photo, index) => `
    <div class="photo-tile">
      <img src="${photo.preview}" alt="">
      <span>${index + 1}</span>
    </div>
  `).join("");
}

function addLog(event) {
  const row = document.createElement("div");
  row.className = `log-row ${event.level === "error" || event.status === "error" || event.status === "failed" ? "log-error" : ""}`;
  const time = event.time ? new Date(event.time).toLocaleTimeString("ru-RU") : new Date().toLocaleTimeString("ru-RU");
  const label = event.id ? `${event.id}: ` : "";
  const message = event.message || event.status || "";
  row.textContent = `[${time}] ${label}${message}`;
  if (event.screenshot) {
    const screenshot = document.createElement("div");
    screenshot.className = "log-path";
    screenshot.textContent = `Скриншот: ${event.screenshot}`;
    row.appendChild(screenshot);
  }
  rpaLog.appendChild(row);
  rpaLog.scrollTop = rpaLog.scrollHeight;
}

function fillForm(item) {
  form.sku.value = item.sku.replace(/-(xxs|xs|s|m|l|xl|2xl)$/i, "");
  form.title.value = item.title || "";
  form.category.value = item.category || "";
  form.price.value = item.price || "";
  form.condition.value = item.condition || "Хорошее";
  form.pickup_point.value = item.pickup_point || "";
  form.description.value = item.description || "";
  form.characteristics.value = removeSizeCharacteristic(item.characteristics);
  form.note.value = item.note || "";
  form.status.value = item.status || "ready";
  form.allow_offers.checked = Boolean(item.allow_offers);
  form.accept_rules.checked = Boolean(item.accept_rules);
  form.draft_only.checked = Boolean(item.draft_only);
  uploadedPhotos = parsePhotos(item.photos).map((photo) => ({
    path: photo,
    preview: `/api/photos/${encodeURIComponent(photo).replaceAll("%2F", "/")}`
  }));
  form.photos.value = item.photos || "";
  renderPhotoPreview();
  const size = extractSize(item.characteristics);
  for (const input of form.querySelectorAll("input[name='sizes']")) input.checked = size ? input.value === size : input.checked;
}

function resetForm() {
  form.reset();
  uploadedPhotos = [];
  renderPhotoPreview();
  form.sku.value = nextSku();
  form.condition.value = "Хорошее";
  form.allow_offers.checked = true;
  form.accept_rules.checked = true;
  form.draft_only.checked = false;
  for (const input of form.querySelectorAll("input[name='sizes']")) input.checked = true;
}

async function startPublishQueue() {
  const state = await api("/api/rpa/status");
  if (state.running) {
    addLog({ type: "log", message: "RPA уже работает. Новые карточки останутся в очереди до следующего запуска." });
    await refreshRpaStatus();
    return;
  }
  const result = await api("/api/rpa/start", { method: "POST" });
  addLog({ type: "log", message: `RPA стартовал одной очередью. CSV: ${result.csvPath}` });
  await refreshRpaStatus();
}

function nextSku() {
  const maxNumber = listings.reduce((max, item) => {
    const match = String(item.sku).match(/item-(\d+)/);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);
  return `item-${String(maxNumber + 1).padStart(3, "0")}`;
}

async function withBusy(button, label, task) {
  const oldText = button.textContent;
  button.disabled = true;
  button.textContent = label;
  try {
    await task();
  } catch (error) {
    addLog({ type: "log", level: "error", message: error.message });
  } finally {
    button.textContent = oldText;
    await refreshRpaStatus();
  }
}

async function api(url, options = {}) {
  const response = await fetch(url, { headers: { "content-type": "application/json" }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Ошибка запроса");
  return data;
}

function parsePhotos(value) {
  return String(value || "").split(",").map((photo) => photo.trim()).filter(Boolean);
}

function extractSize(value) {
  return String(value || "").match(/размер\s+([^,;\n]+)/i)?.[1]?.trim() || "";
}

function removeSizeCharacteristic(value) {
  return String(value || "")
    .split(/[,;\n]/)
    .map((part) => part.trim())
    .filter((part) => part && !/^размер\b/i.test(part))
    .join(", ");
}

function escapeHtml(value) {
  return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

loadListings().then(refreshRpaStatus).then(connectEvents).catch((error) => alert(error.message));
