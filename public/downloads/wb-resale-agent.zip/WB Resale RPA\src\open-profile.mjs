import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { chromium, firefox } from "playwright";
import { defaultProfileDirectory, prepareBrowserProfile, resolveBrowserExecutable } from "./browser-launch.mjs";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const browser = resolveBrowserExecutable({
  playwrightExecutablePaths: {
    chromium: chromium.executablePath(),
    firefox: firefox.executablePath(),
  },
});
const userDataDir = process.env.BROWSER_PROFILE
  ? path.resolve(process.env.BROWSER_PROFILE)
  : defaultProfileDirectory(rootDir, browser.id);
const profileName = String(process.env.BROWSER_PROFILE_NAME || "").trim();
const systemProfileDirectory = String(process.env.BROWSER_SYSTEM_PROFILE_DIRECTORY || "").trim();
const startUrl = process.env.START_URL || "https://www.wildberries.ru/lk";

if (browser.engine !== "firefox" && !systemProfileDirectory) prepareBrowserProfile(userDataDir, profileName);

const args = browser.engine === "firefox"
  ? ["-profile", userDataDir, "-new-window", startUrl]
  : [
      ...(!systemProfileDirectory ? [`--user-data-dir=${userDataDir}`] : []),
      `--profile-directory=${systemProfileDirectory || "Default"}`,
      "--no-first-run",
      "--new-window",
      startUrl,
    ];
const child = spawn(browser.executablePath, args, {
  detached: true,
  stdio: "ignore",
  windowsHide: false,
});
child.unref();
