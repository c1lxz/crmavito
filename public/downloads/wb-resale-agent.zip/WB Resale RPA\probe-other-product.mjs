﻿import { chromium } from 'playwright';
const context = await chromium.launchPersistentContext('.browser-profile', { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(8000);
await page.goto('https://www.wildberries.ru/catalog/resale', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2500);
await page.locator("button:has-text('Продать что‑то своё')").first().click();
await page.waitForTimeout(2000);
await page.locator("button:has-text('Разместить объявление')").first().click();
await page.waitForTimeout(1500);
const other = page.getByText('Другой товар', { exact: true }).first();
console.log('other count', await other.count(), 'visible', await other.isVisible().catch(()=>false));
await other.click();
await page.waitForTimeout(4000);
console.log('url', page.url());
const diag = await page.evaluate(() => ({
 text: document.body.innerText.slice(0,3000),
 inputs: [...document.querySelectorAll('input,textarea,select')].map(el => ({tag:el.tagName,name:el.getAttribute('name'),placeholder:el.getAttribute('placeholder'),type:el.getAttribute('type'),cls:String(el.className||'').slice(0,80),visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible).slice(0,120),
 buttons: [...document.querySelectorAll('button,[role="button"],a,label')].map(el => ({tag:el.tagName,text:(el.innerText||el.textContent||'').trim().replace(/\s+/g,' '),href:el.href||el.getAttribute('href')||'',cls:String(el.className||'').slice(0,80),visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible && x.text).slice(0,160)
}));
console.log(JSON.stringify(diag,null,2));
await page.screenshot({ path: 'logs/probe-after-other-product.png', fullPage: true });
await context.close();
