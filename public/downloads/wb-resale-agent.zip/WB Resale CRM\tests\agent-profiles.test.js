const assert = require("node:assert/strict");
const path = require("node:path");
const test = require("node:test");
const {
  addAgentProfile,
  agentProfileDirectory,
  getAgentProfile,
  normalizeAgentSettings,
  selectAgentProfile,
} = require("../agent-profiles");

test("old settings migrate to the preserved default Chrome profile", () => {
  const settings = normalizeAgentSettings({ browser: "chrome" });
  assert.deepEqual(settings.profiles.chrome, [{ id: "default", name: "Основной аккаунт" }]);
  assert.equal(settings.selectedProfiles.chrome, "default");
  assert.equal(
    agentProfileDirectory("C:\\agent", "chrome", "default"),
    path.join("C:\\agent", ".browser-profile-chrome"),
  );
});

test("additional accounts get isolated persistent browser directories", () => {
  const initial = normalizeAgentSettings({ browser: "chrome" });
  const created = addAgentProfile(initial, "chrome", "Магазин Москва", 123456);
  const selected = selectAgentProfile(created.settings, "chrome", created.profile.id);

  assert.equal(getAgentProfile(selected.settings, "chrome", created.profile.id).name, "Магазин Москва");
  assert.match(agentProfileDirectory("C:\\agent", "chrome", created.profile.id), /\.browser-profile-chrome-.+$/);
  assert.notEqual(
    agentProfileDirectory("C:\\agent", "chrome", created.profile.id),
    agentProfileDirectory("C:\\agent", "chrome", "default"),
  );
});
