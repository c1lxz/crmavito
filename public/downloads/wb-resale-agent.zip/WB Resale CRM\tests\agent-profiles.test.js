const assert = require("node:assert/strict");
const path = require("node:path");
const test = require("node:test");
const {
  addAgentProfile,
  agentProfileDirectory,
  getAgentProfile,
  installedBrowserProfiles,
  normalizeAgentSettings,
  resolveInstalledBrowserProfile,
  selectAgentProfile,
} = require("../agent-profiles");

test("old settings migrate to the preserved default Chrome profile", () => {
  const settings = normalizeAgentSettings({ browser: "chrome" });
  assert.deepEqual(settings.profiles.chrome, [{ id: "default", name: "Основной аккаунт" }]);
  assert.equal(settings.selectedProfiles.chrome, "default");
  assert.equal(
    agentProfileDirectory("C:\\agent", "chrome", "default"),
    path.join("C:\\agent", ".browser-profile-chrome"),
  );
});

test("installed Chrome profiles resolve to their real profile directories", () => {
  let settings = normalizeAgentSettings({ browser: "chrome" });
  const created = addAgentProfile(settings, "chrome", "c1lxz", 123456);
  settings = created.settings;
  const localState = JSON.stringify({
    profile: {
      profiles_order: ["Default", "Profile 3", "Profile 2"],
      info_cache: {
        Default: { name: "Пользователь 1", gaia_name: "Николай Мороз", user_name: "nikolay@example.com" },
        "Profile 2": { name: "c1lxz", user_name: "c1lxz@example.com" },
        "Profile 3": { name: "вбп", user_name: "" },
      },
    },
  });
  const options = { userDataDir: "C:\\Chrome\\User Data", readFileSync: () => localState };

  assert.deepEqual(installedBrowserProfiles("chrome", options).map((profile) => profile.displayName), ["Николай", "вбп", "c1lxz"]);
  assert.equal(resolveInstalledBrowserProfile(settings, "chrome", created.profile.id, options).systemProfileDirectory, "Profile 2");
  assert.equal(resolveInstalledBrowserProfile(settings, "chrome", "default", options).name, "Николай");
});

test("additional accounts get isolated persistent browser directories", () => {
  const initial = normalizeAgentSettings({ browser: "chrome" });
  const created = addAgentProfile(initial, "chrome", "Магазин Москва", 123456);
  const selected = selectAgentProfile(created.settings, "chrome", created.profile.id);

  assert.equal(getAgentProfile(selected.settings, "chrome", created.profile.id).name, "Магазин Москва");
  assert.match(agentProfileDirectory("C:\\agent", "chrome", created.profile.id), /\.browser-profile-chrome-.+$/);
  assert.notEqual(
    agentProfileDirectory("C:\\agent", "chrome", created.profile.id),
    agentProfileDirectory("C:\\agent", "chrome", "default"),
  );
});
