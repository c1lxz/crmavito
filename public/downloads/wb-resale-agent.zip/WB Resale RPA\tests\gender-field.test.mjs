import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const publisher = fs.readFileSync(path.join(here, "../src/publish-resale.mjs"), "utf8");

test("publisher never interacts with the gender characteristic", () => {
  assert.doesNotMatch(publisher, /["']Пол["']/);
  assert.doesNotMatch(publisher, /specs\.gender/);
  assert.doesNotMatch(publisher, /унисекс/i);
  assert.match(publisher, /\["Цвет", specs\.color\]/);
  assert.match(publisher, /\["Состав", specs\.composition\]/);
});
