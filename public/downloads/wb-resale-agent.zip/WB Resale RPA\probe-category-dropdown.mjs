﻿import { chromium } from 'playwright';
const context = await chromium.launchPersistentContext('.browser-profile', { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(8000);
await page.goto('https://www.wildberries.ru/catalog/resale', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2000);
await page.locator("button:has-text('Продать что‑то своё')").first().click();
await page.waitForTimeout(1500);
await page.locator("button:has-text('Разместить объявление')").first().click();
await page.waitForTimeout(1000);
await page.getByText('Другой товар', { exact: true }).first().click();
await page.waitForTimeout(2500);
await page.locator("input[name='adCategory']").click();
await page.waitForTimeout(2500);
const diag = await page.evaluate(() => ({
 text: document.body.innerText.slice(0,5000),
 visible: [...document.querySelectorAll('button,[role="button"],div,span,input')].map(el => ({
  text:(el.innerText||el.textContent||el.getAttribute('placeholder')||el.getAttribute('aria-label')||'').trim().replace(/\s+/g,' '),
  tag:el.tagName, cls:String(el.className||'').slice(0,100),
  visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none'})()
 })).filter(x=>x.visible && x.text).slice(-200)
}));
console.log(JSON.stringify(diag,null,2));
await page.screenshot({ path: 'logs/probe-category-dropdown.png', fullPage: true });
await context.close();
