import fs from "node:fs";
import path from "node:path";

function compact(values) {
  return [...new Set(values.filter(Boolean))];
}

function browser(id, name, engine, paths) {
  return { id, name, engine, paths: compact(paths) };
}

export function installedBrowserCandidates(platform = process.platform, env = process.env) {
  if (platform === "win32") {
    return [
      browser("chrome", "Google Chrome", "chromium", [
        env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe"),
        env.ProgramFiles && path.join(env.ProgramFiles, "Google", "Chrome", "Application", "chrome.exe"),
        env["ProgramFiles(x86)"] && path.join(env["ProgramFiles(x86)"], "Google", "Chrome", "Application", "chrome.exe")
      ]),
      browser("yandex", "Яндекс.Браузер", "chromium", [
        env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, "Yandex", "YandexBrowser", "Application", "browser.exe"),
        env.ProgramFiles && path.join(env.ProgramFiles, "Yandex", "YandexBrowser", "Application", "browser.exe"),
        env["ProgramFiles(x86)"] && path.join(env["ProgramFiles(x86)"], "Yandex", "YandexBrowser", "Application", "browser.exe")
      ]),
      browser("edge", "Microsoft Edge", "chromium", [
        env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, "Microsoft", "Edge", "Application", "msedge.exe"),
        env.ProgramFiles && path.join(env.ProgramFiles, "Microsoft", "Edge", "Application", "msedge.exe"),
        env["ProgramFiles(x86)"] && path.join(env["ProgramFiles(x86)"], "Microsoft", "Edge", "Application", "msedge.exe")
      ]),
      browser("firefox", "Mozilla Firefox", "firefox", [
        env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, "Mozilla Firefox", "firefox.exe"),
        env.ProgramFiles && path.join(env.ProgramFiles, "Mozilla Firefox", "firefox.exe"),
        env["ProgramFiles(x86)"] && path.join(env["ProgramFiles(x86)"], "Mozilla Firefox", "firefox.exe")
      ])
    ];
  }

  if (platform === "darwin") {
    return [
      browser("chrome", "Google Chrome", "chromium", ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"]),
      browser("yandex", "Яндекс.Браузер", "chromium", ["/Applications/Yandex.app/Contents/MacOS/Yandex"]),
      browser("edge", "Microsoft Edge", "chromium", ["/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]),
      browser("firefox", "Mozilla Firefox", "firefox", ["/Applications/Firefox.app/Contents/MacOS/firefox"])
    ];
  }

  return [
    browser("chrome", "Google Chrome", "chromium", ["/usr/bin/google-chrome-stable", "/usr/bin/google-chrome"]),
    browser("yandex", "Яндекс.Браузер", "chromium", ["/usr/bin/yandex-browser-stable", "/usr/bin/yandex-browser"]),
    browser("edge", "Microsoft Edge", "chromium", ["/usr/bin/microsoft-edge-stable", "/usr/bin/microsoft-edge"]),
    browser("firefox", "Mozilla Firefox", "firefox", ["/usr/bin/firefox"])
  ];
}

export function resolveBrowserExecutable({
  preference = process.env.BROWSER || "chrome",
  executablePath = process.env.BROWSER_PATH || "",
  browserEngine = process.env.BROWSER_ENGINE || "",
  platform = process.platform,
  env = process.env,
  existsSync = fs.existsSync,
  playwrightExecutablePaths = {},
  playwrightExecutablePath = ""
} = {}) {
  const requested = String(preference).trim().toLowerCase() || "auto";
  const aliases = new Map([
    ["auto", "auto"],
    ["yandex", "yandex"],
    ["яндекс", "yandex"],
    ["chrome", "chrome"],
    ["google", "chrome"],
    ["edge", "edge"],
    ["microsoft", "edge"],
    ["msedge", "edge"],
    ["firefox", "firefox"],
    ["mozilla", "firefox"],
    ["chromium", "chromium"],
    ["playwright", "chromium"]
  ]);
  const normalized = aliases.get(requested);
  if (!normalized) {
    throw new Error(`Unknown BROWSER value "${preference}". Use chrome, yandex, edge, firefox or chromium.`);
  }

  if (executablePath) {
    const explicitPath = path.resolve(executablePath);
    if (!existsSync(explicitPath)) {
      throw new Error(`BROWSER_PATH does not exist: ${explicitPath}`);
    }
    const explicitEngine = String(browserEngine).trim().toLowerCase() ||
      (normalized === "firefox" || /firefox/i.test(path.basename(explicitPath)) ? "firefox" : "chromium");
    if (!["chromium", "firefox"].includes(explicitEngine)) {
      throw new Error('BROWSER_ENGINE must be "chromium" or "firefox".');
    }
    return { id: "custom", name: "Custom browser", engine: explicitEngine, executablePath: explicitPath };
  }

  const installed = installedBrowserCandidates(platform, env);
  const order = normalized === "auto"
    ? installed
    : installed.filter((candidate) => candidate.id === normalized);

  if (normalized === "firefox" &&
      playwrightExecutablePaths.firefox &&
      existsSync(playwrightExecutablePaths.firefox)) {
    return {
      id: "firefox",
      name: "Mozilla Firefox",
      engine: "firefox",
      executablePath: playwrightExecutablePaths.firefox
    };
  }

  for (const candidate of order) {
    const found = candidate.paths.find((browserPath) => existsSync(browserPath));
    if (found) {
      return {
        id: candidate.id,
        name: candidate.name,
        engine: candidate.engine,
        executablePath: found
      };
    }
  }

  const chromiumFallback = playwrightExecutablePaths.chromium || playwrightExecutablePath;
  if ((normalized === "auto" || normalized === "chromium") &&
      chromiumFallback &&
      existsSync(chromiumFallback)) {
    return {
      id: "chromium",
      name: "Playwright Chromium",
      engine: "chromium",
      executablePath: chromiumFallback
    };
  }

  const requestedName = {
    chrome: "Google Chrome",
    yandex: "Яндекс.Браузер",
    edge: "Microsoft Edge",
    firefox: "Mozilla Firefox"
  }[normalized];
  const locationHint = requestedName
    ? `Install ${requestedName} or choose another browser in CRM.`
    : "Install Google Chrome, Яндекс.Браузер, Microsoft Edge or Mozilla Firefox.";
  const playwrightHint = normalized === "chromium"
    ? " To use Playwright Chromium, run: npx playwright install chromium"
    : "";
  throw new Error(`No compatible browser was found. ${locationHint}${playwrightHint}`);
}

export function defaultProfileDirectory(rootDir, browserId) {
  const suffix = ["chrome", "yandex", "edge", "firefox"].includes(browserId)
    ? `-${browserId}`
    : "";
  return path.join(rootDir, `.browser-profile${suffix}`);
}

export function prepareBrowserProfile(userDataDir, profileName) {
  const name = String(profileName || "").replace(/\s+/g, " ").trim();
  const defaultDir = path.join(userDataDir, "Default");
  fs.mkdirSync(defaultDir, { recursive: true });

  updateJsonFile(path.join(defaultDir, "Preferences"), (preferences) => {
    preferences.profile ||= {};
    if (name) {
      preferences.profile.name = name;
      preferences.profile.is_using_default_name = false;
    }
    preferences.profile.exit_type = "Normal";
    preferences.profile.exited_cleanly = true;
  });

  updateJsonFile(path.join(userDataDir, "Local State"), (state) => {
    state.profile ||= {};
    state.profile.info_cache ||= {};
    state.profile.info_cache.Default ||= {};
    if (name) {
      state.profile.info_cache.Default.name = name;
      state.profile.info_cache.Default.is_using_default_name = false;
    }
    state.profile.profiles_order ||= ["Default"];
  });
}

function updateJsonFile(filePath, update) {
  let data = {};
  try {
    if (fs.existsSync(filePath)) data = JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    data = {};
  }
  update(data);
  fs.writeFileSync(filePath, JSON.stringify(data), "utf8");
}
