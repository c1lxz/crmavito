import fs from "node:fs";
import os from "node:os";
import path from "node:path";

function compact(values) {
  return [...new Set(values.filter(Boolean))];
}

export function installedBrowserCandidates(platform = process.platform, env = process.env) {
  if (platform === "win32") {
    return [
      {
        id: "yandex",
        name: "Yandex Browser",
        paths: compact([
          env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, "Yandex", "YandexBrowser", "Application", "browser.exe"),
          env.ProgramFiles && path.join(env.ProgramFiles, "Yandex", "YandexBrowser", "Application", "browser.exe"),
          env["ProgramFiles(x86)"] && path.join(env["ProgramFiles(x86)"], "Yandex", "YandexBrowser", "Application", "browser.exe")
        ])
      },
      {
        id: "chrome",
        name: "Google Chrome",
        paths: compact([
          env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, "Google", "Chrome", "Application", "chrome.exe"),
          env.ProgramFiles && path.join(env.ProgramFiles, "Google", "Chrome", "Application", "chrome.exe"),
          env["ProgramFiles(x86)"] && path.join(env["ProgramFiles(x86)"], "Google", "Chrome", "Application", "chrome.exe")
        ])
      }
    ];
  }

  if (platform === "darwin") {
    return [
      { id: "yandex", name: "Yandex Browser", paths: ["/Applications/Yandex.app/Contents/MacOS/Yandex"] },
      { id: "chrome", name: "Google Chrome", paths: ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"] }
    ];
  }

  return [
    { id: "yandex", name: "Yandex Browser", paths: ["/usr/bin/yandex-browser-stable", "/usr/bin/yandex-browser"] },
    { id: "chrome", name: "Google Chrome", paths: ["/usr/bin/google-chrome-stable", "/usr/bin/google-chrome"] }
  ];
}

export function resolveBrowserExecutable({
  preference = process.env.BROWSER || "auto",
  executablePath = process.env.BROWSER_PATH || "",
  platform = process.platform,
  env = process.env,
  existsSync = fs.existsSync,
  playwrightExecutablePath = ""
} = {}) {
  const requested = String(preference).trim().toLowerCase() || "auto";
  const aliases = new Map([
    ["auto", "auto"],
    ["yandex", "yandex"],
    ["яндекс", "yandex"],
    ["chrome", "chrome"],
    ["google", "chrome"],
    ["chromium", "chromium"],
    ["playwright", "chromium"]
  ]);
  const normalized = aliases.get(requested);
  if (!normalized) {
    throw new Error(`Unknown BROWSER value "${preference}". Use auto, yandex, chrome or chromium.`);
  }

  if (executablePath) {
    const explicitPath = path.resolve(executablePath);
    if (!existsSync(explicitPath)) {
      throw new Error(`BROWSER_PATH does not exist: ${explicitPath}`);
    }
    return { id: "custom", name: "Custom Chromium browser", executablePath: explicitPath };
  }

  const installed = installedBrowserCandidates(platform, env);
  const order = normalized === "auto"
    ? installed
    : installed.filter((browser) => browser.id === normalized);

  for (const browser of order) {
    const found = browser.paths.find((candidate) => existsSync(candidate));
    if (found) return { id: browser.id, name: browser.name, executablePath: found };
  }

  if ((normalized === "auto" || normalized === "chromium") &&
      playwrightExecutablePath &&
      existsSync(playwrightExecutablePath)) {
    return {
      id: "chromium",
      name: "Playwright Chromium",
      executablePath: playwrightExecutablePath
    };
  }

  const locationHint = platform === "win32"
    ? "Install Yandex Browser or Google Chrome, or set BROWSER_PATH to browser.exe."
    : "Install Yandex Browser or Google Chrome, or set BROWSER_PATH to the browser executable.";
  const playwrightHint = normalized === "chromium"
    ? " To use Playwright Chromium, run: npx playwright install chromium"
    : "";
  throw new Error(`No compatible browser was found. ${locationHint}${playwrightHint}`);
}

export function defaultProfileDirectory(rootDir, browserId) {
  const suffix = browserId === "yandex" ? "-yandex" : browserId === "chrome" ? "-chrome" : "";
  return path.join(rootDir, `.browser-profile${suffix}`);
}

