﻿import { chromium } from 'playwright';
const userDataDir = 'C:/Users/c1lxz/Desktop/WB Resale RPA/.browser-profile';
const context = await chromium.launchPersistentContext(userDataDir, { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
async function matches(label) {
  const data = await page.evaluate(() => {
    const terms = /(прод|объяв|созд|размест|мои|ресейл|ресе|рейс|sell|sale)/i;
    return [...document.querySelectorAll('a,button,[role="button"],div,span,input,textarea')]
      .map((el) => ({
        text:(el.innerText||el.textContent||el.getAttribute('placeholder')||el.getAttribute('aria-label')||'').trim().replace(/\s+/g,' '),
        href:el.href||el.getAttribute('href')||'',
        tag:el.tagName,
        cls:String(el.className||'').slice(0,100),
        visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none'})()
      }))
      .filter(x => terms.test(x.text) || terms.test(x.href) || terms.test(x.cls))
      .slice(0,300);
  });
  console.log('\n---', label, page.url(), '---');
  console.log(JSON.stringify(data, null, 2));
}
await page.goto('https://www.wildberries.ru/catalog/resale', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(5000);
await matches('initial');
await page.locator('.navbar-pc__link:has-text("Профиль"), a:has-text("Профиль")').first().click().catch(e=>console.log('profile click failed', e.message));
await page.waitForTimeout(3000);
await matches('after profile click');
await page.goto('https://www.wildberries.ru/catalog/resale', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2000);
await page.locator('button[aria-label*="Навигация"], button:has-text("Навигация"), .j-menu-burger-btn').first().click().catch(e=>console.log('burger click failed', e.message));
await page.waitForTimeout(2000);
await matches('after burger click');
await page.screenshot({ path: 'C:/Users/c1lxz/Desktop/WB Resale RPA/logs/probe-create-entry.png', fullPage: true });
await context.close();
