function xmlEscape(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&apos;");
}

function listingImages(value) {
  return [...new Set(String(value || "").split(",").map((item) => item.trim()).filter(Boolean))];
}

function buildWbPublicationXml(rows, options = {}) {
  const generatedAt = options.generatedAt instanceof Date
    ? options.generatedAt.toISOString()
    : String(options.generatedAt || new Date().toISOString());
  const profileId = String(options.profileId || "default");
  const profileName = String(options.profileName || "Основной аккаунт");

  const ads = rows.map((row) => {
    const images = listingImages(row.photos)
      .map((image) => `      <Image url="${xmlEscape(image)}" />`)
      .join("\n");
    return [
      "  <Ad>",
      `    <Id>${xmlEscape(row.sku)}</Id>`,
      `    <Title>${xmlEscape(row.title)}</Title>`,
      `    <Category>${xmlEscape(row.category)}</Category>`,
      `    <Price>${xmlEscape(row.price)}</Price>`,
      `    <Quantity>${xmlEscape(row.quantity)}</Quantity>`,
      `    <Condition>${xmlEscape(row.condition)}</Condition>`,
      `    <Description>${xmlEscape(row.description)}</Description>`,
      `    <Characteristics>${xmlEscape(row.characteristics)}</Characteristics>`,
      `    <PickupPoint>${xmlEscape(row.pickup_point)}</PickupPoint>`,
      `    <AllowOffers>${row.allow_offers ? "true" : "false"}</AllowOffers>`,
      `    <DraftOnly>${row.draft_only ? "true" : "false"}</DraftOnly>`,
      "    <Images>",
      images,
      "    </Images>",
      "  </Ad>",
    ].join("\n");
  }).join("\n");

  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<Ads target="Wildberries" formatVersion="1" generatedAt="${xmlEscape(generatedAt)}" profileId="${xmlEscape(profileId)}" profileName="${xmlEscape(profileName)}">`,
    ads,
    "</Ads>",
    "",
  ].join("\n");
}

module.exports = { buildWbPublicationXml, listingImages, xmlEscape };
