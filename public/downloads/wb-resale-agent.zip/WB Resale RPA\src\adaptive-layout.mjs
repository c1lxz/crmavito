export function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  if (max < min) return min;
  return Math.min(max, Math.max(min, value));
}

export function pointInsideRect(rect, viewport, options = {}) {
  const margin = Math.max(4, Number(options.margin) || 12);
  const width = Math.max(1, Number(viewport?.width) || 1);
  const height = Math.max(1, Number(viewport?.height) || 1);
  const left = clamp(Number(rect?.left) || 0, 0, width - 1);
  const top = clamp(Number(rect?.top) || 0, 0, height - 1);
  const right = clamp(Number(rect?.right) || width, left + 1, width);
  const bottom = clamp(Number(rect?.bottom) || height, top + 1, height);
  const minX = Math.min(right - 1, left + margin);
  const maxX = Math.max(minX, right - margin);
  const minY = Math.min(bottom - 1, top + margin);
  const maxY = Math.max(minY, bottom - margin);
  const xRatio = clamp(Number(options.xRatio ?? 0.5), 0, 1);
  const yRatio = clamp(Number(options.yRatio ?? 0.68), 0, 1);

  return {
    x: Math.round(clamp(left + (right - left) * xRatio, minX, maxX)),
    y: Math.round(clamp(top + (bottom - top) * yRatio, minY, maxY)),
  };
}

export async function readAdaptiveLayout(page) {
  return page.evaluate(() => {
    const visible = (element) => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width > 5
        && rect.height > 5
        && rect.bottom > 0
        && rect.right > 0
        && rect.top < innerHeight
        && rect.left < innerWidth
        && style.display !== "none"
        && style.visibility !== "hidden";
    };
    const norm = (value) => String(value || "").trim().replace(/\s+/g, " ");
    const candidates = [...document.querySelectorAll(
      "[role='dialog'],.mo-modal__paper,[class*='modalContent'],[class*='popupContent'],[class*='adFormWrapper']"
    )]
      .filter(visible)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const text = norm(element.innerText || element.textContent || "");
        const zIndex = Number.parseInt(getComputedStyle(element).zIndex, 10);
        return {
          element,
          rect,
          text,
          zIndex: Number.isFinite(zIndex) ? zIndex : 0,
          isSaleForm: /Объявление о продаже|Характеристики/.test(text),
        };
      })
      .sort((a, b) => (
        Number(a.isSaleForm) - Number(b.isSaleForm)
        || a.zIndex - b.zIndex
        || (b.rect.width * b.rect.height) - (a.rect.width * a.rect.height)
      ));
    const active = candidates.at(-1);
    const rect = active?.rect || {
      left: 0,
      top: 0,
      right: innerWidth,
      bottom: innerHeight,
      width: innerWidth,
      height: innerHeight,
    };

    return {
      viewport: {
        width: innerWidth,
        height: innerHeight,
        devicePixelRatio,
      },
      surface: {
        left: Math.max(0, rect.left),
        top: Math.max(0, rect.top),
        right: Math.min(innerWidth, rect.right),
        bottom: Math.min(innerHeight, rect.bottom),
        width: Math.min(innerWidth, rect.right) - Math.max(0, rect.left),
        height: Math.min(innerHeight, rect.bottom) - Math.max(0, rect.top),
      },
      hasActiveSurface: Boolean(active),
      surfaceText: active?.text.slice(0, 120) || "",
    };
  });
}

export async function wheelInsideActiveSurface(page, deltaY) {
  const layout = await readAdaptiveLayout(page);
  const point = pointInsideRect(layout.surface, layout.viewport, { xRatio: 0.56, yRatio: 0.7 });
  await page.mouse.move(point.x, point.y);
  await page.mouse.wheel(0, deltaY);
  return { ...layout, point };
}

export async function maximizeBrowserWindow(page, engine) {
  if (engine !== "chromium") return false;
  const session = await page.context().newCDPSession(page).catch(() => null);
  if (!session) return false;
  try {
    const { windowId } = await session.send("Browser.getWindowForTarget");
    await session.send("Browser.setWindowBounds", {
      windowId,
      bounds: { windowState: "maximized" },
    });
    return true;
  } catch {
    return false;
  } finally {
    await session.detach().catch(() => {});
  }
}

export async function logAdaptiveLayout(page, log, reason = "layout") {
  const layout = await readAdaptiveLayout(page);
  log(
    `${reason}: ${layout.viewport.width}x${layout.viewport.height}`
    + ` @${layout.viewport.devicePixelRatio}`
    + (layout.hasActiveSurface
      ? `, active surface ${Math.round(layout.surface.width)}x${Math.round(layout.surface.height)}`
      : ""),
  );
  return layout;
}
