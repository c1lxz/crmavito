﻿import { chromium } from 'playwright';
const userDataDir = 'C:/Users/c1lxz/Desktop/WB Resale RPA/.browser-profile';
const context = await chromium.launchPersistentContext(userDataDir, { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
async function dump(label) {
  console.log(label, page.url());
  const data = await page.evaluate(() => [...document.querySelectorAll('a,button,[role="button"],input,textarea')].map((el) => ({
    text:(el.innerText||el.textContent||el.getAttribute('placeholder')||el.getAttribute('aria-label')||'').trim().replace(/\s+/g,' '),
    href:el.href||el.getAttribute('href')||'',
    role:el.getAttribute('role')||'',
    tag:el.tagName,
    cls:String(el.className || '').slice(0,120)
  })).filter(x=>x.text || x.href).slice(0,240));
  console.log(JSON.stringify(data, null, 2));
}
await page.goto('https://www.wildberries.ru/catalog/resale', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(5000);
await dump('URL1');
const resale = page.getByText('Ресейл', { exact: true }).first();
if (await resale.count()) {
  await resale.click();
  await page.waitForTimeout(5000);
  await dump('URL2');
}
await page.screenshot({ path: 'C:/Users/c1lxz/Desktop/WB Resale RPA/logs/probe-resale.png', fullPage: true });
await context.close();
