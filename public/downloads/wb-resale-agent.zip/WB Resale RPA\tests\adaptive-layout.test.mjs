import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { chromium } from "playwright";
import {
  pointInsideRect,
  readAdaptiveLayout,
  wheelInsideActiveSurface,
} from "../src/adaptive-layout.mjs";

const screens = [
  { width: 640, height: 480 },
  { width: 768, height: 1024 },
  { width: 800, height: 600 },
  { width: 1024, height: 768 },
  { width: 1280, height: 720 },
  { width: 1280, height: 800 },
  { width: 1366, height: 768 },
  { width: 1536, height: 864 },
  { width: 1920, height: 1080 },
  { width: 2560, height: 1080 },
];

test("adaptive point always stays inside the visible sale dialog", () => {
  for (const viewport of screens) {
    const rect = {
      left: viewport.width * 0.08,
      top: 20,
      right: viewport.width * 0.92,
      bottom: viewport.height - 18,
    };
    const point = pointInsideRect(rect, viewport);
    assert.ok(point.x > rect.left && point.x < rect.right, `${viewport.width}x${viewport.height}: x`);
    assert.ok(point.y > rect.top && point.y < rect.bottom, `${viewport.width}x${viewport.height}: y`);
  }
});

test("active-surface scrolling adapts to laptop and desktop viewports", async () => {
  const chromeCandidates = [
    path.join(process.env.ProgramFiles || "", "Google", "Chrome", "Application", "chrome.exe"),
    path.join(process.env["ProgramFiles(x86)"] || "", "Google", "Chrome", "Application", "chrome.exe"),
  ];
  const executablePath = chromeCandidates.find((candidate) => fs.existsSync(candidate));
  const browser = await chromium.launch({ headless: true, ...(executablePath ? { executablePath } : {}) });
  try {
    for (const viewport of screens) {
      const page = await browser.newPage({ viewport });
      await page.setContent(`
        <style>
          html,body { margin: 0; width: 100%; height: 100%; }
          #background { position: fixed; inset: 0; }
          [role=dialog] {
            position: fixed;
            left: 7vw;
            right: 7vw;
            top: 16px;
            max-height: calc(100vh - 32px);
            overflow: auto;
            background: white;
          }
          #content { height: 2200px; }
        </style>
        <button id="background">background</button>
        <section role="dialog">
          <h1>Объявление о продаже</h1>
          <div id="content">form</div>
        </section>
      `);

      const layout = await readAdaptiveLayout(page);
      assert.equal(layout.viewport.width, viewport.width);
      assert.equal(layout.viewport.height, viewport.height);
      assert.equal(layout.hasActiveSurface, true);

      const result = await wheelInsideActiveSurface(page, 500);
      const inside = await page.evaluate(({ x, y }) => {
        const dialog = document.querySelector("[role=dialog]");
        const hit = document.elementFromPoint(x, y);
        return Boolean(hit && dialog.contains(hit));
      }, result.point);
      assert.equal(inside, true, `${viewport.width}x${viewport.height}: pointer left the dialog`);

      await page.waitForTimeout(50);
      const scrollTop = await page.locator("[role=dialog]").evaluate((element) => element.scrollTop);
      assert.ok(scrollTop > 0, `${viewport.width}x${viewport.height}: dialog did not scroll`);
      await page.close();
    }
  } finally {
    await browser.close();
  }
});
