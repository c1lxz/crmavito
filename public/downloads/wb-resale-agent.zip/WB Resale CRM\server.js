const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { spawn, spawnSync } = require("node:child_process");
const { URL } = require("node:url");
const { DatabaseSync } = require("node:sqlite");
const {
  addAgentProfile,
  agentProfileDirectory,
  getAgentProfile,
  listAgentProfiles,
  normalizeAgentSettings,
  normalizeBrowser: normalizeBrowserPreference,
  selectAgentProfile,
} = require("./agent-profiles");
const { buildWbPublicationXml } = require("./publication-xml");

const rootDir = __dirname;
const dataDir = path.join(rootDir, "data");
const publicDir = path.join(rootDir, "public");
const dbPath = path.join(dataDir, "app.db");
const settingsPath = path.join(dataDir, "settings.json");
const exportsDir = path.join(dataDir, "exports");
const latestXmlPath = path.join(exportsDir, "wb-publication-latest.xml");
const desktopDir = path.join(process.env.USERPROFILE || "", "Desktop");
const rpaDir = path.join(desktopDir, "WB Resale RPA");
const desktopRpaCsv = path.join(rpaDir, "items.csv");
const rpaPhotosDir = path.join(rpaDir, "photos");
const port = Number(process.env.PORT || 3017);
const AGENT_VERSION = "2026.07.31.1";
const XML_LISTING_SIZES = ["XXS", "XS", "S", "M", "L", "XL", "2XL"];
const SIZE_GUIDE_URL = "https://crmavito.duckdns.org/assets/ky-strok-size-guide-v2.jpg";
const DEFAULT_PICKUP_POINT = "Москва, Новоспасский Переулок 3к2";

fs.mkdirSync(exportsDir, { recursive: true });
let agentSettings = loadAgentSettings();

const db = new DatabaseSync(dbPath);
db.exec(`
  CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT '',
    photos TEXT NOT NULL DEFAULT '',
    price INTEGER NOT NULL DEFAULT 0,
    allow_offers INTEGER NOT NULL DEFAULT 1,
    quantity INTEGER NOT NULL DEFAULT 1,
    condition TEXT NOT NULL DEFAULT 'Хорошее',
    description TEXT NOT NULL DEFAULT '',
    characteristics TEXT NOT NULL DEFAULT '',
    pickup_point TEXT NOT NULL DEFAULT '',
    accept_rules INTEGER NOT NULL DEFAULT 1,
    draft_only INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft',
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
for (const migration of [
  "ALTER TABLE listings ADD COLUMN listing_url TEXT NOT NULL DEFAULT ''",
  "ALTER TABLE listings ADD COLUMN profile_id TEXT NOT NULL DEFAULT ''",
]) {
  try {
    db.exec(migration);
  } catch (error) {
    if (!String(error.message || error).includes("duplicate column name")) throw error;
  }
}

let rpaProcess = null;
let activeProfileId = "";
let stopRequested = false;
let rpaState = { running: false, exitCode: null, startedAt: null, endedAt: null };
let rpaEvents = [];
const sseClients = new Set();

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      sendCorsPreflight(res);
      return;
    }
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) {
      await handleApi(req, res, url);
      return;
    }
    serveStatic(res, url.pathname);
  } catch (error) {
    sendJson(res, 500, { error: error.message || String(error) });
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`WB Resale CRM: http://127.0.0.1:${port}`);
  console.log(`SQLite: ${dbPath}`);
});

async function handleApi(req, res, url) {
  if (req.method === "GET" && url.pathname === "/api/events") {
    handleEvents(req, res);
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/rpa/status") {
    sendJson(res, 200, {
      version: AGENT_VERSION,
      browser: agentSettings.browser,
      ...rpaState,
      events: rpaEvents.slice(-120)
    });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/rpa/profiles") {
    sendJson(res, 200, {
      browser: agentSettings.browser,
      profiles: listAgentProfiles(agentSettings, agentSettings.browser),
      selectedProfileId: agentSettings.selectedProfiles[agentSettings.browser] || "default",
    });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/profiles") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "Сначала остановите текущую работу агента." });
      return;
    }
    const body = await readJson(req);
    const created = addAgentProfile(agentSettings, agentSettings.browser, body.name);
    agentSettings = created.settings;
    saveAgentSettings(agentSettings);
    sendJson(res, 201, {
      ok: true,
      browser: agentSettings.browser,
      profile: created.profile,
      profiles: listAgentProfiles(agentSettings, agentSettings.browser),
      selectedProfileId: created.profile.id,
    });
    return;
  }

  if (req.method === "PATCH" && url.pathname === "/api/rpa/browser") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "Сначала остановите текущую работу агента." });
      return;
    }
    const body = await readJson(req);
    agentSettings = normalizeAgentSettings({ ...agentSettings, browser: normalizeBrowser(body.browser) });
    saveAgentSettings(agentSettings);
    sendJson(res, 200, { ok: true, browser: agentSettings.browser });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/start") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "RPA уже запущен" });
      return;
    }
    const body = await readJson(req);
    const selected = selectAgentProfile(agentSettings, agentSettings.browser, body.profileId);
    agentSettings = selected.settings;
    saveAgentSettings(agentSettings);
    const files = writePublicationFiles(selected.profile);
    startRpa("publish", selected.profile);
    sendJson(res, 200, { ok: true, ...files, profile: selected.profile });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/test") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "RPA уже запущен" });
      return;
    }
    const body = await readJson(req);
    const selected = selectAgentProfile(agentSettings, agentSettings.browser, body.profileId);
    agentSettings = selected.settings;
    saveAgentSettings(agentSettings);
    const files = writePublicationFiles(selected.profile);
    startRpa("test", selected.profile);
    sendJson(res, 200, { ok: true, ...files, profile: selected.profile, mode: "test" });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/dry-run") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "RPA уже запущен" });
      return;
    }
    const body = await readJson(req);
    const selected = selectAgentProfile(agentSettings, agentSettings.browser, body.profileId);
    agentSettings = selected.settings;
    saveAgentSettings(agentSettings);
    const files = writePublicationFiles(selected.profile);
    startRpa("dry-run", selected.profile);
    sendJson(res, 200, { ok: true, ...files, profile: selected.profile, mode: "dry-run" });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/stop") {
    if (rpaProcess) {
      const child = rpaProcess;
      stopRequested = true;
      db.prepare("UPDATE listings SET status = 'ready', note = 'Остановлено пользователем', updated_at = CURRENT_TIMESTAMP WHERE status = 'exported'").run();
      db.prepare("UPDATE listings SET status = 'error', note = 'Остановлено пользователем. Проверьте карточку в WB перед повторным запуском.', updated_at = CURRENT_TIMESTAMP WHERE status = 'running'").run();
      pushRpaEvent({ type: "run", status: "stopping", message: "Останавливаю RPA" });
      if (process.platform === "win32" && child.pid) {
        const killed = spawnSync("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], { windowsHide: true });
        if (killed.status !== 0) child.kill("SIGTERM");
      } else {
        child.kill("SIGTERM");
      }
    }
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/clear-log") {
    rpaEvents = [];
    broadcast({ type: "clear" });
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/listings") {
    const rows = db.prepare("SELECT * FROM listings WHERE status != 'archived' ORDER BY updated_at DESC, id DESC").all().map(fromDb);
    sendJson(res, 200, rows);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/listings") {
    const body = normalizeListing(await readJson(req));
    const saved = saveListingOrBatch(body);
    sendJson(res, 200, { ok: true, saved });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/uploads") {
    const body = await readJson(req, 120_000_000);
    const result = saveUploadedPhotos(body);
    sendJson(res, 200, result);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/import/xml") {
    const body = await readJson(req, 120_000_000);
    const result = await importXmlListings(body);
    sendJson(res, 200, result);
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/export.xml") {
    const profile = getAgentProfile(agentSettings, agentSettings.browser, url.searchParams.get("profileId"));
    const rows = publicationRows();
    if (!rows.length) throw new Error("В очереди нет объявлений для XML.");
    const xml = buildWbPublicationXml(rows, { profileId: profile.id, profileName: profile.name });
    res.writeHead(200, {
      ...corsHeaders(),
      "content-type": "application/xml; charset=utf-8",
      "content-disposition": "attachment; filename=\"wb-publication.xml\"",
    });
    res.end(xml);
    return;
  }

  if (req.method === "GET" && url.pathname.startsWith("/api/photos/")) {
    serveRpaPhoto(res, decodeURIComponent(url.pathname.replace("/api/photos/", "")));
    return;
  }

  if (req.method === "PATCH" && url.pathname.startsWith("/api/listings/")) {
    const sku = decodeURIComponent(url.pathname.split("/").pop());
    const body = await readJson(req);
    const status = String(body.status || "draft");
    const note = String(body.note || "");
    db.prepare("UPDATE listings SET status = ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE sku = ?").run(status, note, sku);
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "DELETE" && url.pathname.startsWith("/api/listings/")) {
    const sku = decodeURIComponent(url.pathname.split("/").pop());
    db.prepare("DELETE FROM listings WHERE sku = ?").run(sku);
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "POST" && url.pathname.endsWith("/delete-wb") && url.pathname.startsWith("/api/listings/")) {
    if (rpaProcess) {
      sendJson(res, 409, { error: "Сначала остановите текущую работу агента" });
      return;
    }
    const parts = url.pathname.split("/");
    const sku = decodeURIComponent(parts[3] || "");
    const listing = db.prepare("SELECT * FROM listings WHERE sku = ?").get(sku);
    if (!listing) {
      sendJson(res, 404, { error: "Объявление не найдено" });
      return;
    }
    startDeleteRpa(listing);
    sendJson(res, 202, { ok: true, sku });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/export.csv") {
    const csv = buildCsv();
    res.writeHead(200, {
      ...corsHeaders(),
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": "attachment; filename=\"items.csv\""
    });
    res.end("\uFEFF" + csv);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/export-to-rpa") {
    const csvPath = writeRpaCsv();
    sendJson(res, 200, { ok: true, path: csvPath });
    return;
  }

  sendJson(res, 404, { error: "Not found" });
}

function startRpa(mode, profile) {
  stopRequested = false;
  activeProfileId = profile.id;
  rpaEvents = [];
  rpaState = { running: true, exitCode: null, startedAt: new Date().toISOString(), endedAt: null, profile };
  const isTest = mode === "test";
  const isDryRun = mode === "dry-run";
  pushRpaEvent({ type: "run", status: "starting", message: isTest ? "Запускаю тест на локальной форме" : isDryRun ? "Проверяю WB без публикации" : "Запускаю браузер и RPA" });

  rpaProcess = spawn(process.execPath, ["src/publish-resale.mjs"], {
    cwd: rpaDir,
    env: {
      ...process.env,
      BROWSER: agentSettings.browser,
      BROWSER_PROFILE: agentProfileDirectory(rpaDir, agentSettings.browser, profile.id),
      AUTO_PUBLISH: isTest || isDryRun ? "0" : "1",
      AUTO_OPEN_FORM: "1",
      NO_PAUSE: "1",
      KEEP_BROWSER_OPEN_ON_ERROR: "1",
      WAIT_FOR_LOGIN: isTest ? "0" : "1",
      START_URL: isTest ? `file:///${path.join(rpaDir, "tests", "mock-wb-form.html").replaceAll("\\", "/")}` : ""
    },
    windowsHide: true
  });

  rpaProcess.stdout.on("data", (chunk) => handleRpaOutput(chunk.toString("utf8"), "stdout"));
  rpaProcess.stderr.on("data", (chunk) => handleRpaOutput(chunk.toString("utf8"), "stderr"));
  rpaProcess.on("exit", (code) => {
    const wasStopped = stopRequested;
    if (code !== 0) {
      db.prepare("UPDATE listings SET status = 'ready' WHERE status = 'exported'").run();
    }
    rpaState = { ...rpaState, running: false, exitCode: code, endedAt: new Date().toISOString() };
    const detailedFailure = !wasStopped && code !== 0 && rpaEvents.some((event) => (
      event.type === "run" && event.status === "failed" && event.message && !/^RPA завершился с кодом/.test(event.message)
    ));
    if (wasStopped) {
      pushRpaEvent({ type: "run", status: "stopped", message: "Агент остановлен пользователем" });
    } else if (code === 0 || !detailedFailure) {
      pushRpaEvent({ type: "run", status: code === 0 ? "done" : "failed", message: `RPA завершился с кодом ${code}` });
    } else {
      pushRpaEvent({ type: "log", level: "error", message: `Процесс RPA завершился с кодом ${code}` });
    }
    stopRequested = false;
    activeProfileId = "";
    rpaProcess = null;
  });
}

function startDeleteRpa(listing) {
  const profile = getAgentProfile(agentSettings, agentSettings.browser, listing.profile_id || undefined);
  rpaEvents = [];
  rpaState = { running: true, exitCode: null, startedAt: new Date().toISOString(), endedAt: null };
  db.prepare("UPDATE listings SET status = 'running', note = 'Удаляю в Wildberries', updated_at = CURRENT_TIMESTAMP WHERE sku = ?").run(listing.sku);
  pushRpaEvent({ type: "run", status: "starting", message: `Удаляю «${listing.title}»` });

  rpaProcess = spawn(process.execPath, ["src/delete-resale.mjs"], {
    cwd: rpaDir,
    env: {
      ...process.env,
      BROWSER: agentSettings.browser,
      BROWSER_PROFILE: agentProfileDirectory(rpaDir, agentSettings.browser, profile.id),
      DELETE_SKU: listing.sku,
      DELETE_TITLE: listing.title,
      DELETE_URL: listing.listing_url || "",
      NO_PAUSE: "1",
    },
    windowsHide: true,
  });

  rpaProcess.stdout.on("data", (chunk) => handleRpaOutput(chunk.toString("utf8"), "stdout"));
  rpaProcess.stderr.on("data", (chunk) => handleRpaOutput(chunk.toString("utf8"), "stderr"));
  rpaProcess.on("exit", (code) => {
    if (code === 0) {
      db.prepare("DELETE FROM listings WHERE sku = ?").run(listing.sku);
    } else {
      db.prepare("UPDATE listings SET status = 'error', note = 'Не удалось удалить объявление в WB', updated_at = CURRENT_TIMESTAMP WHERE sku = ?").run(listing.sku);
    }
    rpaState = { ...rpaState, running: false, exitCode: code, endedAt: new Date().toISOString() };
    pushRpaEvent({ type: "run", status: code === 0 ? "done" : "failed", message: code === 0 ? "Объявление удалено" : "Удаление не выполнено" });
    rpaProcess = null;
  });
}

function handleRpaOutput(text, stream) {
  for (const line of text.split(/\r?\n/).filter(Boolean)) {
    if (line.startsWith("EVENT_JSON:")) {
      try {
        const event = JSON.parse(line.slice("EVENT_JSON:".length));
        pushRpaEvent(event);
        if (event.type === "item" && event.id) {
          syncListingStatus(event);
        }
      } catch {
        pushRpaEvent({ type: "log", level: "error", message: line });
      }
    } else {
      pushRpaEvent({ type: "log", level: stream === "stderr" ? "error" : "info", message: line });
    }
  }
}

function syncListingStatus(event) {
  const statusMap = {
    running: "running",
    publishing: "running",
    submitted: "moderation",
    draft_review: "ready",
    error: "error"
  };
  const status = statusMap[event.status];
  if (!status) return;
  db.prepare("UPDATE listings SET status = ?, note = ?, listing_url = COALESCE(NULLIF(?, ''), listing_url), profile_id = COALESCE(NULLIF(?, ''), profile_id), updated_at = CURRENT_TIMESTAMP WHERE sku = ?").run(
    status,
    event.message || "",
    event.listing_url || "",
    activeProfileId,
    event.id
  );
}

function pushRpaEvent(event) {
  const full = { time: new Date().toISOString(), ...event };
  rpaEvents.push(full);
  if (rpaEvents.length > 500) rpaEvents = rpaEvents.slice(-500);
  broadcast(full);
}

function broadcast(event) {
  const data = `data: ${JSON.stringify(event)}\n\n`;
  for (const client of sseClients) client.write(data);
}

function handleEvents(req, res) {
  res.writeHead(200, {
    ...corsHeaders(),
    "content-type": "text/event-stream; charset=utf-8",
    "cache-control": "no-cache",
    connection: "keep-alive"
  });
  res.write("\n");
  sseClients.add(res);
  req.on("close", () => sseClients.delete(res));
}

function writePublicationFiles(profile) {
  const rows = publicationRows();
  if (!rows.length) throw new Error("В очереди нет объявлений для публикации.");
  const xmlPath = writeWbPublicationXml(rows, profile);
  const csvPath = writeRpaCsv(rows);
  return { csvPath, xmlPath };
}

function writeWbPublicationXml(rows, profile) {
  const generatedAt = new Date();
  const xml = buildWbPublicationXml(rows, {
    generatedAt,
    profileId: profile.id,
    profileName: profile.name,
  });
  fs.mkdirSync(exportsDir, { recursive: true });
  fs.writeFileSync(latestXmlPath, xml, "utf8");
  const archiveName = `wb-publication-${generatedAt.toISOString().replace(/[:.]/g, "-")}.xml`;
  fs.writeFileSync(path.join(exportsDir, archiveName), xml, "utf8");
  return latestXmlPath;
}

function writeRpaCsv(rows = publicationRows()) {
  const csv = buildCsv(rows);
  fs.mkdirSync(path.dirname(desktopRpaCsv), { recursive: true });
  fs.writeFileSync(desktopRpaCsv, "\uFEFF" + csv, "utf8");
  db.prepare("UPDATE listings SET status = 'exported', updated_at = CURRENT_TIMESTAMP WHERE status IN ('ready', 'draft', 'error')").run();
  return desktopRpaCsv;
}

function publicationRows() {
  return db.prepare("SELECT * FROM listings WHERE status IN ('ready', 'draft', 'error') ORDER BY id ASC").all().map(fromDb);
}

function buildCsv(rows = publicationRows()) {
  const headers = ["id", "title", "category", "photos", "price", "allow_offers", "quantity", "condition", "description", "characteristics", "pickup_point", "accept_rules", "draft_only"];
  return [
    headers.join(";"),
    ...rows.map((row) => headers.map((key) => csvCell(key === "id" ? row.sku : row[key])).join(";"))
  ].join("\r\n");
}

function normalizeListing(input) {
  const sku = String(input.sku || "").trim() || `item-${Date.now()}`;
  const title = String(input.title || "").trim();
  if (!title) throw new Error("Название обязательно");
  return {
    sku,
    title,
    category: String(input.category || "").trim(),
    photos: String(input.photos || "").trim(),
    price: Number(input.price || 0),
    allow_offers: input.allow_offers ? 1 : 0,
    quantity: Math.max(1, Math.min(20, Number(input.quantity || 1))),
    condition: String(input.condition || "Хорошее"),
    description: String(input.description || "").trim(),
    characteristics: String(input.characteristics || "").trim(),
    pickup_point: DEFAULT_PICKUP_POINT,
    accept_rules: input.accept_rules ? 1 : 0,
    draft_only: input.draft_only ? 1 : 0,
    status: String(input.status || "draft"),
    note: String(input.note || ""),
    sizes: Array.isArray(input.sizes) ? input.sizes.map((size) => String(size).trim()).filter(Boolean) : []
  };
}

function saveListingOrBatch(body) {
  const sizes = body.sizes.length ? body.sizes : [];
  if (!sizes.length) {
    upsertListing(body);
    return [body.sku];
  }

  const saved = [];
  for (const size of sizes) {
    const variant = {
      ...body,
      sku: `${body.sku}-${slugSize(size)}`,
      characteristics: mergeSizeCharacteristic(body.characteristics, size),
      quantity: body.quantity
    };
    upsertListing(variant);
    saved.push(variant.sku);
  }
  return saved;
}

function upsertListing(body) {
  const existing = db.prepare("SELECT id FROM listings WHERE sku = ?").get(body.sku);
  if (existing) updateListing(body);
  else insertListing(body);
}

function slugSize(size) {
  return String(size).toLowerCase().replaceAll("+", "plus").replace(/[^a-z0-9а-яё]+/gi, "-").replace(/^-+|-+$/g, "") || "size";
}

function mergeSizeCharacteristic(characteristics, size) {
  const base = String(characteristics || "").trim();
  const withoutSize = base
    .split(/[,;\n]/)
    .map((part) => part.trim())
    .filter((part) => part && !/^\u0440\u0430\u0437\u043c\u0435\u0440(?:\s|$)/i.test(part));
  return [`Размер ${size}`, ...withoutSize].join(", ");
}

function saveUploadedPhotos(body) {
  const sku = slugName(body.sku || `item-${Date.now()}`);
  const files = Array.isArray(body.files) ? body.files : [];
  if (files.length < 1) throw new Error("Выберите хотя бы одно фото");
  if (files.length > 30) throw new Error("WB принимает максимум 30 фото");

  const targetDir = path.join(rpaPhotosDir, sku);
  fs.mkdirSync(targetDir, { recursive: true });

  const saved = files.map((file, index) => {
    const ext = safeImageExt(file.name, file.type);
    const filename = `${String(index + 1).padStart(2, "0")}${ext}`;
    const base64 = String(file.data || "").replace(/^data:[^,]+,/, "");
    const buffer = Buffer.from(base64, "base64");
    if (!buffer.length) throw new Error(`Фото ${file.name || index + 1} пустое`);
    const absolute = path.join(targetDir, filename);
    fs.writeFileSync(absolute, buffer);
    return {
      path: `photos/${sku}/${filename}`,
      preview: `/api/photos/photos/${encodeURIComponent(sku)}/${encodeURIComponent(filename)}`,
      name: file.name || filename
    };
  });

  return { ok: true, photos: saved, photosText: saved.map((photo) => photo.path).join(",") };
}

async function importXmlListings(body) {
  const xml = String(body.xml || "");
  if (!xml.trim()) throw new Error("XML пустой");
  const publish = body.publish !== false;
  const ads = dedupeXmlAds(parseXmlAds(xml));
  if (!ads.length) throw new Error("В XML не найдены объявления <Ad>");

  const saved = [];
  const errors = [];
  await runLimited(ads.map((ad, index) => async () => {
    try {
      const sku = slugName(ad.Id || ad.Title || `xml-${Date.now()}-${index + 1}`);
      const photos = normalizeXmlImageUrls(ad.Images, sku);
      const descriptionParts = splitDescriptionSections(normalizeXmlDescription(ad.Description || ""));
      const listing = normalizeListing({
        sku,
        title: ad.Title || `Товар из XML ${index + 1}`,
        category: wbCategoryFromXml(ad.Category, ad.GoodsSubType, ad.GoodsType),
        photos: photos.join(","),
        price: Number(String(ad.Price || "").replace(/[^\d]/g, "")) || 0,
        allow_offers: true,
        quantity: 14,
        condition: "Новое",
        description: descriptionParts.description,
        characteristics: xmlCharacteristics(ad, descriptionParts.characteristics),
        pickup_point: DEFAULT_PICKUP_POINT,
        accept_rules: true,
        draft_only: false,
        status: "ready",
        note: "Импортировано из XML",
        sizes: []
      });
      saved.push(...saveListingOrBatch(listing));
    } catch (error) {
      errors.push({ index: index + 1, title: ad.Title || "", error: error.message || String(error) });
    }
  }), 10);

  if (publish && saved.length && !rpaProcess) {
    const selected = selectAgentProfile(agentSettings, agentSettings.browser, body.profileId);
    agentSettings = selected.settings;
    saveAgentSettings(agentSettings);
    const files = writePublicationFiles(selected.profile);
    startRpa("publish", selected.profile);
    return { ok: true, imported: saved.length, skippedDuplicates: ads.skippedDuplicates || 0, saved, errors, publishing: true, ...files, profile: selected.profile };
  }

  return { ok: true, imported: saved.length, skippedDuplicates: ads.skippedDuplicates || 0, saved, errors, publishing: false };
}

async function runLimited(tasks, limit) {
  const queue = [...tasks];
  const workers = Array.from({ length: Math.max(1, Math.min(limit, queue.length)) }, async () => {
    while (queue.length) {
      const task = queue.shift();
      if (task) await task();
    }
  });
  await Promise.all(workers);
}

function dedupeXmlAds(ads) {
  const byKey = new Map();
  const unique = [];
  let skipped = 0;

  for (const ad of ads) {
    const key = xmlDedupeKey(ad);
    const existing = byKey.get(key);
    if (existing) {
      mergeXmlDuplicate(existing, ad);
      skipped += 1;
      continue;
    }
    byKey.set(key, ad);
    unique.push(ad);
  }

  Object.defineProperty(unique, "skippedDuplicates", {
    value: skipped,
    enumerable: false
  });
  return unique;
}

function mergeXmlDuplicate(target, source) {
  target.Images = [...new Set([...(target.Images || []), ...(source.Images || [])].filter(Boolean))];
  for (const field of ["Title", "Description", "Price", "Category", "GoodsType", "GoodsSubType", "Condition", "Brand", "Color", "Size", "Material", "Apparel"]) {
    if (!target[field] && source[field]) target[field] = source[field];
  }
}

function xmlDedupeKey(ad) {
  const id = String(ad.Id || "").trim();
  if (id) return `id:${id.toLowerCase()}`;

  const imageKey = (ad.Images || [])
    .map((url) => String(url).trim().toLowerCase().replace(/[?#].*$/, ""))
    .filter(Boolean)
    .slice(0, 3)
    .join("|");

  return [
    normalizeDedupeText(ad.Title),
    normalizeDedupeText(ad.Description).slice(0, 500),
    normalizeDedupeText(String(ad.Price || "").replace(/[^\d]/g, "")),
    imageKey
  ].join("::");
}

function normalizeXmlImageUrls(urls, sku) {
  const uniqueUrls = [...new Set((urls || []).filter(Boolean))]
    .filter((url) => !/\/ky-strok-size-guide(?:-v\d+)?\.jpg(?:[?#]|$)/i.test(String(url)))
    .slice(0, 29);
  if (!uniqueUrls.length) throw new Error(`В XML у товара ${sku} нет фото`);
  while (uniqueUrls.length < 3) uniqueUrls.push(uniqueUrls[uniqueUrls.length - 1]);
  return [...uniqueUrls.map((url) => normalizePhotoUrl(url)), SIZE_GUIDE_URL];
}

function normalizePhotoUrl(url) {
  const raw = String(url || "").trim();
  if (!raw) return raw;
  try {
    const parsed = new URL(raw);
    if (parsed.hostname === "crmavito.duckdns.org") parsed.protocol = "https:";
    return parsed.toString();
  } catch {
    return raw;
  }
}

function normalizeDedupeText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeXmlDescription(value) {
  return String(value || "")
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+\/[ \t]+/g, "\n")
    .split("\n")
    .map((line) => line.trim())
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function parseXmlAds(xml) {
  return [...xml.matchAll(/<Ad\b[^>]*>([\s\S]*?)<\/Ad>/gi)].map((match, index) => {
    const block = match[1];
    const ad = {
      Id: xmlText(block, "Id") || `xml-${Date.now()}-${index + 1}`,
      Title: xmlText(block, "Title"),
      Description: xmlText(block, "Description"),
      Price: xmlText(block, "Price"),
      Category: xmlText(block, "Category"),
      GoodsType: xmlText(block, "GoodsType"),
      GoodsSubType: xmlText(block, "GoodsSubType"),
      Condition: xmlText(block, "Condition"),
      Brand: xmlText(block, "Brand"),
      Color: xmlText(block, "Color"),
      Size: xmlText(block, "Size"),
      Material: xmlOptionText(block, "MaterialsOdezhda") || xmlText(block, "Material"),
      Apparel: xmlText(block, "Apparel"),
      Images: [...block.matchAll(/<Image\b[^>]*\burl=(["'])(.*?)\1[^>]*\/?>/gi)]
        .map((image) => decodeXml(image[2]).trim())
        .filter(Boolean)
    };
    return ad;
  });
}

function xmlText(block, tag) {
  const match = block.match(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"));
  return match ? decodeXml(match[1].replace(/^<!\[CDATA\[|\]\]>$/g, "")).trim() : "";
}

function xmlOptionText(block, tag) {
  const section = block.match(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"))?.[1] || "";
  return xmlText(section, "Option");
}

function decodeXml(value) {
  return String(value || "")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");
}

async function downloadXmlImages(urls, sku, imageCache = new Map()) {
  const uniqueUrls = [...new Set((urls || []).filter(Boolean))].slice(0, 30);
  if (uniqueUrls.length < 3) throw new Error(`В XML у товара ${sku} меньше 3 фото`);
  const targetDir = path.join(rpaPhotosDir, sku);
  fs.mkdirSync(targetDir, { recursive: true });

  return Promise.all(uniqueUrls.map(async (url, index) => {
    const cached = imageCache.get(url);
    const ext = cached ? path.extname(cached) : safeImageExt(new URL(url).pathname, "");
    const filename = `${String(index + 1).padStart(2, "0")}${ext}`;
    const targetPath = path.join(targetDir, filename);

    if (cached && fs.existsSync(cached)) {
      fs.copyFileSync(cached, targetPath);
      return `photos/${sku}/${filename}`;
    }

    const { buffer, contentType, status } = await fetchImageWithTimeout(url, 15_000);
    if (status < 200 || status >= 300) throw new Error(`Не удалось скачать фото ${url}: HTTP ${status}`);
    if (!buffer.length) throw new Error(`Фото ${url} пустое`);
    const responseExt = safeImageExt(new URL(url).pathname, contentType);
    const responseFilename = responseExt === ext ? filename : `${String(index + 1).padStart(2, "0")}${responseExt}`;
    const responseTargetPath = path.join(targetDir, responseFilename);
    fs.writeFileSync(responseTargetPath, buffer);
    imageCache.set(url, responseTargetPath);
    return `photos/${sku}/${responseFilename}`;
  }));
}

async function fetchImageWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { signal: controller.signal });
    const buffer = Buffer.from(await response.arrayBuffer());
    return {
      status: response.status,
      contentType: response.headers.get("content-type") || "",
      buffer
    };
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error(`Таймаут скачивания фото ${url}`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function wbCategoryFromXml(category, subtype, type) {
  const raw = `${category || ""} ${subtype || ""} ${type || ""}`.toLowerCase();
  if (/футбол|одежд|гардероб|лонгслив|худи|свитшот|рубаш/.test(raw)) return "Одежда / Футболки";
  return "Одежда";
}

function splitDescriptionSections(description) {
  const raw = String(description || "").trim();
  if (!raw) return { description: "", characteristics: [] };

  const lines = raw.split(/\r?\n/);
  const output = [];
  const characteristics = [];
  let inCharacteristics = false;

  for (const line of lines) {
    const trimmed = line.trim();
    if (/^характеристики\s*:?$/i.test(trimmed)) {
      inCharacteristics = true;
      continue;
    }

    if (inCharacteristics && isDescriptionSectionHeader(trimmed)) {
      inCharacteristics = false;
    }

    if (inCharacteristics) {
      const cleaned = cleanupCharacteristicLine(trimmed);
      if (cleaned) characteristics.push(cleaned);
      continue;
    }

    output.push(line);
  }

  return {
    description: formatDescriptionSizeRange(output.join("\n").replace(/\n{3,}/g, "\n\n").trim()),
    characteristics
  };
}

function formatDescriptionSizeRange(description) {
  const sizes = new Set(XML_LISTING_SIZES);
  const lines = String(description || "").split("\n");
  const output = [];

  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const nextLineIsSize = index + 1 < lines.length && sizes.has(lines[index + 1].trim().toUpperCase());
    if (!/^\u0440\u0430\u0437\u043c\u0435\u0440/i.test(line.trim()) || !nextLineIsSize) {
      output.push(line);
      continue;
    }

    output.push("\u0420\u0430\u0437\u043c\u0435\u0440\u044b:");
    const found = [];
    while (index + 1 < lines.length && sizes.has(lines[index + 1].trim().toUpperCase())) {
      found.push(lines[index + 1].trim().toUpperCase());
      index += 1;
    }
    if (found.length) output.push(found.join(" / "));
  }

  return output.join("\n").trim();
}

function isDescriptionSectionHeader(line) {
  return /^(преимущества|размеры|цена|доставка|условия|описание|дизайн)\s*:?$/i.test(line);
}

function cleanupCharacteristicLine(line) {
  return String(line || "")
    .replace(/^[•\-\*]\s*/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function xmlCharacteristics(ad, descriptionCharacteristics = []) {
  const size = normalizeXmlSize(ad.Size);
  return [
    size ? `Размер ${size}` : "",
    `Пол Унисекс`,
    ad.Color ? `Цвет ${ad.Color}` : "",
    ad.Brand ? `Бренд ${ad.Brand}` : "",
    ad.Material ? `Состав ${ad.Material}` : "",
    ...descriptionCharacteristics
  ].filter(Boolean).join(", ");
}

function normalizeXmlSize(value) {
  const raw = String(value || "").trim().toUpperCase();
  if (!raw) return "";
  const parenthesized = raw.match(/\((XXS|XS|S|M|L|XL|2XL)\)/);
  if (parenthesized) return parenthesized[1];
  const direct = raw.match(/^(XXS|XS|S|M|L|XL|2XL)$/);
  return direct ? direct[1] : raw;
}

function xmlGender(...values) {
  const raw = values.filter(Boolean).join(" ").toLowerCase();
  if (/женск|девоч/.test(raw)) return "Женский";
  if (/мужск|мальчик/.test(raw)) return "Мужской";
  return "Унисекс";
}

function slugName(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replaceAll("+", "plus")
    .replace(/[^a-z0-9а-яё_-]+/gi, "-")
    .replace(/^-+|-+$/g, "") || `item-${Date.now()}`;
}

function safeImageExt(name = "", type = "") {
  const fromName = path.extname(String(name)).toLowerCase();
  if ([".jpg", ".jpeg", ".png", ".webp"].includes(fromName)) return fromName === ".jpeg" ? ".jpg" : fromName;
  if (type.includes("png")) return ".png";
  if (type.includes("webp")) return ".webp";
  return ".jpg";
}

function insertListing(body) {
  db.prepare(`
    INSERT INTO listings (
      sku, title, category, photos, price, allow_offers, quantity,
      condition, description, characteristics, pickup_point, accept_rules,
      draft_only, status, note
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(body.sku, body.title, body.category, body.photos, body.price, body.allow_offers, body.quantity, body.condition, body.description, body.characteristics, body.pickup_point, body.accept_rules, body.draft_only, body.status, body.note);
}

function updateListing(body) {
  db.prepare(`
    UPDATE listings SET
      title = ?, category = ?, photos = ?, price = ?, allow_offers = ?,
      quantity = ?, condition = ?, description = ?, characteristics = ?,
      pickup_point = ?, accept_rules = ?, draft_only = ?, status = ?,
      note = ?, updated_at = CURRENT_TIMESTAMP
    WHERE sku = ?
  `).run(body.title, body.category, body.photos, body.price, body.allow_offers, body.quantity, body.condition, body.description, body.characteristics, body.pickup_point, body.accept_rules, body.draft_only, body.status, body.note, body.sku);
}

function fromDb(row) {
  return {
    ...row,
    allow_offers: Boolean(row.allow_offers),
    accept_rules: Boolean(row.accept_rules),
    draft_only: Boolean(row.draft_only)
  };
}

function csvCell(value) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

function readJson(req, limit = 5_000_000) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
      if (data.length > limit) reject(new Error("Request is too large"));
    });
    req.on("end", () => resolve(data ? JSON.parse(data) : {}));
    req.on("error", reject);
  });
}

function normalizeBrowser(value) {
  return normalizeBrowserPreference(value);
}

function loadAgentSettings() {
  try {
    const stored = JSON.parse(fs.readFileSync(settingsPath, "utf8"));
    return normalizeAgentSettings(stored);
  } catch {
    return normalizeAgentSettings({ browser: "chrome" });
  }
}

function saveAgentSettings(settings) {
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2) + "\n", "utf8");
}

function serveRpaPhoto(res, relativePath) {
  const clean = path.normalize(relativePath).replace(/^(\.\.[/\\])+/, "");
  const filePath = path.join(rpaDir, clean);
  if (!filePath.startsWith(rpaDir) || !fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end("Not found");
    return;
  }
  const ext = path.extname(filePath).toLowerCase();
  const contentTypes = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp" };
  res.writeHead(200, { ...corsHeaders(), "content-type": contentTypes[ext] || "application/octet-stream" });
  fs.createReadStream(filePath).pipe(res);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { ...corsHeaders(), "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function sendCorsPreflight(res) {
  res.writeHead(204, corsHeaders());
  res.end();
}

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-allow-private-network": "true",
    "access-control-max-age": "86400"
  };
}

function serveStatic(res, pathname) {
  const cleanPath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.join(publicDir, path.normalize(cleanPath).replace(/^(\.\.[/\\])+/, ""));
  if (!filePath.startsWith(publicDir) || !fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end("Not found");
    return;
  }
  const ext = path.extname(filePath).toLowerCase();
  const contentTypes = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8" };
  res.writeHead(200, { ...corsHeaders(), "content-type": contentTypes[ext] || "application/octet-stream" });
  fs.createReadStream(filePath).pipe(res);
}
