const fs = require("node:fs");
const http = require("node:http");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { URL } = require("node:url");
const { DatabaseSync } = require("node:sqlite");

const rootDir = __dirname;
const dataDir = path.join(rootDir, "data");
const publicDir = path.join(rootDir, "public");
const dbPath = path.join(dataDir, "app.db");
const desktopDir = path.join(process.env.USERPROFILE || "", "Desktop");
const rpaDir = path.join(desktopDir, "WB Resale RPA");
const desktopRpaCsv = path.join(rpaDir, "items.csv");
const rpaPhotosDir = path.join(rpaDir, "photos");
const port = Number(process.env.PORT || 3017);

fs.mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(dbPath);
db.exec(`
  CREATE TABLE IF NOT EXISTS listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT '',
    photos TEXT NOT NULL DEFAULT '',
    price INTEGER NOT NULL DEFAULT 0,
    allow_offers INTEGER NOT NULL DEFAULT 1,
    quantity INTEGER NOT NULL DEFAULT 1,
    condition TEXT NOT NULL DEFAULT 'Хорошее',
    description TEXT NOT NULL DEFAULT '',
    characteristics TEXT NOT NULL DEFAULT '',
    pickup_point TEXT NOT NULL DEFAULT '',
    accept_rules INTEGER NOT NULL DEFAULT 1,
    draft_only INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft',
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

let rpaProcess = null;
let rpaState = { running: false, exitCode: null, startedAt: null, endedAt: null };
let rpaEvents = [];
const sseClients = new Set();

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") {
      sendCorsPreflight(res);
      return;
    }
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) {
      await handleApi(req, res, url);
      return;
    }
    serveStatic(res, url.pathname);
  } catch (error) {
    sendJson(res, 500, { error: error.message || String(error) });
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`WB Resale CRM: http://127.0.0.1:${port}`);
  console.log(`SQLite: ${dbPath}`);
});

async function handleApi(req, res, url) {
  if (req.method === "GET" && url.pathname === "/api/events") {
    handleEvents(req, res);
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/rpa/status") {
    sendJson(res, 200, { ...rpaState, events: rpaEvents.slice(-120) });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/start") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "RPA уже запущен" });
      return;
    }
    const csvPath = writeRpaCsv();
    startRpa("publish");
    sendJson(res, 200, { ok: true, csvPath });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/test") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "RPA уже запущен" });
      return;
    }
    const csvPath = writeRpaCsv();
    startRpa("test");
    sendJson(res, 200, { ok: true, csvPath, mode: "test" });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/dry-run") {
    if (rpaProcess) {
      sendJson(res, 409, { error: "RPA уже запущен" });
      return;
    }
    const csvPath = writeRpaCsv();
    startRpa("dry-run");
    sendJson(res, 200, { ok: true, csvPath, mode: "dry-run" });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/stop") {
    if (rpaProcess) {
      rpaProcess.kill();
      pushRpaEvent({ type: "run", status: "stopping", message: "Останавливаю RPA" });
    }
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/rpa/clear-log") {
    rpaEvents = [];
    broadcast({ type: "clear" });
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/listings") {
    const rows = db.prepare("SELECT * FROM listings WHERE status != 'archived' ORDER BY updated_at DESC, id DESC").all().map(fromDb);
    sendJson(res, 200, rows);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/listings") {
    const body = normalizeListing(await readJson(req));
    const saved = saveListingOrBatch(body);
    sendJson(res, 200, { ok: true, saved });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/uploads") {
    const body = await readJson(req, 120_000_000);
    const result = saveUploadedPhotos(body);
    sendJson(res, 200, result);
    return;
  }

  if (req.method === "GET" && url.pathname.startsWith("/api/photos/")) {
    serveRpaPhoto(res, decodeURIComponent(url.pathname.replace("/api/photos/", "")));
    return;
  }

  if (req.method === "PATCH" && url.pathname.startsWith("/api/listings/")) {
    const sku = decodeURIComponent(url.pathname.split("/").pop());
    const body = await readJson(req);
    const status = String(body.status || "draft");
    const note = String(body.note || "");
    db.prepare("UPDATE listings SET status = ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE sku = ?").run(status, note, sku);
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "DELETE" && url.pathname.startsWith("/api/listings/")) {
    const sku = decodeURIComponent(url.pathname.split("/").pop());
    db.prepare("DELETE FROM listings WHERE sku = ?").run(sku);
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/export.csv") {
    const csv = buildCsv();
    res.writeHead(200, {
      ...corsHeaders(),
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": "attachment; filename=\"items.csv\""
    });
    res.end("\uFEFF" + csv);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/export-to-rpa") {
    const csvPath = writeRpaCsv();
    sendJson(res, 200, { ok: true, path: csvPath });
    return;
  }

  sendJson(res, 404, { error: "Not found" });
}

function startRpa(mode) {
  rpaEvents = [];
  rpaState = { running: true, exitCode: null, startedAt: new Date().toISOString(), endedAt: null };
  const isTest = mode === "test";
  const isDryRun = mode === "dry-run";
  pushRpaEvent({ type: "run", status: "starting", message: isTest ? "Запускаю тест на локальной форме" : isDryRun ? "Проверяю WB без публикации" : "Запускаю браузер и RPA" });

  rpaProcess = spawn(process.execPath, ["src/publish-resale.mjs"], {
    cwd: rpaDir,
    env: {
      ...process.env,
      AUTO_PUBLISH: isTest || isDryRun ? "0" : "1",
      AUTO_OPEN_FORM: "1",
      NO_PAUSE: "1",
      START_URL: isTest ? `file:///${path.join(rpaDir, "tests", "mock-wb-form.html").replaceAll("\\", "/")}` : ""
    },
    windowsHide: false
  });

  rpaProcess.stdout.on("data", (chunk) => handleRpaOutput(chunk.toString("utf8"), "stdout"));
  rpaProcess.stderr.on("data", (chunk) => handleRpaOutput(chunk.toString("utf8"), "stderr"));
  rpaProcess.on("exit", (code) => {
    rpaState = { ...rpaState, running: false, exitCode: code, endedAt: new Date().toISOString() };
    pushRpaEvent({ type: "run", status: code === 0 ? "done" : "failed", message: `RPA завершился с кодом ${code}` });
    rpaProcess = null;
  });
}

function handleRpaOutput(text, stream) {
  for (const line of text.split(/\r?\n/).filter(Boolean)) {
    if (line.startsWith("EVENT_JSON:")) {
      try {
        const event = JSON.parse(line.slice("EVENT_JSON:".length));
        pushRpaEvent(event);
        if (event.type === "item" && event.id) {
          syncListingStatus(event);
        }
      } catch {
        pushRpaEvent({ type: "log", level: "error", message: line });
      }
    } else {
      pushRpaEvent({ type: "log", level: stream === "stderr" ? "error" : "info", message: line });
    }
  }
}

function syncListingStatus(event) {
  const statusMap = {
    running: "running",
    publishing: "running",
    submitted: "moderation",
    draft_review: "ready",
    error: "error"
  };
  const status = statusMap[event.status];
  if (!status) return;
  db.prepare("UPDATE listings SET status = ?, note = ?, updated_at = CURRENT_TIMESTAMP WHERE sku = ?").run(
    status,
    event.message || "",
    event.id
  );
}

function pushRpaEvent(event) {
  const full = { time: new Date().toISOString(), ...event };
  rpaEvents.push(full);
  if (rpaEvents.length > 500) rpaEvents = rpaEvents.slice(-500);
  broadcast(full);
}

function broadcast(event) {
  const data = `data: ${JSON.stringify(event)}\n\n`;
  for (const client of sseClients) client.write(data);
}

function handleEvents(req, res) {
  res.writeHead(200, {
    ...corsHeaders(),
    "content-type": "text/event-stream; charset=utf-8",
    "cache-control": "no-cache",
    connection: "keep-alive"
  });
  res.write("\n");
  sseClients.add(res);
  req.on("close", () => sseClients.delete(res));
}

function writeRpaCsv() {
  const csv = buildCsv();
  fs.mkdirSync(path.dirname(desktopRpaCsv), { recursive: true });
  fs.writeFileSync(desktopRpaCsv, "\uFEFF" + csv, "utf8");
  db.prepare("UPDATE listings SET status = 'exported', updated_at = CURRENT_TIMESTAMP WHERE status IN ('ready', 'draft', 'error')").run();
  return desktopRpaCsv;
}

function buildCsv() {
  const headers = ["id", "title", "category", "photos", "price", "allow_offers", "quantity", "condition", "description", "characteristics", "pickup_point", "accept_rules", "draft_only"];
  const rows = db.prepare("SELECT * FROM listings WHERE status IN ('ready', 'draft', 'error') ORDER BY id ASC").all().map(fromDb);
  return [
    headers.join(";"),
    ...rows.map((row) => headers.map((key) => csvCell(key === "id" ? row.sku : row[key])).join(";"))
  ].join("\r\n");
}

function normalizeListing(input) {
  const sku = String(input.sku || "").trim() || `item-${Date.now()}`;
  const title = String(input.title || "").trim();
  if (!title) throw new Error("Название обязательно");
  return {
    sku,
    title,
    category: String(input.category || "").trim(),
    photos: String(input.photos || "").trim(),
    price: Number(input.price || 0),
    allow_offers: input.allow_offers ? 1 : 0,
    quantity: Math.max(1, Math.min(20, Number(input.quantity || 1))),
    condition: String(input.condition || "Хорошее"),
    description: String(input.description || "").trim(),
    characteristics: String(input.characteristics || "").trim(),
    pickup_point: String(input.pickup_point || "").trim(),
    accept_rules: input.accept_rules ? 1 : 0,
    draft_only: input.draft_only ? 1 : 0,
    status: String(input.status || "draft"),
    note: String(input.note || ""),
    sizes: Array.isArray(input.sizes) ? input.sizes.map((size) => String(size).trim()).filter(Boolean) : []
  };
}

function saveListingOrBatch(body) {
  const sizes = body.sizes.length ? body.sizes : [];
  if (!sizes.length) {
    upsertListing(body);
    return [body.sku];
  }

  const saved = [];
  for (const size of sizes) {
    const variant = {
      ...body,
      sku: `${body.sku}-${slugSize(size)}`,
      characteristics: mergeSizeCharacteristic(body.characteristics, size),
      quantity: 1
    };
    upsertListing(variant);
    saved.push(variant.sku);
  }
  return saved;
}

function upsertListing(body) {
  const existing = db.prepare("SELECT id FROM listings WHERE sku = ?").get(body.sku);
  if (existing) updateListing(body);
  else insertListing(body);
}

function slugSize(size) {
  return String(size).toLowerCase().replaceAll("+", "plus").replace(/[^a-z0-9а-яё]+/gi, "-").replace(/^-+|-+$/g, "") || "size";
}

function mergeSizeCharacteristic(characteristics, size) {
  const base = String(characteristics || "").trim();
  const withoutSize = base
    .split(/[,;\n]/)
    .map((part) => part.trim())
    .filter((part) => part && !/^размер\b/i.test(part));
  return [`Размер ${size}`, ...withoutSize].join(", ");
}

function saveUploadedPhotos(body) {
  const sku = slugName(body.sku || `item-${Date.now()}`);
  const files = Array.isArray(body.files) ? body.files : [];
  if (files.length < 1) throw new Error("Выберите хотя бы одно фото");
  if (files.length > 30) throw new Error("WB принимает максимум 30 фото");

  const targetDir = path.join(rpaPhotosDir, sku);
  fs.mkdirSync(targetDir, { recursive: true });

  const saved = files.map((file, index) => {
    const ext = safeImageExt(file.name, file.type);
    const filename = `${String(index + 1).padStart(2, "0")}${ext}`;
    const base64 = String(file.data || "").replace(/^data:[^,]+,/, "");
    const buffer = Buffer.from(base64, "base64");
    if (!buffer.length) throw new Error(`Фото ${file.name || index + 1} пустое`);
    const absolute = path.join(targetDir, filename);
    fs.writeFileSync(absolute, buffer);
    return {
      path: `photos/${sku}/${filename}`,
      preview: `/api/photos/photos/${encodeURIComponent(sku)}/${encodeURIComponent(filename)}`,
      name: file.name || filename
    };
  });

  return { ok: true, photos: saved, photosText: saved.map((photo) => photo.path).join(",") };
}

function slugName(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replaceAll("+", "plus")
    .replace(/[^a-z0-9а-яё_-]+/gi, "-")
    .replace(/^-+|-+$/g, "") || `item-${Date.now()}`;
}

function safeImageExt(name = "", type = "") {
  const fromName = path.extname(String(name)).toLowerCase();
  if ([".jpg", ".jpeg", ".png", ".webp"].includes(fromName)) return fromName === ".jpeg" ? ".jpg" : fromName;
  if (type.includes("png")) return ".png";
  if (type.includes("webp")) return ".webp";
  return ".jpg";
}

function insertListing(body) {
  db.prepare(`
    INSERT INTO listings (
      sku, title, category, photos, price, allow_offers, quantity,
      condition, description, characteristics, pickup_point, accept_rules,
      draft_only, status, note
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(body.sku, body.title, body.category, body.photos, body.price, body.allow_offers, body.quantity, body.condition, body.description, body.characteristics, body.pickup_point, body.accept_rules, body.draft_only, body.status, body.note);
}

function updateListing(body) {
  db.prepare(`
    UPDATE listings SET
      title = ?, category = ?, photos = ?, price = ?, allow_offers = ?,
      quantity = ?, condition = ?, description = ?, characteristics = ?,
      pickup_point = ?, accept_rules = ?, draft_only = ?, status = ?,
      note = ?, updated_at = CURRENT_TIMESTAMP
    WHERE sku = ?
  `).run(body.title, body.category, body.photos, body.price, body.allow_offers, body.quantity, body.condition, body.description, body.characteristics, body.pickup_point, body.accept_rules, body.draft_only, body.status, body.note, body.sku);
}

function fromDb(row) {
  return {
    ...row,
    allow_offers: Boolean(row.allow_offers),
    accept_rules: Boolean(row.accept_rules),
    draft_only: Boolean(row.draft_only)
  };
}

function csvCell(value) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

function readJson(req, limit = 5_000_000) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
      if (data.length > limit) reject(new Error("Request is too large"));
    });
    req.on("end", () => resolve(data ? JSON.parse(data) : {}));
    req.on("error", reject);
  });
}

function serveRpaPhoto(res, relativePath) {
  const clean = path.normalize(relativePath).replace(/^(\.\.[/\\])+/, "");
  const filePath = path.join(rpaDir, clean);
  if (!filePath.startsWith(rpaDir) || !fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end("Not found");
    return;
  }
  const ext = path.extname(filePath).toLowerCase();
  const contentTypes = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp" };
  res.writeHead(200, { ...corsHeaders(), "content-type": contentTypes[ext] || "application/octet-stream" });
  fs.createReadStream(filePath).pipe(res);
}

function sendJson(res, status, payload) {
  res.writeHead(status, { ...corsHeaders(), "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

function sendCorsPreflight(res) {
  res.writeHead(204, corsHeaders());
  res.end();
}

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-allow-private-network": "true",
    "access-control-max-age": "86400"
  };
}

function serveStatic(res, pathname) {
  const cleanPath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.join(publicDir, path.normalize(cleanPath).replace(/^(\.\.[/\\])+/, ""));
  if (!filePath.startsWith(publicDir) || !fs.existsSync(filePath)) {
    res.writeHead(404);
    res.end("Not found");
    return;
  }
  const ext = path.extname(filePath).toLowerCase();
  const contentTypes = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8" };
  res.writeHead(200, { ...corsHeaders(), "content-type": contentTypes[ext] || "application/octet-stream" });
  fs.createReadStream(filePath).pipe(res);
}
