import assert from "node:assert/strict";
import path from "node:path";
import test from "node:test";
import { defaultProfileDirectory, resolveBrowserExecutable } from "../src/browser-launch.mjs";

const env = {
  LOCALAPPDATA: "C:\\Users\\Test\\AppData\\Local",
  ProgramFiles: "C:\\Program Files",
  "ProgramFiles(x86)": "C:\\Program Files (x86)"
};

test("auto prefers Chrome when Chrome and Yandex Browser are installed", () => {
  const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  const yandexPath = "C:\\Program Files\\Yandex\\YandexBrowser\\Application\\browser.exe";
  const result = resolveBrowserExecutable({
    preference: "auto",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === chromePath || candidate === yandexPath,
    playwrightExecutablePath: "C:\\missing\\playwright\\chrome.exe"
  });

  assert.deepEqual(result, {
    id: "chrome",
    name: "Google Chrome",
    executablePath: chromePath
  });
});

test("default browser preference is Chrome", () => {
  const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  const result = resolveBrowserExecutable({
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === chromePath
  });

  assert.equal(result.id, "chrome");
  assert.equal(result.executablePath, chromePath);
});

test("Yandex Browser remains available only through an explicit override", () => {
  const yandexPath = "C:\\Program Files\\Yandex\\YandexBrowser\\Application\\browser.exe";
  const result = resolveBrowserExecutable({
    preference: "yandex",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === yandexPath
  });

  assert.equal(result.id, "yandex");
  assert.equal(result.executablePath, yandexPath);
});

test("chromium reports a useful install hint when its binary is absent", () => {
  assert.throws(
    () => resolveBrowserExecutable({
      preference: "chromium",
      platform: "win32",
      env,
      existsSync: () => false,
      playwrightExecutablePath: "C:\\missing\\playwright\\chrome.exe"
    }),
    /npx playwright install chromium/
  );
});

test("browser-specific profiles do not mix Yandex and Chrome data", () => {
  assert.equal(defaultProfileDirectory("C:\\agent", "yandex"), path.join("C:\\agent", ".browser-profile-yandex"));
  assert.equal(defaultProfileDirectory("C:\\agent", "chrome"), path.join("C:\\agent", ".browser-profile-chrome"));
});
