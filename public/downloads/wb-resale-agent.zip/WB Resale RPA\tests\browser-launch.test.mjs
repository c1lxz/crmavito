import assert from "node:assert/strict";
import path from "node:path";
import test from "node:test";
import { defaultProfileDirectory, resolveBrowserExecutable } from "../src/browser-launch.mjs";

const env = {
  LOCALAPPDATA: "C:\\Users\\Test\\AppData\\Local",
  ProgramFiles: "C:\\Program Files",
  "ProgramFiles(x86)": "C:\\Program Files (x86)"
};

test("auto prefers Yandex Browser and does not require Playwright Chromium", () => {
  const yandexPath = "C:\\Program Files\\Yandex\\YandexBrowser\\Application\\browser.exe";
  const result = resolveBrowserExecutable({
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === yandexPath,
    playwrightExecutablePath: "C:\\missing\\playwright\\chrome.exe"
  });

  assert.deepEqual(result, {
    id: "yandex",
    name: "Yandex Browser",
    executablePath: yandexPath
  });
});

test("auto falls back to Chrome when Yandex Browser is absent", () => {
  const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  const result = resolveBrowserExecutable({
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === chromePath
  });

  assert.equal(result.id, "chrome");
  assert.equal(result.executablePath, chromePath);
});

test("chromium reports a useful install hint when its binary is absent", () => {
  assert.throws(
    () => resolveBrowserExecutable({
      preference: "chromium",
      platform: "win32",
      env,
      existsSync: () => false,
      playwrightExecutablePath: "C:\\missing\\playwright\\chrome.exe"
    }),
    /npx playwright install chromium/
  );
});

test("browser-specific profiles do not mix Yandex and Chrome data", () => {
  assert.equal(defaultProfileDirectory("C:\\agent", "yandex"), path.join("C:\\agent", ".browser-profile-yandex"));
  assert.equal(defaultProfileDirectory("C:\\agent", "chrome"), path.join("C:\\agent", ".browser-profile-chrome"));
});

