import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { defaultProfileDirectory, prepareBrowserProfile, resolveBrowserExecutable } from "../src/browser-launch.mjs";

const env = {
  LOCALAPPDATA: "C:\\Users\\Test\\AppData\\Local",
  ProgramFiles: "C:\\Program Files",
  "ProgramFiles(x86)": "C:\\Program Files (x86)"
};

test("auto prefers Chrome when Chrome and Yandex Browser are installed", () => {
  const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  const yandexPath = "C:\\Program Files\\Yandex\\YandexBrowser\\Application\\browser.exe";
  const result = resolveBrowserExecutable({
    preference: "auto",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === chromePath || candidate === yandexPath,
    playwrightExecutablePath: "C:\\missing\\playwright\\chrome.exe"
  });

  assert.deepEqual(result, {
    id: "chrome",
    name: "Google Chrome",
    engine: "chromium",
    executablePath: chromePath
  });
});

test("default browser preference is Chrome", () => {
  const chromePath = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  const result = resolveBrowserExecutable({
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === chromePath
  });

  assert.equal(result.id, "chrome");
  assert.equal(result.executablePath, chromePath);
});

test("Yandex Browser remains available only through an explicit override", () => {
  const yandexPath = "C:\\Program Files\\Yandex\\YandexBrowser\\Application\\browser.exe";
  const result = resolveBrowserExecutable({
    preference: "yandex",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === yandexPath
  });

  assert.equal(result.id, "yandex");
  assert.equal(result.engine, "chromium");
  assert.equal(result.executablePath, yandexPath);
});

test("Microsoft Edge uses the Chromium engine", () => {
  const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
  const result = resolveBrowserExecutable({
    preference: "edge",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === edgePath
  });

  assert.deepEqual(result, {
    id: "edge",
    name: "Microsoft Edge",
    engine: "chromium",
    executablePath: edgePath
  });
});

test("Mozilla Firefox uses the Firefox engine", () => {
  const firefoxPath = "C:\\Program Files\\Mozilla Firefox\\firefox.exe";
  const result = resolveBrowserExecutable({
    preference: "firefox",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === firefoxPath
  });

  assert.deepEqual(result, {
    id: "firefox",
    name: "Mozilla Firefox",
    engine: "firefox",
    executablePath: firefoxPath
  });
});

test("Mozilla Firefox prefers the Playwright-compatible binary", () => {
  const systemFirefox = "C:\\Program Files\\Mozilla Firefox\\firefox.exe";
  const playwrightFirefox = "C:\\Playwright\\firefox\\firefox.exe";
  const result = resolveBrowserExecutable({
    preference: "firefox",
    platform: "win32",
    env,
    existsSync: (candidate) => candidate === systemFirefox || candidate === playwrightFirefox,
    playwrightExecutablePaths: { firefox: playwrightFirefox }
  });

  assert.equal(result.engine, "firefox");
  assert.equal(result.executablePath, playwrightFirefox);
});

test("chromium reports a useful install hint when its binary is absent", () => {
  assert.throws(
    () => resolveBrowserExecutable({
      preference: "chromium",
      platform: "win32",
      env,
      existsSync: () => false,
      playwrightExecutablePath: "C:\\missing\\playwright\\chrome.exe"
    }),
    /npx playwright install chromium/
  );
});

test("browser-specific profiles do not mix browser data", () => {
  assert.equal(defaultProfileDirectory("C:\\agent", "yandex"), path.join("C:\\agent", ".browser-profile-yandex"));
  assert.equal(defaultProfileDirectory("C:\\agent", "chrome"), path.join("C:\\agent", ".browser-profile-chrome"));
  assert.equal(defaultProfileDirectory("C:\\agent", "edge"), path.join("C:\\agent", ".browser-profile-edge"));
  assert.equal(defaultProfileDirectory("C:\\agent", "firefox"), path.join("C:\\agent", ".browser-profile-firefox"));
});

test("persistent Chrome profile keeps the selected account name", () => {
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), "wbr-profile-name-"));
  try {
    prepareBrowserProfile(userDataDir, "c1lxz");
    const preferences = JSON.parse(fs.readFileSync(path.join(userDataDir, "Default", "Preferences"), "utf8"));
    const localState = JSON.parse(fs.readFileSync(path.join(userDataDir, "Local State"), "utf8"));
    assert.equal(preferences.profile.name, "c1lxz");
    assert.equal(preferences.profile.is_using_default_name, false);
    assert.equal(localState.profile.info_cache.Default.name, "c1lxz");
  } finally {
    fs.rmSync(userDataDir, { recursive: true, force: true });
  }
});
