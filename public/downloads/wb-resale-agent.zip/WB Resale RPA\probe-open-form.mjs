﻿import fs from 'node:fs';
import { chromium } from 'playwright';
const selectors = JSON.parse(fs.readFileSync('selectors.json','utf8'));
const context = await chromium.launchPersistentContext('.browser-profile', { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(8000);
await page.goto(selectors.startUrl, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3000);
let clicked = false;
for (const selector of selectors.createButton) {
  const loc = page.locator(selector).first();
  if (await loc.count().catch(()=>0) && await loc.isVisible().catch(()=>false)) {
    console.log('CLICK', selector, await loc.innerText().catch(()=>''));
    await loc.click();
    clicked = true;
    break;
  }
}
console.log('clicked', clicked);
await page.waitForTimeout(5000);
console.log('url', page.url());
const diag = await page.evaluate(() => ({
  title: document.title,
  text: document.body.innerText.slice(0,3000),
  inputs: [...document.querySelectorAll('input,textarea,select')].map(el => ({tag:el.tagName, name:el.getAttribute('name'), placeholder:el.getAttribute('placeholder'), visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible).slice(0,50),
  buttons: [...document.querySelectorAll('button,[role="button"],a')].map(el => ({tag:el.tagName, text:(el.innerText||el.textContent||'').trim().replace(/\s+/g,' '), href:el.href||el.getAttribute('href')||'', visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible && x.text).slice(0,80)
}));
console.log(JSON.stringify(diag,null,2));
await page.screenshot({ path: 'logs/probe-after-create-click.png', fullPage: true });
await context.close();
