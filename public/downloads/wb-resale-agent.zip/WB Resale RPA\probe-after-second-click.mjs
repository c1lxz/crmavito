﻿import fs from 'node:fs';
import { chromium } from 'playwright';
const selectors = JSON.parse(fs.readFileSync('selectors.json','utf8'));
const context = await chromium.launchPersistentContext('.browser-profile', { headless: false, viewport: { width: 1366, height: 900 }, locale: 'ru-RU' });
const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(8000);
await page.goto(selectors.startUrl, { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(3000);
await page.locator("button:has-text('Продать что‑то своё')").first().click();
await page.waitForTimeout(2500);
await page.locator("button:has-text('Разместить объявление')").first().click();
await page.waitForTimeout(4000);
console.log('url', page.url());
const diag = await page.evaluate(() => ({
 text: document.body.innerText.slice(0,4000),
 modals: [...document.querySelectorAll('[class*=modal],[class*=popup],[data-floating-ui-portal]')].map(el => ({text:(el.innerText||el.textContent||'').trim().replace(/\s+/g,' ').slice(0,2000), cls:String(el.className||''), visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible || x.text).slice(0,20),
 inputs: [...document.querySelectorAll('input,textarea,select')].map(el => ({tag:el.tagName,name:el.getAttribute('name'),placeholder:el.getAttribute('placeholder'),type:el.getAttribute('type'),cls:String(el.className||'').slice(0,80),visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible).slice(0,100),
 buttons: [...document.querySelectorAll('button,[role="button"],a')].map(el => ({tag:el.tagName,text:(el.innerText||el.textContent||'').trim().replace(/\s+/g,' '),href:el.href||el.getAttribute('href')||'',cls:String(el.className||'').slice(0,80),visible:(()=>{const r=el.getBoundingClientRect(); return r.width>5&&r.height>5})()})).filter(x=>x.visible && x.text).slice(0,120)
}));
console.log(JSON.stringify(diag,null,2));
await page.screenshot({ path: 'logs/probe-after-second-click.png', fullPage: true });
await context.close();
