import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium, firefox } from "playwright";
import { defaultProfileDirectory, resolveBrowserExecutable } from "./browser-launch.mjs";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sku = String(process.env.DELETE_SKU || "").trim();
const title = String(process.env.DELETE_TITLE || "").trim();
const listingUrl = String(process.env.DELETE_URL || "").trim();
const browser = resolveBrowserExecutable({
  playwrightExecutablePaths: {
    chromium: chromium.executablePath(),
    firefox: firefox.executablePath()
  }
});
const browserType = browser.engine === "firefox" ? firefox : chromium;
const userDataDir = process.env.BROWSER_PROFILE
  ? path.resolve(process.env.BROWSER_PROFILE)
  : defaultProfileDirectory(rootDir, browser.id);

if (!sku || !title) throw new Error("Не переданы данные объявления для удаления");

const context = await browserType.launchPersistentContext(userDataDir, {
  executablePath: browser.executablePath,
  headless: false,
  viewport: { width: 1366, height: 1000 },
  locale: "ru-RU",
});
const page = context.pages()[0] ?? await context.newPage();
page.setDefaultTimeout(8000);

try {
  emit({ type: "item", id: sku, status: "running", message: "Ищу объявление в Wildberries" });
  await page.goto(listingUrl || "https://www.wildberries.ru/resale/ads", {
    waitUntil: "domcontentloaded",
  });
  await page.waitForLoadState("networkidle", { timeout: 15_000 }).catch(() => {});

  if (!listingUrl) {
    const titleLocator = page.getByText(title, { exact: true }).first();
    if (!(await titleLocator.isVisible().catch(() => false))) {
      throw new Error(`Объявление «${title}» не найдено в списке WB`);
    }

    const href = await titleLocator.evaluate((element) => {
      const anchor = element.closest("a") || element.parentElement?.closest("a");
      return anchor?.href || "";
    }).catch(() => "");
    if (href) {
      await page.goto(href, { waitUntil: "domcontentloaded" });
    } else {
      await titleLocator.click();
      await page.waitForTimeout(1200);
    }
  }

  await clickAction(page, [/снять с публикации/i, /удалить объявление/i, /^удалить$/i]);
  await page.waitForTimeout(500);
  await clickAction(page, [/^удалить$/i, /^подтвердить$/i, /^да, удалить$/i], { optional: true });

  await page.waitForTimeout(1500);
  const body = await page.locator("body").innerText().catch(() => "");
  if (/не удалось|ошибка|попробуйте позже/i.test(body)) {
    throw new Error("Wildberries показал ошибку при удалении объявления");
  }
  emit({ type: "item", id: sku, status: "deleted", message: "Удалено из Wildberries" });
} catch (error) {
  emit({ type: "item", id: sku, status: "error", message: error?.message || String(error) });
  process.exitCode = 1;
} finally {
  await context.close().catch(() => {});
}

async function clickAction(page, patterns, options = {}) {
  const buttons = page.locator("button,a,[role='button']");
  for (let index = 0; index < await buttons.count(); index += 1) {
    const button = buttons.nth(index);
    if (!(await button.isVisible().catch(() => false))) continue;
    const text = String(await button.innerText().catch(() => "")).trim();
    if (!patterns.some((pattern) => pattern.test(text))) continue;
    await button.click();
    return;
  }

  const menuButtons = page.locator("button[aria-label*='меню' i],button[aria-label*='действ' i],button").filter({
    has: page.locator("svg"),
  });
  if (!options.menuTried && await menuButtons.count()) {
    await menuButtons.first().click().catch(() => {});
    await page.waitForTimeout(400);
    return clickAction(page, patterns, { ...options, menuTried: true });
  }

  if (!options.optional) throw new Error("Кнопка удаления объявления не найдена");
}

function emit(payload) {
  console.log(`EVENT_JSON:${JSON.stringify({ time: new Date().toISOString(), ...payload })}`);
}
